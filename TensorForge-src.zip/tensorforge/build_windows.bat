@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TensorForge - Windows build

echo ============================================================
echo    TensorForge
echo    One-click build  ->  dist\TensorForge.exe
echo ============================================================
echo.
echo This script needs:
echo   - Windows 10/11 (64-bit)
echo   - about 3 GB of free disk space
echo   - an internet connection (it downloads PyTorch, ~250 MB)
echo.
echo Python itself is installed automatically if you do not have it.
echo.

REM A running TensorForge.exe holds a lock on dist\TensorForge.exe, which makes
REM PyInstaller fail with "Access is denied" five minutes into the build.
call :close_running_app
pause

REM ============================================================
REM  1. Find a usable Python 3.9+
REM ============================================================
set "PY="

call :probe py -3
if defined PY goto got_python
call :probe python
if defined PY goto got_python
call :probe python3
if defined PY goto got_python

call :probe "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PY goto got_python
call :probe "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if defined PY goto got_python
call :probe "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
if defined PY goto got_python
call :probe "%ProgramFiles%\Python312\python.exe"
if defined PY goto got_python
call :probe "%ProgramFiles%\Python311\python.exe"
if defined PY goto got_python

echo.
echo Python 3 was not found on this PC.
echo TensorForge will install it for you now.
echo.
call :install_python
if not defined PY goto no_python

:got_python
echo.
echo Using Python: "%PY%"
"%PY%" --version
echo.

REM ============================================================
REM  2. Virtual environment
REM ============================================================
echo [1/4] Preparing the virtual environment (.venv) ...
if exist ".venv\Scripts\python.exe" goto venv_ready
"%PY%" -m venv .venv
if errorlevel 1 goto venv_failed
:venv_ready
call .venv\Scripts\activate.bat
if errorlevel 1 goto venv_failed
echo       ok.
echo.

REM ============================================================
REM  3. Dependencies
REM ============================================================
echo [2/4] Upgrading pip ...
python -m pip install --upgrade pip wheel --quiet
if errorlevel 1 goto pip_failed

echo [3/4] Installing Flask, NumPy, Matplotlib, PyInstaller ...
python -m pip install --quiet "flask>=3.0" "numpy>=2.0" "matplotlib>=3.8" "pillow>=10.0" "pyinstaller>=6.6"
if errorlevel 1 goto pip_failed

echo       Installing PyTorch (CPU build, ~250 MB - this is the slow part) ...
python -m pip install --quiet torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto pip_failed
echo       ok.
echo.

REM ============================================================
REM  4. Freeze into one .exe
REM ============================================================
echo [4/4] Building dist\TensorForge.exe (takes 5-10 minutes) ...
python build_exe.py --clean
if errorlevel 1 goto build_failed

if not exist "dist\TensorForge.exe" goto build_failed

echo.
echo ============================================================
echo    DONE
echo ============================================================
for %%F in ("dist\TensorForge.exe") do echo    File : %%~fF
for %%F in ("dist\TensorForge.exe") do echo    Size : %%~zF bytes
echo.
echo    Double-click that file to start TensorForge.
echo    Your browser opens at http://127.0.0.1:8765
echo ============================================================
echo.
choice /c YN /n /m "Open the folder with the exe now? [Y/N] "
if errorlevel 2 goto end_ok
explorer "%~dp0dist"
goto end_ok

REM ============================================================
REM  Helpers
REM ============================================================
:close_running_app
tasklist /FI "IMAGENAME eq TensorForge.exe" /NH 2>nul | find /I "TensorForge.exe" >nul
if errorlevel 1 exit /b 0
echo TensorForge is open right now - closing it so the build can replace the exe.
taskkill /F /IM TensorForge.exe /T >nul 2>&1
ping -n 3 127.0.0.1 >nul
exit /b 0

:probe
REM %* is a candidate command line. On success PY is set to the full exe path.
%* -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
if errorlevel 1 exit /b 0
REM write the interpreter path to a temp file (safer than for /f with quotes)
%* -c "import sys;print(sys.executable)" > "%TEMP%\tf_py.txt" 2>nul
set "PY="
set /p PY=<"%TEMP%\tf_py.txt"
del "%TEMP%\tf_py.txt" >nul 2>nul
exit /b 0

:install_python
where winget >nul 2>nul
if errorlevel 1 goto ip_download

echo Trying the Windows Package Manager (winget) ...
winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements --silent
call :probe "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PY exit /b 0
call :probe py -3
if defined PY exit /b 0
echo winget did not work, falling back to a direct download.
echo.

:ip_download
echo Downloading the official Python 3.12 installer from python.org ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile ($env:TEMP + '\python-setup.exe')"
if errorlevel 1 exit /b 1
if not exist "%TEMP%\python-setup.exe" exit /b 1

echo Installing Python (1-2 minutes, no clicks needed) ...
"%TEMP%\python-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0 SimpleInstall=1
call :probe "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PY exit /b 0
call :probe py -3
if defined PY exit /b 0
call :probe "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
exit /b 0

REM ============================================================
REM  Error paths
REM ============================================================
:no_python
echo.
echo ------------------------------------------------------------
echo  Python could not be installed automatically.
echo.
echo  Please do this once, manually:
echo    1. open https://www.python.org/downloads/windows/
echo    2. download "Windows installer (64-bit)" for Python 3.12
echo    3. run it and TICK "Add python.exe to PATH"
echo    4. run this build_windows.bat again
echo ------------------------------------------------------------
pause
exit /b 1

:venv_failed
echo.
echo Could not create the virtual environment.
echo.
echo If the message above says "No module named venv" or "ensurepip", the
echo Python found on this PC is incomplete (the Microsoft Store build is).
echo Install the full build from https://www.python.org/downloads/windows/
echo (tick "Add python.exe to PATH"), delete the .venv folder, and retry.
pause
exit /b 1

:pip_failed
echo.
echo A package failed to install. The most common causes:
echo   - no internet connection / proxy blocking pypi.org
echo   - less than 3 GB of free disk space
echo Scroll up to see the pip error, then run this script again.
pause
exit /b 1

:build_failed
echo.
echo PyInstaller failed. Scroll up for the full error.
echo.
echo   "PermissionError: [WinError 5] Access is denied" /
echo   "The process cannot access the file ... being used by another process"
echo      -> TensorForge is still running, or antivirus is scanning the exe.
echo         Close every TensorForge window, wait a few seconds and run this
echo         script again. If it persists, delete the dist folder, pause
echo         your antivirus for the build, and - if this project sits in
echo         OneDrive/Dropbox - pause syncing while it builds.
echo.
echo   "MemoryError" / "Killed"
echo      -> close other programs and retry (the build peaks around 1.5 GB RAM).
echo.
echo   Anything about torch / DLLs
echo      -> delete the .venv folder and run this script again so PyTorch is
echo         reinstalled cleanly.
pause
exit /b 1

:end_ok
echo.
pause
exit /b 0
