"""
Build a single-file TensorForge executable with PyInstaller.

    python build_exe.py                # build for the current OS
    python build_exe.py --clean        # wipe build/ and dist/ first
    python build_exe.py --onedir       # folder build (starts much faster)

Windows output : dist\\TensorForge.exe

The exe is replaced safely even while an older copy of TensorForge is still
running: Windows keeps a running program's .exe locked, and PyInstaller then
dies with "PermissionError: [WinError 5] Access is denied". We close the app,
retry the delete, and only if the file stays locked (antivirus, another user)
do we build into dist-build/ and swap it in afterwards.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SPEC = ROOT / "tensorforge.spec"
DIST = ROOT / "dist"
ALT_DIST = ROOT / "dist-build"


def exe_name() -> str:
    return "TensorForge.exe" if os.name == "nt" else "TensorForge"


def run(cmd: list[str]) -> int:
    print("\n$ " + " ".join(cmd), flush=True)
    return subprocess.call(cmd, cwd=str(ROOT))


# --------------------------------------------------------------------------- #
#  Replacing an exe that Windows refuses to let go of
# --------------------------------------------------------------------------- #
def app_is_running() -> bool:
    """True when a TensorForge.exe process is alive (it locks its own image)."""
    if os.name != "nt":
        return False
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq TensorForge.exe", "/NH"],
            capture_output=True, text=True, timeout=25,
        ).stdout
    except Exception:
        return False
    return "TensorForge.exe" in out


def stop_running_app() -> bool:
    """Close a running TensorForge. Returns True when one was actually killed."""
    if not app_is_running():
        return False
    print("  TensorForge is running - closing it so the build can replace the exe ...")
    try:
        subprocess.run(["taskkill", "/F", "/IM", "TensorForge.exe", "/T"],
                       capture_output=True, text=True, timeout=30)
    except Exception:
        pass
    # give Windows a moment to release the image section
    for _ in range(20):
        if not app_is_running():
            return True
        time.sleep(0.25)
    return True


def wait_until_free(path: Path, tries: int = 24, delay: float = 0.5) -> bool:
    """Delete `path`, retrying while another process (app or antivirus) holds it."""
    for _ in range(tries):
        try:
            path.unlink()
            return True
        except FileNotFoundError:
            return True
        except OSError:                      # PermissionError on Windows
            time.sleep(delay)
    return not path.exists()


def move_aside(path: Path) -> Path | None:
    """Rename a locked exe out of the way - Windows allows renaming a running image."""
    for i in range(6):
        tomb = path.with_name(path.name + (".old" if not i else f".old{i}"))
        try:
            path.rename(tomb)
            print(f"  note: the old exe was still locked, moved it to {tomb.name}")
            return tomb
        except OSError:
            time.sleep(0.5)
    return None


def _purge_tombstones() -> None:
    for old in DIST.glob(exe_name() + ".old*"):
        try:
            old.unlink()
        except OSError:
            pass
    left = sorted(DIST.glob(exe_name() + ".old*"))
    if left:
        print("  note: " + ", ".join(p.name for p in left) +
              " is still locked and will be left on disk - delete it after the app closes.")


def free_dist() -> Path:
    """Make sure dist/<exe> can be written.

    Returns the distpath PyInstaller should write to. Normally that is ./dist.
    If the old exe cannot be removed (the app is still running, antivirus scan,
    Explorer preview pane), we build into ./dist-build instead and swap after.
    """
    DIST.mkdir(exist_ok=True)
    target = DIST / exe_name()
    if not target.exists():
        _purge_tombstones()
        return DIST

    stop_running_app()
    if wait_until_free(target):
        _purge_tombstones()
        return DIST

    tomb = move_aside(target)
    if tomb is not None:
        _purge_tombstones()                  # best effort: may still be locked
        return DIST

    print("\n  ! dist/" + exe_name() + " is locked by another program.")
    print("    Windows locks a program's .exe while it runs, antivirus scanners can")
    print("    do the same, and so can OneDrive/Dropbox sync if this folder is inside")
    print("    one. Building into dist-build/ instead, then swapping it in.")
    ALT_DIST.mkdir(exist_ok=True)
    return ALT_DIST


def publish_from(alt: Path) -> int:
    """Move dist-build/<exe> into dist/, or explain why we could not."""
    src = alt / exe_name()
    dst = DIST / exe_name()
    if not src.exists():
        print("\n  The build did not produce " + str(src))
        return 1
    if dst.exists():
        wait_until_free(dst, tries=4)
    try:
        os.replace(src, dst)
        print(f"   Moved the new build into {dst}")
        _purge_tombstones()
        try:
            alt.rmdir()
        except OSError:
            pass
        return 0
    except OSError:
        pass
    print("\n  The old exe is still locked, so the fresh build is here instead:\n"
          f"     {src}\n"
          "  Close TensorForge (taskbar + Task Manager), delete\n"
          f"     {dst}\n"
          f"  then rename {src.name} to {dst.name} - or just run the new file.")
    return 2


def patch_spec_onedir(onedir: bool) -> None:
    """Flip EXE(...) into COLLECT-based onedir mode when asked."""
    text = SPEC.read_text(encoding="utf-8")
    marker = "# __TF_ONEDIR__"
    if marker in text:
        text = text.split(marker)[0]
    if onedir:
        text += f"""
{marker}
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="TensorForge",
          debug=False, strip=False, upx=False, console=False,
          icon=str(ROOT / "build_assets" / "icon.ico") if IS_WIN else None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="TensorForge")
"""
    SPEC.write_text(text, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--clean", action="store_true")
    ap.add_argument("--onedir", action="store_true")
    ap.add_argument("--no-spec-patch", action="store_true",
                    help="do not rewrite the spec (leaves it in onefile mode)")
    args = ap.parse_args()

    if not args.no_spec_patch:
        patch_spec_onedir(args.onedir)

    if args.clean:
        for d in ("build", "dist-build"):
            shutil.rmtree(ROOT / d, ignore_errors=True)
        shutil.rmtree(DIST, ignore_errors=True)   # may fail while the app runs; free_dist handles it

    try:
        import PyInstaller  # noqa: F401
    except ImportError:
        print("PyInstaller is missing - installing it...")
        if run([sys.executable, "-m", "pip", "install", "--upgrade", "pyinstaller"]):
            return 1

    # A CUDA build of torch would triple the size of the exe; warn early.
    try:
        import torch

        if getattr(torch.version, "cuda", None):
            print("WARNING: this torch build has CUDA support, so TensorForge.exe will be "
                  "very large. Install the CPU build instead:\n"
                  "  pip install torch --index-url https://download.pytorch.org/whl/cpu")
    except Exception:
        pass

    # Never let PyInstaller trip over a locked dist/TensorForge.exe: that is what
    # produced "PermissionError: [WinError 5] Access is denied" mid-build.
    stop_running_app()
    distpath = free_dist()

    t0 = time.time()
    cmd = [sys.executable, "-m", "PyInstaller", str(SPEC), "--noconfirm",
           "--clean", "--log-level", "WARN"]
    if distpath != DIST:
        cmd += ["--distpath", str(distpath)]
    code = run(cmd)
    if code:
        return code

    if distpath != DIST:
        swapped = publish_from(distpath)
        if swapped:
            return swapped

    exe = DIST / exe_name()
    if exe.exists():
        mb = exe.stat().st_size / (1024 * 1024)
        print(f"\n✅ Built {exe}  ({mb:.0f} MB) in {time.time() - t0:.0f}s")
        print("   Double-click it - your browser opens at http://127.0.0.1:8765")
        return 0
    print("\n  PyInstaller finished but no exe appeared in dist/. Check the log above.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
