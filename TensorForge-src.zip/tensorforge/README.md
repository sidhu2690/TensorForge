# ⚡ TensorForge

A LeetCode-style practice app for **PyTorch, NumPy, Python and Matplotlib** — 2,049 problems,
each with hidden automated tests generated from a reference solution, plus an AI coach powered
by Groq (`qwen/qwen3.8-27b`).

Ships as **one executable**. Double-click it, the browser opens, paste your API key once.

---

## What's inside

| Track | Problems | Easy / Medium / Hard | What it covers |
|---|---|---|---|
| 🔥 **PyTorch** | 846 | 162 / 510 / 174 | tensors & broadcasting, autograd, nn modules, losses, optimizers & schedulers, metrics, attention, data pipelines, internals |
| 🔢 **NumPy** | 675 | 144 / 459 / 72 | array creation, indexing, broadcasting, reductions, linear algebra, statistics, sorting, random |
| 🐍 **Python** | 321 | 99 / 207 / 15 | core language, data structures, classes, generators, decorators, algorithms (two-sum → LRU cache → Roman numerals) |
| 📊 **Matplotlib** | 207 | all easy | lines, scatter, bars, hist, subplots, styles, legends, ticks, 3-D, images, violin/box plots |

Every problem has:
* a **starter snippet** with the exact required signature,
* a **worked example** (input → expected output),
* **hidden tests** — randomized cases + edge cases, and for plotting problems, property
  checks on the actual artists (colors, labels, limits, ticks, legend location, bar heights…),
* **3 graded hints** (built-in, and an AI version that reads your code),
* a **reference solution** you can reveal or have explained.

## Getting it running (no Python? that's fine)

`build_windows.bat` no longer assumes Python is installed — it finds an existing
Python 3.9+, and if there is none it installs one (winget, or a silent install from
python.org) and then builds.

**Option A — one file to double-click (recommended)**

1. Double-click **`build_windows.bat`**.
   It installs Python if needed, creates `.venv`, downloads Flask/NumPy/Matplotlib/PyTorch
   (~250 MB, CPU build), then freezes everything into `dist\TensorForge.exe`.
   Takes 10-20 minutes the first time; needs ~3 GB free disk.
2. When it finishes, double-click **`dist\TensorForge.exe`**. Your browser opens
   `http://127.0.0.1:8765`.

**Option B — run it without building an exe**

Double-click **`run_from_source.bat`**. Same dependency install, but it starts the app
directly and skips the 5-10 minute PyInstaller step. Ideal while you are still trying
things out.

**Option C — no Windows machine needed**

`tools/build_windows_on_linux.sh` builds the same `TensorForge.exe` on Linux using Wine
(that is how the file was produced and verified here).

## Running the packaged app (what you do)

1. Get the exe (above).
2. Double-click **`TensorForge.exe`**.
   *First launch is slower* — the single-file app unpacks its runtime (~10-30 s), then it
   starts a local server and opens `http://127.0.0.1:8765` in your browser.
3. Click **⚙️ Settings → Groq API key**, paste a key from
   [console.groq.com/keys](https://console.groq.com/keys), press **Test connection**, **Save**.
   The key is stored locally in `%APPDATA%\TensorForge\tensorforge.db` and stays between
   launches. You can replace or remove it any time from the same screen.
4. Pick a track, solve problems, press **▶ Run** (`Ctrl+Enter`).

## Screens

| Library | Practice |
|---|---|
| ![library](docs/library.png) | ![practice](docs/practice.png) |

## Using the interface

The UI has two screens, both in the dark-green "IDE" style.

**Library** — everything you can solve, one row per *concept*.

* Topic chips (All / PyTorch / NumPy / Python / Matplotlib) with solved counters.
* Search, **Status** (unsolved, solved, partial, attempted, starred) and **Difficulty** filters.
* **Shuffle** mixes the table so you don't grind the same corner of the syllabus.
* Problems that used to repeat ("Broadcast add #1, #2, #3") are collapsed into **one row with
  3 variants**; the `Variants` column shows `1/3` and the variant picker lives in the editor header.
* The left rail shows overall progress in a segmented ring, current/best streak, and recent activity.

**Practice** — three panes, all separated by **draggable splitters** (your layout is remembered).

| Pane | Contents |
|---|---|
| Problem navigator | the filtered problem list, topic/difficulty segments, "unsolved only", **Pick for me** (random) |
| Description | difficulty + tags, prompt, signature, worked example, hints, checks — tabs: **Description · AI Coach · Solution · Notes** |
| Editor | line-numbered code area, variant selector, reset, **▶ Run**, **Submit**, and a **Testcase / Test result** pane underneath |

* `Ctrl+Enter` runs the tests · **Submit** runs the same checks and records the solve · code
  autosaves 0.8 s after you stop typing · `Esc` goes back to the library · `/` jumps to search.
* Drag the vertical splitters to give more room to the description, the editor, or the navigator;
  the horizontal splitter resizes the test panel. `⟨` collapses a pane, `⇄` swaps description/editor.
* The AI Coach tab holds streaming chat plus **Hint n**, **Review my code** and **Explain solution**.

Everything runs on your machine. The only network traffic is to the AI endpoint you configure.

## AI features

| Feature | Where | What it does |
|---|---|---|
| Graded hints | 💡 Hint | 3 escalating nudges, aware of the code you've written |
| Code review | 🩺 Review my code | Reads your failing tests + code, explains the bug, proposes a fix |
| Solution walkthrough | 🧠 Explain with AI | Explains the reference solution step by step |
| Tutor chat | AI coach tab | Streaming Q&A about shapes, gradients, broadcasting, dtype errors… |
| Settings | ⚙️ | API key, model, base URL, temperature, max tokens, connection test, model list |

Any OpenAI-compatible endpoint works (Groq, local vLLM, Ollama, OpenRouter…): change
**Base URL** and **Model** in Settings. Defaults: `https://api.groq.com/openai/v1`,
`qwen/qwen3.8-27b`.

## Building

### Windows (recommended path)

```bat
build_windows.bat
```
Creates a venv, installs `requirements.txt` (PyTorch CPU wheel ~250 MB), then runs PyInstaller.
Result: **`dist\TensorForge.exe`** — a single file you can copy anywhere.

Re-running the build while TensorForge is open is fine: the script closes a running
copy first, and `build_exe.py` retries the delete, renames the old exe if Windows
still holds it, or builds into `dist-build\` and swaps the file in at the end.

Manual equivalent:
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python build_exe.py --clean
```

### macOS / Linux
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python build_exe.py            # -> dist/TensorForge
```

### Run from source (development)
```bash
python app.py                  # http://127.0.0.1:8765
python app.py --port 9000 --no-browser
```

## How the test engine works

* The bank (`bank/*.json`) stores, per problem: prompt, starter, reference solution and the
  **generated check source** (randomized cases + property assertions).
* `runner.py` executes a submission in a **separate process**, then runs each check against
  it. A warm worker process is kept alive between runs, so `▶ Run tests` answers in
  milliseconds instead of re-importing torch every click.
* Infinite loops are cut off by a wall-clock timeout, a crashed process is detected and
  replaced automatically, and stdout/figures are captured and shown in the Results tab.
* Plotting checks compare artists, not pixels, so students can style freely while the
  required structure is still enforced; the rendered figure is shown to you as a PNG.

## Files

```
app.py               Flask app (API + AI + settings + progress DB)
runner.py            isolated test worker (JSON in / JSON out, warm loop)
templates/index.html the whole UI (single file, no external assets, v1.1 three-pane layout)
bank/*.json          2,049 problems, generated by build_bank.py
tools/               problem specs + generators + validator
tensorforge.spec     PyInstaller spec (one-file build, splash screen, icon)
hooks/hook-torch.py  curated torch hook: full libtorch, sources for inspect.getsource()
build_exe.py         build helper (--clean, --onedir)
build_windows.bat    one-click Windows build
```

## Where your data lives

| OS | Path |
|---|---|
| Windows | `%APPDATA%\TensorForge\` |
| macOS | `~/Library/Application Support/TensorForge/` |
| Linux | `~/.local/share/tensorforge/` |

* `tensorforge.db` — settings (API key), progress, notes, bookmarks
* `tensorforge.log` — startup log (useful if the window ever fails to appear)

Set `TENSORFORGE_HOME=/some/dir` to override (handy for a portable USB-stick install).

## Command-line flags

```
--port 8765        port for the local server
--host 127.0.0.1   bind address
--no-browser       don't open a browser tab automatically
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| Windows SmartScreen warning | "More info" → "Run anyway" — the exe is unsigned |
| Build fails with `PermissionError: [WinError 5] Access is denied: ...\dist\TensorForge.exe` | TensorForge was still running (Windows locks a running exe). The builder now closes it and retries, then renames the old file; if it still cannot, it builds to `dist-build\` and tells you to swap. Close the app / pause antivirus and re-run. |
| `The process cannot access the file ... being used by another process` | Same cause: a running `TensorForge.exe` or an antivirus scan. `build_windows.bat` now kills a stray instance before it starts. |
| Port already in use | `TensorForge.exe --port 8766` |
| AI says "no API key" | Settings → paste key → **Test connection** |
| First run takes 20-30 s | One-file builds unpack once per launch; later runs are cached by the OS |
| Antivirus quarantines the exe | Common for unsigned PyInstaller binaries — whitelist it, or build locally with `build_windows.bat` |
| Windows says "VCRUNTIME140.dll missing" | The exe bundles it; if your antivirus stripped it, install the [VC++ 2015-2022 redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe) |
