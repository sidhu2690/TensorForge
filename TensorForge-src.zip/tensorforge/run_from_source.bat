@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TensorForge

echo ============================================================
echo    TensorForge - run from source (no .exe needed)
echo ============================================================
echo.
echo The first run sets up a local Python environment (~250 MB of
echo downloads).  Every run after that starts in a few seconds.
echo.

if not exist ".venv\Scripts\python.exe" goto setup

REM ---------- already set up: just launch ----------
:launch
".venv\Scripts\python.exe" -c "import torch, flask, matplotlib, numpy" >nul 2>nul
if errorlevel 1 goto setup

echo Starting TensorForge ...
echo Close this window to stop the server.
echo.
".venv\Scripts\python.exe" app.py
pause
exit /b 0

REM ---------- first run ----------
:setup
echo No local environment found, setting one up.
echo.

set "PY="
call :probe py -3
if defined PY goto have_py
call :probe python
if defined PY goto have_py
call :probe python3
if defined PY goto have_py
call :probe "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PY goto have_py
call :probe "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if defined PY goto have_py
call :probe "%ProgramFiles%\Python312\python.exe"
if defined PY goto have_py

echo Python 3 was not found.
echo Run build_windows.bat once - it installs Python automatically - or install
echo Python 3.12 from https://www.python.org/downloads/windows/
echo and tick "Add python.exe to PATH", then start this file again.
pause
exit /b 1

:have_py
echo Using Python: "%PY%"
if exist .venv rmdir /s /q .venv
"%PY%" -m venv .venv
if errorlevel 1 goto setup_failed
call .venv\Scripts\activate.bat

echo Installing dependencies (a few minutes) ...
python -m pip install --upgrade pip wheel --quiet
python -m pip install --quiet "flask>=3.0" "numpy>=2.0" "matplotlib>=3.8" "pillow>=10.0"
python -m pip install --quiet torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto setup_failed
echo Environment ready.
echo.
goto launch

:setup_failed
echo.
echo Setup failed - scroll up for the error above.
echo.
echo If it says "No module named venv", the Python on this PC is a stripped
echo build (the Microsoft Store one usually is). Run build_windows.bat once:
echo it installs a full Python 3.12 from python.org, and this file then works.
pause
exit /b 1

:probe
%* -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul
if errorlevel 1 exit /b 0
REM write the interpreter path to a temp file (safer than for /f with quotes)
%* -c "import sys;print(sys.executable)" > "%TEMP%\tf_py.txt" 2>nul
set "PY="
set /p PY=<"%TEMP%\tf_py.txt"
del "%TEMP%\tf_py.txt" >nul 2>nul
exit /b 0
