"""
TensorForge — a LeetCode-style practice app for Python, NumPy, PyTorch & Matplotlib.

Run:      python app.py                (opens http://127.0.0.1:8765)
Flags:    --port 8765 --host 127.0.0.1 --no-browser
Frozen:   TensorForge.exe             (PyInstaller one-file build)
"""
from __future__ import annotations

import atexit
import json
import os
import queue
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_file, send_from_directory
from werkzeug.exceptions import HTTPException

# --------------------------------------------------------------------------- #
#  Paths & configuration
# --------------------------------------------------------------------------- #
FROZEN = bool(getattr(sys, "frozen", False))
BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
APP_DIR = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent


def _data_dir() -> Path:
    env = os.environ.get("TENSORFORGE_HOME")
    if env:
        p = Path(env)
    elif os.name == "nt":
        p = Path(os.environ.get("APPDATA", Path.home())) / "TensorForge"
    elif sys.platform == "darwin":
        p = Path.home() / "Library" / "Application Support" / "TensorForge"
    else:
        p = Path.home() / ".local" / "share" / "tensorforge"
    p.mkdir(parents=True, exist_ok=True)
    return p


DATA_DIR = _data_dir()

if FROZEN:
    # Data files keep their bytes but not always their mode bits; torch's shared
    # memory helper has to stay executable.
    try:
        _shm = Path(getattr(sys, "_MEIPASS", "")) / "torch" / "bin" / "torch_shm_manager"
        if _shm.exists() and not os.access(_shm, os.X_OK):
            os.chmod(_shm, 0o755)
    except Exception:
        pass
DB_PATH = DATA_DIR / "tensorforge.db"
BANK_DIR = BASE_DIR / "bank"
# The Windows build lives next to the source tree (see build_windows.bat)
WINDOWS_EXE = APP_DIR / "dist" / "TensorForge.exe"
if not WINDOWS_EXE.exists():
    WINDOWS_EXE = BASE_DIR / "dist" / "TensorForge.exe"

DEFAULT_BASE_URL = "https://api.groq.com/openai/v1"
DEFAULT_MODEL = "qwen/qwen3.8-27b"
RUN_TIMEOUT = int(os.environ.get("TENSORFORGE_RUN_TIMEOUT", "30"))

app = Flask(__name__, static_folder=str(BASE_DIR / "static"), static_url_path="/static")
app.config["JSON_SORT_KEYS"] = False

# --------------------------------------------------------------------------- #
#  Question bank
# --------------------------------------------------------------------------- #
_BANK: dict[str, dict] = {}
_BY_TOPIC: dict[str, list[dict]] = {}
_BANK_LOCK = threading.Lock()


def load_bank() -> None:
    if _BANK:
        return
    with _BANK_LOCK:
        if _BANK:
            return
        for path in sorted(BANK_DIR.glob("*.json")):
            if path.name == "manifest.json":
                continue
            items = json.loads(path.read_text(encoding="utf-8"))
            topic = path.stem
            _BY_TOPIC.setdefault(topic, []).extend(items)
            for item in items:
                _BANK[item["id"]] = item


load_bank()

TOPIC_META = {
    "python": {"label": "Python", "icon": "🐍", "accent": "#3b82f6"},
    "numpy": {"label": "NumPy", "icon": "🔢", "accent": "#22c55e"},
    "torch": {"label": "PyTorch", "icon": "🔥", "accent": "#f97316"},
    "matplotlib": {"label": "Matplotlib", "icon": "📊", "accent": "#a855f7"},
}
DIFF_ORDER = {"easy": 0, "medium": 1, "hard": 2}

# --------------------------------------------------------------------------- #
#  Database (progress, notes, settings)
# --------------------------------------------------------------------------- #
_DB_LOCK = threading.Lock()


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS progress (
                pid TEXT PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'attempted',
                attempts INTEGER NOT NULL DEFAULT 0,
                solved_at TEXT,
                last_code TEXT,
                updated_at TEXT
            );
            CREATE TABLE IF NOT EXISTS notes (
                pid TEXT PRIMARY KEY,
                note TEXT DEFAULT '',
                bookmark INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            """
        )


init_db()


def get_setting(key: str, default: str = "") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row and row["value"] is not None else default


def set_setting(key: str, value: str) -> None:
    with db() as conn:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


def progress_map() -> dict[str, dict]:
    with db() as conn:
        rows = conn.execute("SELECT pid, status, attempts FROM progress").fetchall()
    return {r["pid"]: dict(r) for r in rows}


def notes_map() -> dict[str, dict]:
    with db() as conn:
        rows = conn.execute("SELECT pid, bookmark FROM notes").fetchall()
    return {r["pid"]: dict(r) for r in rows}


DEFAULT_GLOBAL_NOTE = """# TensorForge Global Notebook

> Personal Markdown cheat sheet. AI additions insert cleanly under each section without changing your structure.

## PyTorch
- **`tensor.to(dtype)`** --> cast tensor dtype -> `torch.float32`, `torch.float64`, `torch.int64`, `torch.bool`
  ```python
  x = torch.tensor([1, 2, 3]).to(torch.float32)
  ```

## NumPy
- **`np.asarray(x, dtype=...)`** --> convert input to array without copying when possible -> `np.float32`, `np.int64`
  ```python
  a = np.asarray([1, 2, 3], dtype=np.float32)
  ```

## Python

## Matplotlib

## General & Gotchas
"""

SECTION_MAP = {
    "torch": "PyTorch",
    "pytorch": "PyTorch",
    "numpy": "NumPy",
    "python": "Python",
    "matplotlib": "Matplotlib",
    "plots": "Matplotlib",
    "general": "General & Gotchas",
}


def get_global_note() -> str:
    val = get_setting("global_note", "")
    if val.strip():
        return val
    md_file = DATA_DIR / "global_note.md"
    if md_file.exists():
        try:
            txt = md_file.read_text(encoding="utf-8")
            if txt.strip():
                set_setting("global_note", txt)
                return txt
        except Exception:
            pass
    set_setting("global_note", DEFAULT_GLOBAL_NOTE)
    return DEFAULT_GLOBAL_NOTE


def save_global_note(content: str) -> str:
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    set_setting("global_note", content)
    set_setting("global_note_updated", now)
    try:
        (DATA_DIR / "global_note.md").write_text(content, encoding="utf-8")
    except Exception:
        pass
    return now


def _normalize_section(raw: str, fallback_topic: str = "") -> str:
    cleaned = (raw or "").strip().lstrip("#").strip()
    low = cleaned.lower()
    for k, v in SECTION_MAP.items():
        if k in low:
            return v
    if fallback_topic and fallback_topic.lower() in SECTION_MAP:
        return SECTION_MAP[fallback_topic.lower()]
    return cleaned if cleaned in ("PyTorch", "NumPy", "Python", "Matplotlib", "General & Gotchas") else "General & Gotchas"


def _insert_into_global_note(md_text: str, section: str, entry: str) -> str:
    """
    Deterministically insert `entry` at the end of `## <section>` in `md_text`
    without modifying any existing notes or headings.
    """
    import re
    entry = entry.strip()
    if not entry:
        return md_text
    # Strip any accidental heading line the model might have included
    lines = [ln for ln in entry.splitlines() if not re.match(r"^#{1,3}\s+", ln.strip())]
    entry = "\n".join(lines).strip()
    if not entry.startswith(("- ", "* ")):
        entry = "- " + entry.lstrip("-* ").strip()

    if not md_text.strip():
        md_text = DEFAULT_GLOBAL_NOTE

    pattern = re.compile(rf"^##\s+{re.escape(section)}\s*$", re.IGNORECASE | re.MULTILINE)
    m = pattern.search(md_text)
    if not m:
        # Append section at the end without disturbing anything above
        sep = "" if md_text.endswith("\n\n") else ("\n" if md_text.endswith("\n") else "\n\n")
        return f"{md_text}{sep}## {section}\n{entry}\n"

    # Find the next `## ` heading after this section
    next_h = re.search(r"^##\s+.+$", md_text[m.end():], re.MULTILINE)
    if next_h:
        insert_pos = m.end() + next_h.start()
        before = md_text[:insert_pos].rstrip()
        after = md_text[insert_pos:]
        return f"{before}\n{entry}\n\n{after}"
    else:
        before = md_text.rstrip()
        return f"{before}\n{entry}\n"



# --------------------------------------------------------------------------- #
#  AI helpers (Groq-compatible chat completions API)
# --------------------------------------------------------------------------- #
def ai_settings() -> dict:
    return {
        "api_key": get_setting("api_key", os.environ.get("GROQ_API_KEY", "")),
        "model": get_setting("model", DEFAULT_MODEL) or DEFAULT_MODEL,
        "base_url": (get_setting("base_url", DEFAULT_BASE_URL) or DEFAULT_BASE_URL).rstrip("/"),
        "temperature": float(get_setting("temperature", "0.6") or 0.6),
        "max_tokens": int(get_setting("max_tokens", "1200") or 1200),
    }


def _clean_error(raw: bytes) -> str:
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
        if isinstance(data, dict):
            err = data.get("error", data)
            if isinstance(err, dict):
                return str(err.get("message") or err)[:400]
            return str(err)[:400]
    except Exception:
        pass
    return raw.decode("utf-8", "replace")[:400]


def ai_complete(messages: list[dict], *, stream: bool = False, temperature: float | None = None,
                max_tokens: int | None = None):
    cfg = ai_settings()
    if not cfg["api_key"]:
        raise RuntimeError("NO_API_KEY")
    payload = {
        "model": cfg["model"],
        "messages": messages,
        "temperature": cfg["temperature"] if temperature is None else temperature,
        "max_completion_tokens": cfg["max_tokens"] if max_tokens is None else max_tokens,
        "top_p": 0.95,
        "stream": bool(stream),
    }
    req = urllib.request.Request(
        cfg["base_url"] + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + cfg["api_key"],
            "User-Agent": "TensorForge/1.0",
        },
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=120)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"API {exc.code}: {_clean_error(exc.read())}") from None
    except Exception as exc:  # network errors
        raise RuntimeError(f"Network error: {exc}") from None

    if not stream:
        raw = resp.read().decode("utf-8", "replace")
        try:
            data = json.loads(raw)
            return data["choices"][0]["message"]["content"] or ""
        except Exception:
            raise RuntimeError(f"Unexpected response: {raw[:300]}") from None

    def gen():
        buf = b""
        for chunk in resp:
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not line.startswith(b"data:"):
                    continue
                payload_raw = line[5:].strip()
                if payload_raw == b"[DONE]":
                    return
                try:
                    obj = json.loads(payload_raw)
                    delta = obj["choices"][0].get("delta", {}).get("content") or ""
                except Exception:
                    continue
                if delta:
                    yield delta

    return gen()


def problem_context(item: dict, *, include_solution: bool = False, code: str = "") -> str:
    lines = [
        f"Problem: {item['title']}",
        f"Library: {item['topic']} | Difficulty: {item['difficulty']} | Tags: {', '.join(item['tags'])}",
        "",
        "Task:",
        item["ask"],
        "",
        f"Required signature: {item['sig']}",
    ]
    if item.get("example"):
        lines += ["", "Example:", item["example"].replace("```", "")]
    if code.strip():
        lines += ["", "The learner's current code:", "```python", code[:6000], "```"]
    if include_solution:
        lines += ["", "Reference solution (for your explanation):", "```python",
                  item["solution"][:4000], "```"]
    lines += [
        "",
        "Rules: be concise, concrete and friendly. Never invent APIs. "
        "Use plain markdown with short code fences. The learner is practicing, "
        "so prefer guiding questions and small steps over pasting the whole answer.",
    ]
    return "\n".join(lines)


def _ai_or_error(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs), None
    except RuntimeError as exc:
        msg = str(exc)
        if msg == "NO_API_KEY":
            return None, ("No API key configured. Open Settings and paste a Groq API key "
                          "(free at console.groq.com/keys) to unlock AI hints, reviews and the tutor.")
        return None, msg


# --------------------------------------------------------------------------- #
#  Code execution
# --------------------------------------------------------------------------- #
def worker_env() -> dict:
    """
    Environment for the test worker.

    In a one-file build the child would otherwise re-extract the whole bundle to
    a fresh temp directory (slow: hundreds of MB). PyInstaller's bootloader skips
    extraction when these two variables point at the parent's own unpacked dir.
    """
    env = os.environ.copy()
    if FROZEN:
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            env["_PYI_PARENT_PROCESS_LEVEL"] = "1"
            env["_PYI_APPLICATION_HOME_DIR"] = meipass
    return env


def worker_command() -> list[str]:
    """Command that starts a test worker; `--serve` keeps it alive between runs."""
    if FROZEN:
        return [sys.executable, "--tf-worker", "--serve"]
    return [sys.executable, str(Path(__file__).resolve().parent / "runner.py"), "--serve"]


class Worker:
    """
    A warm, long-lived test process.

    Keeping one interpreter alive means torch is imported once instead of on every
    Run click (on Windows that saves several seconds per attempt). If a submission
    hangs, crashes the interpreter or blows up memory, the process is killed and a
    fresh one is started for the next run.
    """

    MARKER = "@@TF@@"

    def __init__(self) -> None:
        self.proc: subprocess.Popen | None = None
        self.lock = threading.Lock()
        self.jobs = 0

    # -- lifecycle ---------------------------------------------------------
    def _spawn(self) -> None:
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            self.proc = subprocess.Popen(
                worker_command(),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                cwd=str(DATA_DIR),
                creationflags=flags,
                env=worker_env(),
            )
            self.jobs = 0
        except Exception:
            self.proc = None

    def _kill(self) -> None:
        proc, self.proc = self.proc, None
        if proc is None:
            return
        try:
            proc.kill()
        except Exception:
            pass
        try:
            proc.wait(timeout=5)
        except Exception:
            pass

    def warm(self) -> None:
        """Start (and pre-import torch in) the worker before the first request."""
        with self.lock:
            if self.proc is None or self.proc.poll() is not None:
                self._spawn()

    def shutdown(self) -> None:
        with self.lock:
            self._kill()

    # -- execution ---------------------------------------------------------
    def run(self, payload: dict, timeout: int = RUN_TIMEOUT) -> dict | None:
        with self.lock:
            recyclable = self.jobs >= 10  # bound memory growth from user code
            if self.proc is None or self.proc.poll() is not None or recyclable:
                self._kill()
                self._spawn()
            if self.proc is None:
                return None

            line = (json.dumps(payload) + "\n").encode("utf-8")
            box: queue.Queue = queue.Queue()

            def reader(stream):
                """Read lines until a real result arrives (skips the READY banner)."""
                for _ in range(40):
                    try:
                        raw_line = stream.readline()
                    except Exception:
                        raw_line = b""
                    if not raw_line:
                        box.put(b"")
                        return
                    if raw_line.startswith(self.MARKER.encode()):
                        box.put(raw_line)
                        return

            try:
                self.proc.stdin.write(line)
                self.proc.stdin.flush()
            except Exception:
                self._kill()
                return None

            threading.Thread(target=reader, args=(self.proc.stdout,), daemon=True).start()
            try:
                raw = box.get(timeout=timeout)
            except queue.Empty:
                self._kill()
                return {"ok": False,
                        "compile_error": f"Timed out after {timeout}s. Is there an infinite loop?",
                        "results": [], "figures": [], "stdout": "", "timed_out": True}

            self.jobs += 1
            if not raw:
                # the interpreter died mid-submission (os._exit, segfault, OOM kill)
                self._kill()
                return {"ok": False,
                        "compile_error": (
                            "Your code terminated the Python process (for example via "
                            "os._exit(), a segfault in native code, or running out of memory). "
                            "Remove that and run again."),
                        "results": [], "figures": [], "stdout": "", "crashed": True}
            text = raw.decode("utf-8", "replace").strip()
            if text.startswith(self.MARKER):
                text = text[len(self.MARKER):]
            try:
                return json.loads(text)
            except Exception:
                self._kill()
                return None


WORKER = Worker()
atexit.register(WORKER.shutdown)


def run_submission(item: dict, source: str) -> dict:
    payload = {
        "source": source,
        "checks": [{"name": c["name"], "kind": c["kind"], "source": c["source"], "n": c["n"]}
                   for c in item["checks"]],
    }
    t0 = time.time()
    res = WORKER.run(payload)
    if res is None:
        # could not start / talk to the worker at all — retry once with a cold start
        WORKER.warm()
        res = WORKER.run(payload)
    if res is None:
        res = {"ok": False,
               "compile_error": "The test runner could not be started. Try restarting TensorForge.",
               "results": [], "figures": [], "stdout": ""}
    res["time_ms"] = int((time.time() - t0) * 1000)
    return res


def record_progress(item: dict, code: str, ok: bool) -> None:
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        row = conn.execute("SELECT status, attempts FROM progress WHERE pid = ?",
                           (item["id"],)).fetchone()
        attempts = (row["attempts"] if row else 0) + 1
        status = "solved" if ok else ((row["status"] if row else "attempted") or "attempted")
        if status != "solved":
            status = "solved" if (row and row["status"] == "solved") else "attempted"
        solved_at = now if (ok or (row and row["status"] == "solved")) else None
        conn.execute(
            "INSERT INTO progress(pid, status, attempts, solved_at, last_code, updated_at) "
            "VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(pid) DO UPDATE SET status=excluded.status, attempts=excluded.attempts, "
            "solved_at=COALESCE(progress.solved_at, excluded.solved_at), "
            "last_code=excluded.last_code, updated_at=excluded.updated_at",
            (item["id"], status, attempts, solved_at, code, now),
        )


def _log(msg: str) -> None:
    """Console output is unavailable in a windowed build — also log to a file."""
    try:
        if sys.stdout is not None:
            print(msg, flush=True)
    except Exception:
        pass
    try:
        with open(DATA_DIR / "tensorforge.log", "a", encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass


# --------------------------------------------------------------------------- #
#  Static UI
# --------------------------------------------------------------------------- #
@app.get("/")
def index():
    return send_from_directory(BASE_DIR / "templates", "index.html")


@app.errorhandler(Exception)
def _json_errors(exc):
    """Never hand the single-page app an HTML error page."""
    if isinstance(exc, HTTPException):
        return jsonify({"error": exc.description or exc.name}), exc.code
    app.logger.exception("unhandled error")
    _log(f"ERROR {type(exc).__name__}: {exc}")
    return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 500


@app.get("/download/windows")
def download_windows():
    """Offer the built Windows executable for download (source checkout only)."""
    if not WINDOWS_EXE.exists():
        return jsonify({"error": "No Windows build found in this copy. "
                                 "Run build_windows.bat (or the GitHub workflow) first."}), 404
    return send_file(WINDOWS_EXE, as_attachment=True, download_name="TensorForge.exe",
                     mimetype="application/vnd.microsoft.portable-executable")


@app.get("/favicon.ico")
def favicon():
    return Response(status=204)


# --------------------------------------------------------------------------- #
#  Concept groups
#
#  The bank contains three generated variants per concept ("Trig identities #1..#3").
#  Students should see ONE row per concept and pick a variant inside it, so the
#  list is grouped here and only expanded on request.
# --------------------------------------------------------------------------- #
def _build_concepts() -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = {}
    for topic_items in _BY_TOPIC.values():
        for it in topic_items:
            groups.setdefault(it.get("concept") or it["id"], []).append(it)
    for key, items in groups.items():
        items.sort(key=lambda i: i["id"])
    return groups


CONCEPTS = _build_concepts()
CONCEPT_OF: dict[str, str] = {it["id"]: c for c, items in CONCEPTS.items() for it in items}

TOPIC_ORDER = ["torch", "numpy", "python", "matplotlib"]


def _group_state(items: list[dict], progress: dict, notes: dict) -> dict:
    solved = sum(1 for i in items if progress.get(i["id"], {}).get("status") == "solved")
    attempted = sum(1 for i in items if progress.get(i["id"], {}).get("status") == "attempted")
    starred = any(notes.get(i["id"], {}).get("bookmark") for i in items)
    if solved >= len(items):
        status = "solved"
    elif solved:
        status = "partial"
    elif attempted:
        status = "attempted"
    else:
        status = "new"
    return {"solved": solved, "attempted": attempted, "starred": starred, "status": status}


def _row(items: list[dict], progress: dict, notes: dict) -> dict:
    rep = items[0]
    st = _group_state(items, progress, notes)
    return {
        "id": rep["id"],
        "title": rep["title"].rsplit(" #", 1)[0],
        "topic": rep["topic"],
        "difficulty": rep["difficulty"],
        "tags": rep["tags"][:3],
        "variants": len(items),
        "variant_ids": [i["id"] for i in items],
        **st,
    }


def _filtered_rows(*, topic="", difficulty="", status="", q="", expand=False) -> list[dict]:
    progress, notes = progress_map(), notes_map()
    rows = []
    for concept, items in CONCEPTS.items():
        rep = items[0]
        if topic and rep["topic"] != topic:
            continue
        if difficulty and rep["difficulty"] != difficulty:
            continue
        row = _row(items, progress, notes)
        if status == "solved" and row["status"] != "solved":
            continue
        if status == "partial" and row["status"] != "partial":
            continue
        if status == "unsolved" and row["status"] in ("solved", "partial"):
            continue
        if status == "attempted" and row["status"] != "attempted":
            continue
        if status == "starred" and not row["starred"]:
            continue
        if q and q not in row["title"].lower() and not any(q in t for t in rep["tags"]) \
                and q not in concept:
            continue
        if expand:
            for it in items:
                single = _row([it], progress, notes)
                single["variants"] = 1
                single["concept"] = concept
                rows.append(single)
        else:
            row["concept"] = concept
            rows.append(row)
    rows.sort(key=lambda r: (TOPIC_ORDER.index(r["topic"]) if r["topic"] in TOPIC_ORDER else 9,
                             DIFF_ORDER.get(r["difficulty"], 9), r["title"].lower()))
    return rows


def _streak_and_recent() -> dict:
    with db() as conn:
        rows = conn.execute(
            "SELECT pid, status, MAX(updated_at) AS ts FROM progress "
            "WHERE updated_at IS NOT NULL GROUP BY pid ORDER BY ts DESC").fetchall()
    days = sorted({r["ts"][:10] for r in rows if r["ts"]}, reverse=True)
    streak = 0
    if days:
        from datetime import date, timedelta
        today = date.today()
        d = today if days[0] == str(today) else today - timedelta(days=1)
        have = set(days)
        while str(d) in have:
            streak += 1
            d -= timedelta(days=1)
    # longest run of consecutive days ever (for the "best streak" card)
    best = 0
    if days:
        from datetime import date, timedelta
        ordered = sorted(days)
        run = 1
        best = 1
        for prev, cur in zip(ordered, ordered[1:]):
            gap = (date.fromisoformat(cur) - date.fromisoformat(prev)).days
            run = run + 1 if gap == 1 else 1
            best = max(best, run)
    recent = []
    for r in rows[:8]:
        item = _BANK.get(r["pid"])
        if not item:
            continue
        recent.append({"id": item["id"], "title": item["title"].rsplit(" #", 1)[0],
                       "topic": item["topic"], "difficulty": item["difficulty"],
                       "status": r["status"], "when": r["ts"]})
    return {"streak": streak, "max_streak": max(best, streak), "recent": recent}


# --------------------------------------------------------------------------- #
#  API: home / browsing
# --------------------------------------------------------------------------- #
@app.get("/api/home")
def api_home():
    progress, notes = progress_map(), notes_map()
    topics = []
    for topic in TOPIC_ORDER:
        items = _BY_TOPIC.get(topic, [])
        if not items:
            continue
        concepts = [c for c, its in CONCEPTS.items() if its[0]["topic"] == topic]
        solved = sum(1 for c in concepts if _group_state(CONCEPTS[c], progress, notes)["status"] == "solved")
        diff = {d: sum(1 for c in concepts if CONCEPTS[c][0]["difficulty"] == d) for d in DIFF_ORDER}
        meta = TOPIC_META.get(topic, {"label": topic.title(), "icon": "*", "accent": "#64748b"})
        topics.append({"id": topic, "label": meta["label"], "icon": meta["icon"],
                       "accent": meta["accent"], "count": len(concepts),
                       "problems": len(items), "solved": solved, "difficulty": diff})

    all_concepts = list(CONCEPTS.values())
    _states = [_group_state(its, progress, notes)["status"] for its in all_concepts]
    total_solved = sum(1 for st in _states if st == "solved")
    total_in_progress = sum(1 for st in _states if st in ("attempted", "partial"))
    all_items = [it for t in _BY_TOPIC.values() for it in t]
    stats = _streak_and_recent()
    cfg = ai_settings()

    # solved-per-day for the last 14 days (for the activity strip)
    with db() as conn:
        rows = conn.execute(
            "SELECT substr(updated_at,1,10) AS d, COUNT(*) AS n FROM progress "
            "WHERE status='solved' AND updated_at IS NOT NULL "
            "GROUP BY d ORDER BY d DESC LIMIT 14").fetchall()
    daily = {r["d"]: r["n"] for r in rows}

    return jsonify({
        "topics": topics,
        "total_concepts": len(all_concepts),
        "total_problems": len(all_items),
        "solved_concepts": total_solved,
        "in_progress_concepts": total_in_progress,
        "solved_problems": sum(1 for it in all_items
                               if progress.get(it["id"], {}).get("status") == "solved"),
        "attempted": sum(1 for p in progress.values() if p["status"] == "attempted"),
        "bookmarks": sum(1 for n in notes.values() if n.get("bookmark")),
        "streak": stats["streak"],
        "max_streak": stats["max_streak"],
        "recent": stats["recent"],
        "daily": daily,
        "ai": {"configured": bool(cfg["api_key"]), "model": cfg["model"],
               "key_hint": ("\u2026" + cfg["api_key"][-4:]) if cfg["api_key"] else ""},
        "exe": {"available": WINDOWS_EXE.exists(),
                "size_mb": round(WINDOWS_EXE.stat().st_size / (1024 * 1024)) if WINDOWS_EXE.exists() else 0},
        "analysis": _get_cached_analysis(),
        "version": "1.2.0",
        "data_dir": str(DATA_DIR),
    })


@app.get("/api/bootstrap")           # kept for older clients
def api_bootstrap():
    return api_home()


@app.get("/api/problems")
def api_problems():
    rows = _filtered_rows(
        topic=request.args.get("topic", "").strip(),
        difficulty=request.args.get("difficulty", "").strip(),
        status=request.args.get("status", "").strip(),
        q=request.args.get("q", "").strip().lower(),
        expand=request.args.get("variants", "0") == "1",
    )
    if request.args.get("shuffle") == "1":
        import random as _random
        _random.shuffle(rows)
    total = len(rows)
    offset = int(request.args.get("offset", 0))
    limit = min(int(request.args.get("limit", 4000)), 5000)
    return jsonify({"total": total, "items": rows[offset:offset + limit]})


@app.get("/api/problem/<pid>")
def api_problem(pid: str):
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "not found"}), 404
    concept = CONCEPT_OF.get(pid, pid)
    variants = CONCEPTS.get(concept, [item])
    progress, notes = progress_map(), notes_map()
    with db() as conn:
        row = conn.execute("SELECT status, attempts, last_code FROM progress WHERE pid = ?",
                           (pid,)).fetchone()
        note = conn.execute("SELECT note, bookmark FROM notes WHERE pid = ?", (pid,)).fetchone()
    return jsonify({
        "id": item["id"],
        "concept": concept,
        "title": item["title"].rsplit(" #", 1)[0],
        "subtitle": item["title"],
        "topic": item["topic"],
        "difficulty": item["difficulty"],
        "tags": item["tags"],
        "ask": item["ask"],
        "sig": item["sig"],
        "starter": item["starter"],
        "example": item.get("example"),
        "hints": item["hints"],
        "checks": [c["name"] for c in item["checks"]],
        "variants": [{"id": v["id"], "label": v["title"].rsplit(" #", 1)[-1] if " #" in v["title"] else "1",
                      "status": progress.get(v["id"], {}).get("status", "new")} for v in variants],
        "attempts": row["attempts"] if row else 0,
        "status": (row["status"] if row else "new"),
        "last_code": (row["last_code"] if row else "") or item["starter"],
        "note": (note["note"] if note else "") or "",
        "bookmarked": bool(note["bookmark"]) if note else False,
        "weak": bool(item.get("weak")),
    })


@app.get("/api/random")
def api_random():
    topic = request.args.get("topic", "").strip()
    difficulty = request.args.get("difficulty", "").strip()
    only_unsolved = request.args.get("unsolved", "1") == "1"
    status = "unsolved" if only_unsolved else ""
    rows = _filtered_rows(topic=topic, difficulty=difficulty, status=status)
    if not rows and only_unsolved:
        rows = _filtered_rows(topic=topic, difficulty=difficulty)
    if not rows:
        return jsonify({"error": "no problems match those filters"}), 404
    import random as _random
    choice = _random.choice(rows)
    return jsonify({"id": choice["id"], "variants": choice.get("variant_ids", [choice["id"]])})


@app.get("/api/solution/<pid>")
def api_solution(pid: str):
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "not found"}), 404
    return jsonify({"code": item["solution"], "title": item["title"]})


@app.get("/api/reference/<pid>")
def api_reference(pid: str):
    """Run the reference solution and return its figures (used for plot problems)."""
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "not found"}), 404
    res = run_submission(item, item["solution"])
    if not res.get("ok"):
        return jsonify({"error": res.get("compile_error") or "reference failed"}), 500
    return jsonify({"figures": res.get("figures", [])[:1]})


@app.get("/api/search")
def api_search():
    q = request.args.get("q", "").strip().lower()
    if not q:
        return jsonify({"items": []})
    rows = _filtered_rows(q=q)[:40]
    return jsonify({"items": [{"id": r["id"], "title": r["title"], "topic": r["topic"],
                              "difficulty": r["difficulty"]} for r in rows]})


# --------------------------------------------------------------------------- #
#  API: execution
# --------------------------------------------------------------------------- #
@app.post("/api/run")
def api_run():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    code = body.get("code", "")
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    if not code.strip():
        return jsonify({"ok": False, "compile_error": "Write some code first 🙂",
                        "results": []})
    res = run_submission(item, code)
    record_progress(item, code, bool(res.get("ok")))
    res["status"] = "solved" if res.get("ok") else "attempted"
    return jsonify(res)


@app.post("/api/save")
def api_save():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    code = body.get("code", "")
    if pid not in _BANK:
        return jsonify({"ok": False}), 404
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        conn.execute(
            "INSERT INTO progress(pid, status, attempts, last_code, updated_at) "
            "VALUES(?, 'attempted', 0, ?, ?) "
            "ON CONFLICT(pid) DO UPDATE SET last_code=excluded.last_code, updated_at=excluded.updated_at",
            (pid, code, now),
        )
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- #
#  API: notes (local problem notes + global markdown notebook) & bookmarks
# --------------------------------------------------------------------------- #
@app.post("/api/note")
def api_note():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    if pid not in _BANK:
        return jsonify({"ok": False}), 404
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        row = conn.execute("SELECT note, bookmark FROM notes WHERE pid = ?", (pid,)).fetchone()
        note = body.get("note", row["note"] if row else "")
        bookmark = int(body.get("bookmark", row["bookmark"] if row else 0))
        conn.execute(
            "INSERT INTO notes(pid, note, bookmark, updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(pid) DO UPDATE SET note=excluded.note, bookmark=excluded.bookmark, "
            "updated_at=excluded.updated_at",
            (pid, note, bookmark, now),
        )
    return jsonify({"ok": True, "bookmark": bool(bookmark), "note": note})


@app.get("/api/global-note")
def api_global_note_get():
    return jsonify({
        "content": get_global_note(),
        "updated_at": get_setting("global_note_updated", ""),
    })


@app.post("/api/global-note")
def api_global_note_post():
    body = request.get_json(force=True, silent=True) or {}
    content = str(body.get("content", ""))
    if not content.strip():
        content = DEFAULT_GLOBAL_NOTE
    ts = save_global_note(content)
    return jsonify({"ok": True, "content": content, "updated_at": ts})


@app.get("/api/global-note/download")
def api_global_note_download():
    content = get_global_note()
    return Response(
        content,
        mimetype="text/markdown; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=tensorforge-notes.md"},
    )


NOTE_AI_SYSTEM = (
    "You are TensorForge's cheat-sheet note formatter. "
    "Format a single concise takeaway bullet in Markdown without altering any existing notes. "
    "Line 1 MUST be: SECTION: <PyTorch|NumPy|Python|Matplotlib|General & Gotchas>\n"
    "Line 2+ MUST be a single bullet in this exact arrow style, plus a 1-2 line code example:\n"
    "- **`<API or concept>`** --> <what to remember / rule> -> `<key types / args / options>`\n"
    "  ```python\n"
    "  # 1-2 line example\n"
    "  ```\n"
    "Keep it under 65 words total. Output ONLY Line 1 (SECTION:) and the bullet."
)


def _infer_topic_from_text(text: str) -> str:
    low = text.lower()
    if any(k in low for k in ("torch", "tensor", "nn.", "autograd", "cuda", "dtype")):
        return "torch"
    if any(k in low for k in ("np.", "numpy", "ndarray", "linspace", "arange")):
        return "numpy"
    if any(k in low for k in ("plt.", "matplotlib", "subplot", "figsize", "ax.")):
        return "matplotlib"
    if any(k in low for k in ("dict", "comprehension", "itertools", "decorator", "generator", "python")):
        return "python"
    return "general"


def _fallback_note_entry(item: dict | None, raw_note: str, prompt: str) -> tuple[str, str]:
    text = (prompt or raw_note or "").strip()
    topic = (item["topic"] if item else "") or _infer_topic_from_text(text)
    section = _normalize_section(topic, topic)
    if item and not text:
        title = item["title"].rsplit(" #", 1)[0]
        sig = item.get("sig", "").strip()
        hint = (item.get("hints") or [""])[0]
        sol_lines = [ln for ln in (item.get("solution") or "").strip().splitlines() if ln.strip()][:2]
        code_snip = "\n  ".join(sol_lines) if sol_lines else sig
        entry = f"- **`{title}`** --> {hint or item['ask'][:100]} -> `{sig}`\n  ```python\n  {code_snip}\n  ```"
        return section, entry
    # If user already wrote arrow syntax or plain text, wrap cleanly
    first_line, *rest = text.splitlines()
    if "-->" in first_line or "->" in first_line:
        bullet = first_line if first_line.startswith(("-", "*")) else f"- {first_line}"
    elif item:
        title = item["title"].rsplit(" #", 1)[0]
        bullet = f"- **`{title}`** --> {first_line}"
    else:
        bullet = first_line if first_line.startswith(("-", "*")) else f"- {first_line}"
    if rest:
        code_block = "\n".join("  " + ln for ln in rest if ln.strip())
        if "```" not in code_block:
            bullet += f"\n  ```python\n{code_block}\n  ```"
        else:
            bullet += "\n" + code_block
    return section, bullet


def _generate_note_entry(item: dict | None, raw_note: str, prompt: str, code: str = "",
                         target_section: str = "") -> tuple[str, str, str, str | None]:
    """Return (section, entry_markdown, source, error_or_none)."""
    ctx_parts = []
    if item:
        ctx_parts.append(
            f"Problem: {item['title'].rsplit(' #', 1)[0]} (track: {item['topic']}, tags: {', '.join(item['tags'])})\n"
            f"Signature: {item['sig']}\n"
            f"Reference solution:\n{item.get('solution', '')[:500]}"
        )
    if code.strip():
        ctx_parts.append(f"Learner code:\n{code[:600]}")
    if raw_note.strip():
        ctx_parts.append(f"Learner local note:\n{raw_note[:800]}")
    if prompt.strip():
        ctx_parts.append(f"Learner instruction:\n{prompt[:600]}")
    if not ctx_parts:
        ctx_parts.append("Create a concise PyTorch dtype casting cheat-sheet entry.")

    messages = [
        {"role": "system", "content": NOTE_AI_SYSTEM},
        {"role": "user", "content": "\n\n".join(ctx_parts)},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=220, temperature=0.3)
    if err or not text:
        sec, entry = _fallback_note_entry(item, raw_note, prompt)
        if target_section:
            sec = _normalize_section(target_section, sec)
        return sec, entry, "fallback", err

    lines = [ln for ln in text.strip().splitlines() if ln.strip()]
    sec = _normalize_section(item["topic"] if item else "general")
    if lines and lines[0].upper().startswith("SECTION:"):
        sec = _normalize_section(lines[0].split(":", 1)[1], sec)
        lines = lines[1:]
    if target_section:
        sec = _normalize_section(target_section, sec)
    entry = "\n".join(lines).strip()
    if not entry:
        sec, entry = _fallback_note_entry(item, raw_note, prompt)
        return sec, entry, "fallback", None
    return sec, entry, "ai", None


@app.post("/api/note/ai")
def api_note_ai():
    """
    AI helper for both Local Problem Notes and the Global Markdown Notebook.
    - mode='local': formats/enhances the local problem note and saves it.
    - mode='to_global' (default): generates a structured cheat-sheet bullet
      (`--> ... -> ...` + short example) and inserts it into the matching
      section of the Global Note without disturbing existing content.
    """
    body = request.get_json(force=True, silent=True) or {}
    mode = body.get("mode", "to_global")
    pid = body.get("id", "")
    item = _BANK.get(pid) if pid else None
    raw_note = str(body.get("note", ""))
    prompt = str(body.get("prompt", ""))
    code = str(body.get("code", ""))
    target_section = str(body.get("section", ""))

    sec, entry, source, err = _generate_note_entry(item, raw_note, prompt, code, target_section)

    now = time.strftime("%Y-%m-%d %H:%M:%S")
    local_note = raw_note
    if mode == "local" and item:
        local_note = (raw_note.rstrip() + "\n\n" + entry).strip() if raw_note.strip() and prompt.strip() else entry
        with db() as conn:
            row = conn.execute("SELECT bookmark FROM notes WHERE pid = ?", (pid,)).fetchone()
            bmk = int(row["bookmark"]) if row else 0
            conn.execute(
                "INSERT INTO notes(pid, note, bookmark, updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(pid) DO UPDATE SET note=excluded.note, updated_at=excluded.updated_at",
                (pid, local_note, bmk, now),
            )
        return jsonify({
            "ok": True,
            "mode": "local",
            "section": sec,
            "entry": entry,
            "local_note": local_note,
            "source": source,
            "error": err,
        })

    # mode == 'to_global': insert into Global Note without altering existing structure
    current_global = get_global_note()
    updated_global = _insert_into_global_note(current_global, sec, entry)
    ts = save_global_note(updated_global)

    # If invoked from a problem and local note was empty or user asked to sync, also save local note
    if item and body.get("sync_local", True):
        if not raw_note.strip():
            local_note = entry
        with db() as conn:
            row = conn.execute("SELECT bookmark FROM notes WHERE pid = ?", (pid,)).fetchone()
            bmk = int(row["bookmark"]) if row else 0
            conn.execute(
                "INSERT INTO notes(pid, note, bookmark, updated_at) VALUES(?,?,?,?) "
                "ON CONFLICT(pid) DO UPDATE SET note=excluded.note, updated_at=excluded.updated_at",
                (pid, local_note, bmk, now),
            )

    return jsonify({
        "ok": True,
        "mode": "to_global",
        "section": sec,
        "entry": entry,
        "global_note": updated_global,
        "local_note": local_note,
        "updated_at": ts,
        "source": source,
        "error": err,
    })


# --------------------------------------------------------------------------- #
#  API: AI Progress Analyser (token-efficient diagnostic & study planner)
# --------------------------------------------------------------------------- #
def _get_cached_analysis() -> dict | None:
    raw = get_setting("progress_analysis", "")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def _build_progress_digest() -> dict:
    """
    Build a compact statistical summary of the user's progress so the AI
    analyser uses <250 input tokens even across a 2,049-problem bank.
    """
    progress, notes = progress_map(), notes_map()
    by_track = {}
    tag_solved: dict[str, int] = {}
    tag_total: dict[str, int] = {}
    tag_failed: dict[str, int] = {}
    struggled = []
    recent_solved = []

    with db() as conn:
        recent_rows = conn.execute(
            "SELECT pid, status, attempts, updated_at FROM progress "
            "ORDER BY updated_at DESC LIMIT 40"
        ).fetchall()

    for topic in TOPIC_ORDER:
        concepts = [c for c, its in CONCEPTS.items() if its[0]["topic"] == topic]
        diff_tot = {d: 0 for d in DIFF_ORDER}
        diff_sol = {d: 0 for d in DIFF_ORDER}
        sol_c = 0
        att_c = 0
        for c in concepts:
            its = CONCEPTS[c]
            d = its[0]["difficulty"]
            diff_tot[d] = diff_tot.get(d, 0) + 1
            st = _group_state(its, progress, notes)["status"]
            if st == "solved":
                sol_c += 1
                diff_sol[d] = diff_sol.get(d, 0) + 1
            elif st in ("attempted", "partial"):
                att_c += 1
            for t in its[0].get("tags", [])[:3]:
                tag_total[t] = tag_total.get(t, 0) + 1
                if st == "solved":
                    tag_solved[t] = tag_solved.get(t, 0) + 1
                elif st in ("attempted", "partial"):
                    tag_failed[t] = tag_failed.get(t, 0) + 1
        by_track[topic] = {
            "label": TOPIC_META.get(topic, {}).get("label", topic),
            "solved": sol_c,
            "attempted": att_c,
            "total": len(concepts),
            "pct": round(sol_c / len(concepts) * 100, 1) if concepts else 0.0,
            "easy": f"{diff_sol['easy']}/{diff_tot['easy']}",
            "medium": f"{diff_sol['medium']}/{diff_tot['medium']}",
            "hard": f"{diff_sol['hard']}/{diff_tot['hard']}",
        }

    for r in recent_rows:
        it = _BANK.get(r["pid"])
        if not it:
            continue
        title = it["title"].rsplit(" #", 1)[0]
        if r["status"] == "solved" and len(recent_solved) < 8:
            if title not in recent_solved:
                recent_solved.append(f"{title} ({it['topic']}/{it['difficulty']})")
        elif r["status"] != "solved" and len(struggled) < 6:
            struggled.append(f"{title} ({it['topic']}/{it['difficulty']}, {r['attempts']} tries)")

    strong_tags = sorted(
        [(t, n, tag_total.get(t, n)) for t, n in tag_solved.items() if n > 0],
        key=lambda x: (-x[1], -x[1] / max(x[2], 1)),
    )[:6]
    weak_tags = sorted(
        [(t, tag_failed.get(t, 0), tag_solved.get(t, 0), tot)
         for t, tot in tag_total.items() if tot >= 4 and tag_solved.get(t, 0) == 0],
        key=lambda x: (-x[1], -x[3]),
    )[:6]

    # Pick 3 concrete next problems to recommend
    recs = []
    seen_concepts = set()
    # 1) Retry an attempted/struggled concept if any
    for r in recent_rows:
        if r["status"] != "solved" and r["pid"] in _BANK:
            it = _BANK[r["pid"]]
            c = CONCEPT_OF.get(it["id"], it["id"])
            if c not in seen_concepts:
                seen_concepts.add(c)
                recs.append({
                    "id": it["id"],
                    "title": it["title"].rsplit(" #", 1)[0],
                    "topic": it["topic"],
                    "difficulty": it["difficulty"],
                    "reason": f"Finish this in-progress {it['topic']} concept ({r['attempts']} attempt{'s' if r['attempts'] != 1 else ''})",
                })
                break

    # 2) Weakest / least-practiced tracks
    tracks_by_pct = sorted(TOPIC_ORDER, key=lambda t: (by_track[t]["pct"], TOPIC_ORDER.index(t)))
    for t in tracks_by_pct:
        if len(recs) >= 3:
            break
        target_diff = "easy" if by_track[t]["solved"] < 5 else "medium"
        for c, its in CONCEPTS.items():
            if c in seen_concepts or its[0]["topic"] != t or its[0]["difficulty"] != target_diff:
                continue
            if _group_state(its, progress, notes)["status"] == "new":
                seen_concepts.add(c)
                recs.append({
                    "id": its[0]["id"],
                    "title": its[0]["title"].rsplit(" #", 1)[0],
                    "topic": t,
                    "difficulty": target_diff,
                    "reason": f"Build coverage in {by_track[t]['label']} ({target_diff})",
                })
                break

    total_solved = sum(v["solved"] for v in by_track.values())
    total_concepts = sum(v["total"] for v in by_track.values())
    total_attempted = sum(v["attempted"] for v in by_track.values())

    compact_lines = [
        f"Overall: {total_solved}/{total_concepts} concepts solved, {total_attempted} in-progress.",
        "Tracks: " + "; ".join(
            f"{k}: {v['solved']}/{v['total']} (E:{v['easy']} M:{v['medium']} H:{v['hard']})"
            for k, v in by_track.items()
        ),
        "Strongest tags: " + (", ".join(f"{t}({s}/{tot})" for t, s, tot in strong_tags) or "none yet"),
        "Unexplored/weak tags: " + (", ".join(f"{t}(0/{tot}, {f} failed)" for t, f, _, tot in weak_tags) or "none"),
        "Recent solved: " + (", ".join(recent_solved) or "none yet"),
        "Struggled/in-progress: " + (", ".join(struggled) or "none"),
    ]
    return {
        "total_solved": total_solved,
        "total_concepts": total_concepts,
        "total_attempted": total_attempted,
        "by_track": by_track,
        "strong_tags": [f"{t} ({s}/{tot})" for t, s, tot in strong_tags],
        "weak_tags": [t for t, _, _, _ in weak_tags],
        "recent_solved": recent_solved,
        "struggled": struggled,
        "recommendations": recs[:3],
        "prompt_digest": "\n".join(compact_lines),
    }


def _fallback_analysis_markdown(digest: dict) -> str:
    sol = digest["total_solved"]
    tot = digest["total_concepts"]
    if sol == 0 and digest["total_attempted"] == 0:
        return (
            "### What You're Good At\n"
            "- Fresh slate! You haven't submitted a problem yet.\n\n"
            "### What to Focus On Next\n"
            "- Start with **PyTorch Easy** (tensor creation & dtype casting) and **NumPy Easy** (indexing & broadcasting) to build momentum.\n\n"
            "### Study Plan\n"
            "- Solve 2 Easy PyTorch + 1 Easy NumPy concept per session, and save key API rules into your **Global Note**."
        )
    bt = digest["by_track"]
    best_t = max(TOPIC_ORDER, key=lambda t: (bt[t]["solved"], -TOPIC_ORDER.index(t)))
    weak_t = min(TOPIC_ORDER, key=lambda t: (bt[t]["pct"], TOPIC_ORDER.index(t)))
    strong_str = ", ".join(digest["strong_tags"][:4]) or f"{bt[best_t]['label']} fundamentals"
    weak_str = ", ".join(digest["weak_tags"][:4]) or f"{bt[weak_t]['label']} concepts"
    strug = ("; ".join(digest["struggled"][:2])) if digest["struggled"] else "moving from Easy to Medium variants"
    return (
        f"### What You're Good At\n"
        f"- **{bt[best_t]['label']}** leads your progress ({bt[best_t]['solved']}/{bt[best_t]['total']} concepts), with solid traction in **{strong_str}**.\n\n"
        f"### What to Focus On Next\n"
        f"- **{bt[weak_t]['label']}** has the most room to grow ({bt[weak_t]['solved']}/{bt[weak_t]['total']}). Target **{weak_str}** and revisit: *{strug}*.\n\n"
        f"### Study Plan\n"
        f"- Complete the 3 recommended problems below, then step up one difficulty tier in **{bt[best_t]['label']}**."
    )


@app.get("/api/analyse-progress")
def api_analyse_progress_get():
    cached = _get_cached_analysis()
    if cached:
        return jsonify(cached)
    digest = _build_progress_digest()
    return jsonify({
        "ok": True,
        "analysis": _fallback_analysis_markdown(digest),
        "recommendations": digest["recommendations"],
        "stats": {
            "solved": digest["total_solved"],
            "total": digest["total_concepts"],
            "strong_tags": digest["strong_tags"],
            "weak_tags": digest["weak_tags"],
        },
        "source": "builtin",
        "tokens_est": 0,
        "generated_at": "",
    })


@app.post("/api/analyse-progress")
def api_analyse_progress_post():
    digest = _build_progress_digest()
    sys_prompt = (
        "You are TensorForge's AI study analyser. Given a compact statistical digest of "
        "the learner's solved and attempted problems, write a high-signal diagnostic in "
        "Markdown under 165 words with these exact 3 headings:\n"
        "### What You're Good At\n"
        "### What to Focus On Next\n"
        "### Study Plan\n"
        "Be concrete about tracks, tags, and difficulty balance. No fluff."
    )
    messages = [
        {"role": "system", "content": sys_prompt},
        {"role": "user", "content": digest["prompt_digest"]},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=300, temperature=0.4)
    source = "ai"
    if err or not text:
        text = _fallback_analysis_markdown(digest)
        source = "builtin"
    tokens_est = 0 if source == "builtin" else (len(sys_prompt + digest["prompt_digest"] + text) // 4 + 30)
    payload = {
        "ok": True,
        "analysis": text.strip(),
        "recommendations": digest["recommendations"],
        "stats": {
            "solved": digest["total_solved"],
            "total": digest["total_concepts"],
            "strong_tags": digest["strong_tags"],
            "weak_tags": digest["weak_tags"],
        },
        "source": source,
        "error": err,
        "tokens_est": tokens_est,
        "generated_at": time.strftime("%Y-%m-%d %H:%M"),
    }
    set_setting("progress_analysis", json.dumps(payload))
    return jsonify(payload)


# --------------------------------------------------------------------------- #
#  API: settings
# --------------------------------------------------------------------------- #
@app.get("/api/settings")
def api_settings_get():
    cfg = ai_settings()
    key = cfg["api_key"]
    return jsonify({
        "api_key_hint": ("…" + key[-4:]) if key else "",
        "has_key": bool(key),
        "model": cfg["model"],
        "base_url": cfg["base_url"],
        "temperature": cfg["temperature"],
        "max_tokens": cfg["max_tokens"],
        "defaults": {"model": DEFAULT_MODEL, "base_url": DEFAULT_BASE_URL},
        "data_dir": str(DATA_DIR),
    })


@app.post("/api/settings")
def api_settings_post():
    body = request.get_json(force=True, silent=True) or {}
    if "api_key" in body:
        key = (body.get("api_key") or "").strip()
        set_setting("api_key", key)
    if body.get("model"):
        set_setting("model", str(body["model"]).strip())
    if body.get("base_url"):
        set_setting("base_url", str(body["base_url"]).strip())
    if "temperature" in body:
        try:
            set_setting("temperature", str(float(body["temperature"])))
        except Exception:
            pass
    if "max_tokens" in body:
        try:
            set_setting("max_tokens", str(int(body["max_tokens"])))
        except Exception:
            pass
    cfg = ai_settings()
    return jsonify({"ok": True, "has_key": bool(cfg["api_key"]),
                    "api_key_hint": ("…" + cfg["api_key"][-4:]) if cfg["api_key"] else ""})


@app.post("/api/settings/test")
def api_settings_test():
    text, err = _ai_or_error(
        ai_complete,
        [{"role": "user", "content": "Reply with exactly: TensorForge ready"}],
        max_tokens=16, temperature=0.0,
    )
    if err:
        return jsonify({"ok": False, "error": err})
    return jsonify({"ok": True, "reply": (text or "").strip()[:120]})


@app.get("/api/models")
def api_models():
    cfg = ai_settings()
    if not cfg["api_key"]:
        return jsonify({"ok": False, "error": "NO_API_KEY"})
    try:
        req = urllib.request.Request(
            cfg["base_url"] + "/models",
            headers={"Authorization": "Bearer " + cfg["api_key"],
                     "User-Agent": "TensorForge/1.0"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        ids = sorted(m["id"] for m in data.get("data", []) if m.get("id"))
        return jsonify({"ok": True, "models": ids})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:300]})


# --------------------------------------------------------------------------- #
#  API: AI features
# --------------------------------------------------------------------------- #
HINT_SYSTEM = (
    "You are TensorForge's PyTorch/NumPy coach. You give graded hints that help a "
    "learner get unstuck without handing them the answer. Keep the reply under 130 "
    "words, plain markdown, no preamble."
)


@app.post("/api/hint")
def api_hint():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    level = int(body.get("level", 1))
    static_hints = item.get("hints", [])
    fallback = static_hints[min(level - 1, len(static_hints) - 1)] if static_hints else ""

    messages = [
        {"role": "system", "content": HINT_SYSTEM},
        {"role": "user", "content": problem_context(item, code=body.get("code", ""))
         + f"\n\nGive hint #{level} of 3: hint 1 = a nudge about the concept, hint 2 = the "
           f"concrete approach/API to use, hint 3 = the precise gotcha that usually breaks it. "
           f"Do not write the full solution."},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=350)
    if err:
        return jsonify({"hint": fallback, "source": "builtin", "error": err})
    return jsonify({"hint": text.strip(), "source": "ai"})


REVIEW_SYSTEM = (
    "You are a senior deep-learning engineer reviewing a learner's attempt in a "
    "practice app. Be specific and kind. Structure: **What happened**, **Why**, "
    "**Fix** (1-3 bullets, tiny code snippet only if essential), **Try next**. "
    "Under 220 words."
)


@app.post("/api/review")
def api_review():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    results = body.get("results", [])
    failures = [r for r in results if not r.get("passed")]
    detail = json.dumps([{k: r.get(k) for k in ("name", "passed", "message")} for r in results],
                        indent=1)[:4000]
    messages = [
        {"role": "system", "content": REVIEW_SYSTEM},
        {"role": "user", "content": problem_context(item, code=body.get("code", ""))
         + ("\n\nTest results:\n" + detail if results else "\n\nNo test run yet.")
         + ("\n\nFocus on the first failing check." if failures else "")},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=600)
    if err:
        return jsonify({"error": err}), 400
    return jsonify({"review": text.strip()})


@app.post("/api/explain")
def api_explain():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    messages = [
        {"role": "system", "content": (
            "You explain reference solutions to a learner. Walk through the idea, the "
            "shapes, and why each step exists. Then give one 'watch out' note and one "
            "'going further' idea. Under 260 words, markdown.")},
        {"role": "user", "content": problem_context(item, include_solution=True)},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=700)
    if err:
        return jsonify({"error": err}), 400
    return jsonify({"explanation": text.strip()})


@app.post("/api/chat")
def api_chat():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    history = body.get("messages", [])[-12:]
    code = body.get("code", "")
    system = (
        "You are TensorForge's AI tutor for Python, NumPy, PyTorch and Matplotlib. "
        "You answer questions about the current problem, explain concepts, and debug. "
        "Be concise (under 200 words unless code is needed), use markdown, and never "
        "pretend to run code — the learner runs it with the Run tests button."
    )
    sys_msg = {"role": "system", "content": system}
    if item:
        sys_msg["content"] += "\n\n" + problem_context(item, code=code)
        if body.get("reveal_solution"):
            sys_msg["content"] += "\n\nReference solution:\n```python\n" + item["solution"][:3000] + "\n```"
    messages = [sys_msg] + [{"role": m.get("role", "user"), "content": str(m.get("content", ""))[:4000]}
                            for m in history if m.get("content")]

    try:
        gen = ai_complete(messages, stream=True, max_tokens=900)
    except RuntimeError as exc:
        msg = str(exc)
        if msg == "NO_API_KEY":
            msg = ("No API key configured. Open **Settings → AI** and paste a Groq API key "
                   "to chat with the tutor.")
        return jsonify({"error": msg}), 400

    last_user = ""
    for m in reversed(history):
        if m.get("role") == "user" and m.get("content"):
            last_user = str(m["content"])
            break
    import re as _re
    wants_note = bool(_re.search(
        r"\b(add|save|put|write|append)\b[\s\S]{0,40}\b(to|in|into)\b[\s\S]{0,25}\b(my\s+)?(global\s+|local\s+)?(note|notes|notebook|cheat\s*sheet)\b",
        last_user, _re.IGNORECASE
    ))

    def sse():
        try:
            if wants_note:
                sec, entry, src, _ = _generate_note_entry(item, "", last_user, code)
                updated_global = _insert_into_global_note(get_global_note(), sec, entry)
                ts = save_global_note(updated_global)
                yield "data: " + json.dumps({
                    "note_added": {"section": sec, "entry": entry, "updated_at": ts, "global_note": updated_global}
                }) + "\n\n"
            for delta in gen:
                yield "data: " + json.dumps({"delta": delta}) + "\n\n"
        except Exception as exc:  # noqa: BLE001
            yield "data: " + json.dumps({"error": str(exc)[:300]}) + "\n\n"
        yield "data: " + json.dumps({"done": True}) + "\n\n"

    return Response(sse(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# --------------------------------------------------------------------------- #
#  API: progress export / reset
# --------------------------------------------------------------------------- #
@app.post("/api/quit")
def api_quit():
    """Close TensorForge (the packaged app has no console window to Ctrl+C in)."""
    WORKER.shutdown()
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


@app.get("/api/export")
def api_export():
    with db() as conn:
        progress = [dict(r) for r in conn.execute("SELECT * FROM progress").fetchall()]
        notes = [dict(r) for r in conn.execute("SELECT * FROM notes").fetchall()]
    payload = {"app": "TensorForge", "version": "1.2.0",
               "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
               "progress": progress, "notes": notes,
               "global_note": get_global_note()}
    return Response(json.dumps(payload, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=tensorforge-progress.json"})


@app.post("/api/reset")
def api_reset():
    body = request.get_json(force=True, silent=True) or {}
    what = body.get("what", "progress")
    with db() as conn:
        if what == "progress":
            conn.execute("DELETE FROM progress")
        elif what == "notes":
            conn.execute("DELETE FROM notes")
        elif what == "all":
            conn.execute("DELETE FROM progress")
            conn.execute("DELETE FROM notes")
        elif what == "api_key":
            conn.execute("DELETE FROM settings WHERE key = 'api_key'")
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- #
#  Entrypoint
# --------------------------------------------------------------------------- #
def _port_busy(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.4)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def _is_tensorforge(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/home", timeout=2) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return "total_problems" in data and "total_concepts" in data
    except Exception:
        return False


def main() -> None:
    port = 8765
    host = "127.0.0.1"
    open_browser = True
    args = sys.argv[1:]
    for i, a in enumerate(args):
        if a == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
        elif a == "--host" and i + 1 < len(args):
            host = args[i + 1]
        elif a == "--no-browser":
            open_browser = False

    url = f"http://127.0.0.1:{port}"

    # If TensorForge is already up on this port (very common: the user
    # double-clicks the exe twice, or rebuilds while it runs), reuse that
    # instance instead of dying with "Address already in use" in a windowless
    # build — and instead of holding a second lock on the exe.
    if _port_busy(port):
        if _is_tensorforge(port):
            _log(f"  TensorForge is already running on {url} — opening it.")
            if open_browser:
                webbrowser.open(url)
            return
        _log(f"  Port {port} is used by another program. Try: --port {port + 1}")
        return

    _log("=" * 62)
    _log("  TensorForge — PyTorch / NumPy / Python / Matplotlib practice")
    _log("=" * 62)
    _log(f"  {len(_BANK)} problems loaded from {BANK_DIR}")
    _log(f"  Progress + API key stored in: {DATA_DIR}")
    _log(f"  Open: {url}")
    _log("=" * 62)

    threading.Thread(target=WORKER.warm, daemon=True).start()

    if open_browser and host in ("127.0.0.1", "localhost"):
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    app.run(host=host, port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    if "--tf-worker" in sys.argv:
        # Frozen mode: `TensorForge.exe --tf-worker --serve` is the test engine.
        # Keep --serve so the process stays warm between submissions.
        sys.argv = [sys.argv[0]] + [a for a in sys.argv[1:] if a == "--serve"]
        import runner

        runner.main()
    else:
        main()
