"""
TensorForge — a LeetCode-style practice app for Python, NumPy, PyTorch & Matplotlib.

Run:      python app.py                (opens http://127.0.0.1:8765)
Flags:    --port 8765 --host 127.0.0.1 --no-browser
Frozen:   TensorForge.exe             (PyInstaller one-file build)
"""
from __future__ import annotations

import atexit
import json
import os
import queue
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

from flask import Flask, Response, jsonify, request, send_file, send_from_directory
from werkzeug.exceptions import HTTPException

# --------------------------------------------------------------------------- #
#  Paths & configuration
# --------------------------------------------------------------------------- #
FROZEN = bool(getattr(sys, "frozen", False))
BASE_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
APP_DIR = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent


def _data_dir() -> Path:
    env = os.environ.get("TENSORFORGE_HOME")
    if env:
        p = Path(env)
    elif os.name == "nt":
        p = Path(os.environ.get("APPDATA", Path.home())) / "TensorForge"
    elif sys.platform == "darwin":
        p = Path.home() / "Library" / "Application Support" / "TensorForge"
    else:
        p = Path.home() / ".local" / "share" / "tensorforge"
    p.mkdir(parents=True, exist_ok=True)
    return p


DATA_DIR = _data_dir()

if FROZEN:
    # Data files keep their bytes but not always their mode bits; torch's shared
    # memory helper has to stay executable.
    try:
        _shm = Path(getattr(sys, "_MEIPASS", "")) / "torch" / "bin" / "torch_shm_manager"
        if _shm.exists() and not os.access(_shm, os.X_OK):
            os.chmod(_shm, 0o755)
    except Exception:
        pass
DB_PATH = DATA_DIR / "tensorforge.db"
BANK_DIR = BASE_DIR / "bank"
# The Windows build lives next to the source tree (see build_windows.bat)
WINDOWS_EXE = APP_DIR / "dist" / "TensorForge.exe"
if not WINDOWS_EXE.exists():
    WINDOWS_EXE = BASE_DIR / "dist" / "TensorForge.exe"

DEFAULT_BASE_URL = "https://api.groq.com/openai/v1"
DEFAULT_MODEL = "qwen/qwen3.8-27b"
RUN_TIMEOUT = int(os.environ.get("TENSORFORGE_RUN_TIMEOUT", "30"))

app = Flask(__name__, static_folder=str(BASE_DIR / "static"), static_url_path="/static")
app.config["JSON_SORT_KEYS"] = False

# --------------------------------------------------------------------------- #
#  Question bank
# --------------------------------------------------------------------------- #
_BANK: dict[str, dict] = {}
_BY_TOPIC: dict[str, list[dict]] = {}
_BANK_LOCK = threading.Lock()


def load_bank() -> None:
    if _BANK:
        return
    with _BANK_LOCK:
        if _BANK:
            return
        for path in sorted(BANK_DIR.glob("*.json")):
            if path.name == "manifest.json":
                continue
            items = json.loads(path.read_text(encoding="utf-8"))
            topic = path.stem
            _BY_TOPIC.setdefault(topic, []).extend(items)
            for item in items:
                _BANK[item["id"]] = item


load_bank()

TOPIC_META = {
    "python": {"label": "Python", "icon": "🐍", "accent": "#3b82f6"},
    "numpy": {"label": "NumPy", "icon": "🔢", "accent": "#22c55e"},
    "torch": {"label": "PyTorch", "icon": "🔥", "accent": "#f97316"},
    "matplotlib": {"label": "Matplotlib", "icon": "📊", "accent": "#a855f7"},
}
DIFF_ORDER = {"easy": 0, "medium": 1, "hard": 2}

# --------------------------------------------------------------------------- #
#  Database (progress, notes, settings)
# --------------------------------------------------------------------------- #
_DB_LOCK = threading.Lock()


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS progress (
                pid TEXT PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'attempted',
                attempts INTEGER NOT NULL DEFAULT 0,
                solved_at TEXT,
                last_code TEXT,
                updated_at TEXT
            );
            CREATE TABLE IF NOT EXISTS notes (
                pid TEXT PRIMARY KEY,
                note TEXT DEFAULT '',
                bookmark INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            """
        )


init_db()


def get_setting(key: str, default: str = "") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row and row["value"] is not None else default


def set_setting(key: str, value: str) -> None:
    with db() as conn:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


def progress_map() -> dict[str, dict]:
    with db() as conn:
        rows = conn.execute("SELECT pid, status, attempts FROM progress").fetchall()
    return {r["pid"]: dict(r) for r in rows}


def notes_map() -> dict[str, dict]:
    with db() as conn:
        rows = conn.execute("SELECT pid, bookmark FROM notes").fetchall()
    return {r["pid"]: dict(r) for r in rows}


# --------------------------------------------------------------------------- #
#  AI helpers (Groq-compatible chat completions API)
# --------------------------------------------------------------------------- #
def ai_settings() -> dict:
    return {
        "api_key": get_setting("api_key", os.environ.get("GROQ_API_KEY", "")),
        "model": get_setting("model", DEFAULT_MODEL) or DEFAULT_MODEL,
        "base_url": (get_setting("base_url", DEFAULT_BASE_URL) or DEFAULT_BASE_URL).rstrip("/"),
        "temperature": float(get_setting("temperature", "0.6") or 0.6),
        "max_tokens": int(get_setting("max_tokens", "1200") or 1200),
    }


def _clean_error(raw: bytes) -> str:
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
        if isinstance(data, dict):
            err = data.get("error", data)
            if isinstance(err, dict):
                return str(err.get("message") or err)[:400]
            return str(err)[:400]
    except Exception:
        pass
    return raw.decode("utf-8", "replace")[:400]


def ai_complete(messages: list[dict], *, stream: bool = False, temperature: float | None = None,
                max_tokens: int | None = None):
    cfg = ai_settings()
    if not cfg["api_key"]:
        raise RuntimeError("NO_API_KEY")
    payload = {
        "model": cfg["model"],
        "messages": messages,
        "temperature": cfg["temperature"] if temperature is None else temperature,
        "max_completion_tokens": cfg["max_tokens"] if max_tokens is None else max_tokens,
        "top_p": 0.95,
        "stream": bool(stream),
    }
    req = urllib.request.Request(
        cfg["base_url"] + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + cfg["api_key"],
            "User-Agent": "TensorForge/1.0",
        },
        method="POST",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=120)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"API {exc.code}: {_clean_error(exc.read())}") from None
    except Exception as exc:  # network errors
        raise RuntimeError(f"Network error: {exc}") from None

    if not stream:
        raw = resp.read().decode("utf-8", "replace")
        try:
            data = json.loads(raw)
            return data["choices"][0]["message"]["content"] or ""
        except Exception:
            raise RuntimeError(f"Unexpected response: {raw[:300]}") from None

    def gen():
        buf = b""
        for chunk in resp:
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not line.startswith(b"data:"):
                    continue
                payload_raw = line[5:].strip()
                if payload_raw == b"[DONE]":
                    return
                try:
                    obj = json.loads(payload_raw)
                    delta = obj["choices"][0].get("delta", {}).get("content") or ""
                except Exception:
                    continue
                if delta:
                    yield delta

    return gen()


def problem_context(item: dict, *, include_solution: bool = False, code: str = "") -> str:
    lines = [
        f"Problem: {item['title']}",
        f"Library: {item['topic']} | Difficulty: {item['difficulty']} | Tags: {', '.join(item['tags'])}",
        "",
        "Task:",
        item["ask"],
        "",
        f"Required signature: {item['sig']}",
    ]
    if item.get("example"):
        lines += ["", "Example:", item["example"].replace("```", "")]
    if code.strip():
        lines += ["", "The learner's current code:", "```python", code[:6000], "```"]
    if include_solution:
        lines += ["", "Reference solution (for your explanation):", "```python",
                  item["solution"][:4000], "```"]
    lines += [
        "",
        "Rules: be concise, concrete and friendly. Never invent APIs. "
        "Use plain markdown with short code fences. The learner is practicing, "
        "so prefer guiding questions and small steps over pasting the whole answer.",
    ]
    return "\n".join(lines)


def _ai_or_error(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs), None
    except RuntimeError as exc:
        msg = str(exc)
        if msg == "NO_API_KEY":
            return None, ("No API key configured. Open Settings and paste a Groq API key "
                          "(free at console.groq.com/keys) to unlock AI hints, reviews and the tutor.")
        return None, msg


# --------------------------------------------------------------------------- #
#  Code execution
# --------------------------------------------------------------------------- #
def worker_env() -> dict:
    """
    Environment for the test worker.

    In a one-file build the child would otherwise re-extract the whole bundle to
    a fresh temp directory (slow: hundreds of MB). PyInstaller's bootloader skips
    extraction when these two variables point at the parent's own unpacked dir.
    """
    env = os.environ.copy()
    if FROZEN:
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            env["_PYI_PARENT_PROCESS_LEVEL"] = "1"
            env["_PYI_APPLICATION_HOME_DIR"] = meipass
    return env


def worker_command() -> list[str]:
    """Command that starts a test worker; `--serve` keeps it alive between runs."""
    if FROZEN:
        return [sys.executable, "--tf-worker", "--serve"]
    return [sys.executable, str(Path(__file__).resolve().parent / "runner.py"), "--serve"]


class Worker:
    """
    A warm, long-lived test process.

    Keeping one interpreter alive means torch is imported once instead of on every
    Run click (on Windows that saves several seconds per attempt). If a submission
    hangs, crashes the interpreter or blows up memory, the process is killed and a
    fresh one is started for the next run.
    """

    MARKER = "@@TF@@"

    def __init__(self) -> None:
        self.proc: subprocess.Popen | None = None
        self.lock = threading.Lock()
        self.jobs = 0

    # -- lifecycle ---------------------------------------------------------
    def _spawn(self) -> None:
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            self.proc = subprocess.Popen(
                worker_command(),
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                cwd=str(DATA_DIR),
                creationflags=flags,
                env=worker_env(),
            )
            self.jobs = 0
        except Exception:
            self.proc = None

    def _kill(self) -> None:
        proc, self.proc = self.proc, None
        if proc is None:
            return
        try:
            proc.kill()
        except Exception:
            pass
        try:
            proc.wait(timeout=5)
        except Exception:
            pass

    def warm(self) -> None:
        """Start (and pre-import torch in) the worker before the first request."""
        with self.lock:
            if self.proc is None or self.proc.poll() is not None:
                self._spawn()

    def shutdown(self) -> None:
        with self.lock:
            self._kill()

    # -- execution ---------------------------------------------------------
    def run(self, payload: dict, timeout: int = RUN_TIMEOUT) -> dict | None:
        with self.lock:
            recyclable = self.jobs >= 10  # bound memory growth from user code
            if self.proc is None or self.proc.poll() is not None or recyclable:
                self._kill()
                self._spawn()
            if self.proc is None:
                return None

            line = (json.dumps(payload) + "\n").encode("utf-8")
            box: queue.Queue = queue.Queue()

            def reader(stream):
                """Read lines until a real result arrives (skips the READY banner)."""
                for _ in range(40):
                    try:
                        raw_line = stream.readline()
                    except Exception:
                        raw_line = b""
                    if not raw_line:
                        box.put(b"")
                        return
                    if raw_line.startswith(self.MARKER.encode()):
                        box.put(raw_line)
                        return

            try:
                self.proc.stdin.write(line)
                self.proc.stdin.flush()
            except Exception:
                self._kill()
                return None

            threading.Thread(target=reader, args=(self.proc.stdout,), daemon=True).start()
            try:
                raw = box.get(timeout=timeout)
            except queue.Empty:
                self._kill()
                return {"ok": False,
                        "compile_error": f"Timed out after {timeout}s. Is there an infinite loop?",
                        "results": [], "figures": [], "stdout": "", "timed_out": True}

            self.jobs += 1
            if not raw:
                # the interpreter died mid-submission (os._exit, segfault, OOM kill)
                self._kill()
                return {"ok": False,
                        "compile_error": (
                            "Your code terminated the Python process (for example via "
                            "os._exit(), a segfault in native code, or running out of memory). "
                            "Remove that and run again."),
                        "results": [], "figures": [], "stdout": "", "crashed": True}
            text = raw.decode("utf-8", "replace").strip()
            if text.startswith(self.MARKER):
                text = text[len(self.MARKER):]
            try:
                return json.loads(text)
            except Exception:
                self._kill()
                return None


WORKER = Worker()
atexit.register(WORKER.shutdown)


def run_submission(item: dict, source: str) -> dict:
    payload = {
        "source": source,
        "checks": [{"name": c["name"], "kind": c["kind"], "source": c["source"], "n": c["n"]}
                   for c in item["checks"]],
    }
    t0 = time.time()
    res = WORKER.run(payload)
    if res is None:
        # could not start / talk to the worker at all — retry once with a cold start
        WORKER.warm()
        res = WORKER.run(payload)
    if res is None:
        res = {"ok": False,
               "compile_error": "The test runner could not be started. Try restarting TensorForge.",
               "results": [], "figures": [], "stdout": ""}
    res["time_ms"] = int((time.time() - t0) * 1000)
    return res


def record_progress(item: dict, code: str, ok: bool) -> None:
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        row = conn.execute("SELECT status, attempts FROM progress WHERE pid = ?",
                           (item["id"],)).fetchone()
        attempts = (row["attempts"] if row else 0) + 1
        status = "solved" if ok else ((row["status"] if row else "attempted") or "attempted")
        if status != "solved":
            status = "solved" if (row and row["status"] == "solved") else "attempted"
        solved_at = now if (ok or (row and row["status"] == "solved")) else None
        conn.execute(
            "INSERT INTO progress(pid, status, attempts, solved_at, last_code, updated_at) "
            "VALUES(?,?,?,?,?,?) "
            "ON CONFLICT(pid) DO UPDATE SET status=excluded.status, attempts=excluded.attempts, "
            "solved_at=COALESCE(progress.solved_at, excluded.solved_at), "
            "last_code=excluded.last_code, updated_at=excluded.updated_at",
            (item["id"], status, attempts, solved_at, code, now),
        )


def _log(msg: str) -> None:
    """Console output is unavailable in a windowed build — also log to a file."""
    try:
        if sys.stdout is not None:
            print(msg, flush=True)
    except Exception:
        pass
    try:
        with open(DATA_DIR / "tensorforge.log", "a", encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass


# --------------------------------------------------------------------------- #
#  Static UI
# --------------------------------------------------------------------------- #
@app.get("/")
def index():
    return send_from_directory(BASE_DIR / "templates", "index.html")


@app.errorhandler(Exception)
def _json_errors(exc):
    """Never hand the single-page app an HTML error page."""
    if isinstance(exc, HTTPException):
        return jsonify({"error": exc.description or exc.name}), exc.code
    app.logger.exception("unhandled error")
    _log(f"ERROR {type(exc).__name__}: {exc}")
    return jsonify({"error": f"{type(exc).__name__}: {exc}"}), 500


@app.get("/download/windows")
def download_windows():
    """Offer the built Windows executable for download (source checkout only)."""
    if not WINDOWS_EXE.exists():
        return jsonify({"error": "No Windows build found in this copy. "
                                 "Run build_windows.bat (or the GitHub workflow) first."}), 404
    return send_file(WINDOWS_EXE, as_attachment=True, download_name="TensorForge.exe",
                     mimetype="application/vnd.microsoft.portable-executable")


@app.get("/favicon.ico")
def favicon():
    return Response(status=204)


# --------------------------------------------------------------------------- #
#  Concept groups
#
#  The bank contains three generated variants per concept ("Trig identities #1..#3").
#  Students should see ONE row per concept and pick a variant inside it, so the
#  list is grouped here and only expanded on request.
# --------------------------------------------------------------------------- #
def _build_concepts() -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = {}
    for topic_items in _BY_TOPIC.values():
        for it in topic_items:
            groups.setdefault(it.get("concept") or it["id"], []).append(it)
    for key, items in groups.items():
        items.sort(key=lambda i: i["id"])
    return groups


CONCEPTS = _build_concepts()
CONCEPT_OF: dict[str, str] = {it["id"]: c for c, items in CONCEPTS.items() for it in items}

TOPIC_ORDER = ["torch", "numpy", "python", "matplotlib"]


def _group_state(items: list[dict], progress: dict, notes: dict) -> dict:
    solved = sum(1 for i in items if progress.get(i["id"], {}).get("status") == "solved")
    attempted = sum(1 for i in items if progress.get(i["id"], {}).get("status") == "attempted")
    starred = any(notes.get(i["id"], {}).get("bookmark") for i in items)
    if solved >= len(items):
        status = "solved"
    elif solved:
        status = "partial"
    elif attempted:
        status = "attempted"
    else:
        status = "new"
    return {"solved": solved, "attempted": attempted, "starred": starred, "status": status}


def _row(items: list[dict], progress: dict, notes: dict) -> dict:
    rep = items[0]
    st = _group_state(items, progress, notes)
    return {
        "id": rep["id"],
        "title": rep["title"].rsplit(" #", 1)[0],
        "topic": rep["topic"],
        "difficulty": rep["difficulty"],
        "tags": rep["tags"][:3],
        "variants": len(items),
        "variant_ids": [i["id"] for i in items],
        **st,
    }


def _filtered_rows(*, topic="", difficulty="", status="", q="", expand=False) -> list[dict]:
    progress, notes = progress_map(), notes_map()
    rows = []
    for concept, items in CONCEPTS.items():
        rep = items[0]
        if topic and rep["topic"] != topic:
            continue
        if difficulty and rep["difficulty"] != difficulty:
            continue
        row = _row(items, progress, notes)
        if status == "solved" and row["status"] != "solved":
            continue
        if status == "partial" and row["status"] != "partial":
            continue
        if status == "unsolved" and row["status"] in ("solved", "partial"):
            continue
        if status == "attempted" and row["status"] != "attempted":
            continue
        if status == "starred" and not row["starred"]:
            continue
        if q and q not in row["title"].lower() and not any(q in t for t in rep["tags"]) \
                and q not in concept:
            continue
        if expand:
            for it in items:
                single = _row([it], progress, notes)
                single["variants"] = 1
                single["concept"] = concept
                rows.append(single)
        else:
            row["concept"] = concept
            rows.append(row)
    rows.sort(key=lambda r: (TOPIC_ORDER.index(r["topic"]) if r["topic"] in TOPIC_ORDER else 9,
                             DIFF_ORDER.get(r["difficulty"], 9), r["title"].lower()))
    return rows


def _streak_and_recent() -> dict:
    with db() as conn:
        rows = conn.execute(
            "SELECT pid, status, MAX(updated_at) AS ts FROM progress "
            "WHERE updated_at IS NOT NULL GROUP BY pid ORDER BY ts DESC").fetchall()
    days = sorted({r["ts"][:10] for r in rows if r["ts"]}, reverse=True)
    streak = 0
    if days:
        from datetime import date, timedelta
        today = date.today()
        d = today if days[0] == str(today) else today - timedelta(days=1)
        have = set(days)
        while str(d) in have:
            streak += 1
            d -= timedelta(days=1)
    # longest run of consecutive days ever (for the "best streak" card)
    best = 0
    if days:
        from datetime import date, timedelta
        ordered = sorted(days)
        run = 1
        best = 1
        for prev, cur in zip(ordered, ordered[1:]):
            gap = (date.fromisoformat(cur) - date.fromisoformat(prev)).days
            run = run + 1 if gap == 1 else 1
            best = max(best, run)
    recent = []
    for r in rows[:8]:
        item = _BANK.get(r["pid"])
        if not item:
            continue
        recent.append({"id": item["id"], "title": item["title"].rsplit(" #", 1)[0],
                       "topic": item["topic"], "difficulty": item["difficulty"],
                       "status": r["status"], "when": r["ts"]})
    return {"streak": streak, "max_streak": max(best, streak), "recent": recent}


# --------------------------------------------------------------------------- #
#  API: home / browsing
# --------------------------------------------------------------------------- #
@app.get("/api/home")
def api_home():
    progress, notes = progress_map(), notes_map()
    topics = []
    for topic in TOPIC_ORDER:
        items = _BY_TOPIC.get(topic, [])
        if not items:
            continue
        concepts = [c for c, its in CONCEPTS.items() if its[0]["topic"] == topic]
        solved = sum(1 for c in concepts if _group_state(CONCEPTS[c], progress, notes)["status"] == "solved")
        diff = {d: sum(1 for c in concepts if CONCEPTS[c][0]["difficulty"] == d) for d in DIFF_ORDER}
        meta = TOPIC_META.get(topic, {"label": topic.title(), "icon": "*", "accent": "#64748b"})
        topics.append({"id": topic, "label": meta["label"], "icon": meta["icon"],
                       "accent": meta["accent"], "count": len(concepts),
                       "problems": len(items), "solved": solved, "difficulty": diff})

    all_concepts = list(CONCEPTS.values())
    _states = [_group_state(its, progress, notes)["status"] for its in all_concepts]
    total_solved = sum(1 for st in _states if st == "solved")
    total_in_progress = sum(1 for st in _states if st in ("attempted", "partial"))
    all_items = [it for t in _BY_TOPIC.values() for it in t]
    stats = _streak_and_recent()
    cfg = ai_settings()

    # solved-per-day for the last 14 days (for the activity strip)
    with db() as conn:
        rows = conn.execute(
            "SELECT substr(updated_at,1,10) AS d, COUNT(*) AS n FROM progress "
            "WHERE status='solved' AND updated_at IS NOT NULL "
            "GROUP BY d ORDER BY d DESC LIMIT 14").fetchall()
    daily = {r["d"]: r["n"] for r in rows}

    return jsonify({
        "topics": topics,
        "total_concepts": len(all_concepts),
        "total_problems": len(all_items),
        "solved_concepts": total_solved,
        "in_progress_concepts": total_in_progress,
        "solved_problems": sum(1 for it in all_items
                               if progress.get(it["id"], {}).get("status") == "solved"),
        "attempted": sum(1 for p in progress.values() if p["status"] == "attempted"),
        "bookmarks": sum(1 for n in notes.values() if n.get("bookmark")),
        "streak": stats["streak"],
        "max_streak": stats["max_streak"],
        "recent": stats["recent"],
        "daily": daily,
        "ai": {"configured": bool(cfg["api_key"]), "model": cfg["model"],
               "key_hint": ("\u2026" + cfg["api_key"][-4:]) if cfg["api_key"] else ""},
        "exe": {"available": WINDOWS_EXE.exists(),
                "size_mb": round(WINDOWS_EXE.stat().st_size / (1024 * 1024)) if WINDOWS_EXE.exists() else 0},
        "version": "1.1.0",
        "data_dir": str(DATA_DIR),
    })


@app.get("/api/bootstrap")           # kept for older clients
def api_bootstrap():
    return api_home()


@app.get("/api/problems")
def api_problems():
    rows = _filtered_rows(
        topic=request.args.get("topic", "").strip(),
        difficulty=request.args.get("difficulty", "").strip(),
        status=request.args.get("status", "").strip(),
        q=request.args.get("q", "").strip().lower(),
        expand=request.args.get("variants", "0") == "1",
    )
    if request.args.get("shuffle") == "1":
        import random as _random
        _random.shuffle(rows)
    total = len(rows)
    offset = int(request.args.get("offset", 0))
    limit = min(int(request.args.get("limit", 4000)), 5000)
    return jsonify({"total": total, "items": rows[offset:offset + limit]})


@app.get("/api/problem/<pid>")
def api_problem(pid: str):
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "not found"}), 404
    concept = CONCEPT_OF.get(pid, pid)
    variants = CONCEPTS.get(concept, [item])
    progress, notes = progress_map(), notes_map()
    with db() as conn:
        row = conn.execute("SELECT status, attempts, last_code FROM progress WHERE pid = ?",
                           (pid,)).fetchone()
        note = conn.execute("SELECT note, bookmark FROM notes WHERE pid = ?", (pid,)).fetchone()
    return jsonify({
        "id": item["id"],
        "concept": concept,
        "title": item["title"].rsplit(" #", 1)[0],
        "subtitle": item["title"],
        "topic": item["topic"],
        "difficulty": item["difficulty"],
        "tags": item["tags"],
        "ask": item["ask"],
        "sig": item["sig"],
        "starter": item["starter"],
        "example": item.get("example"),
        "hints": item["hints"],
        "checks": [c["name"] for c in item["checks"]],
        "variants": [{"id": v["id"], "label": v["title"].rsplit(" #", 1)[-1] if " #" in v["title"] else "1",
                      "status": progress.get(v["id"], {}).get("status", "new")} for v in variants],
        "attempts": row["attempts"] if row else 0,
        "status": (row["status"] if row else "new"),
        "last_code": (row["last_code"] if row else "") or item["starter"],
        "note": (note["note"] if note else "") or "",
        "bookmarked": bool(note["bookmark"]) if note else False,
        "weak": bool(item.get("weak")),
    })


@app.get("/api/random")
def api_random():
    topic = request.args.get("topic", "").strip()
    difficulty = request.args.get("difficulty", "").strip()
    only_unsolved = request.args.get("unsolved", "1") == "1"
    status = "unsolved" if only_unsolved else ""
    rows = _filtered_rows(topic=topic, difficulty=difficulty, status=status)
    if not rows and only_unsolved:
        rows = _filtered_rows(topic=topic, difficulty=difficulty)
    if not rows:
        return jsonify({"error": "no problems match those filters"}), 404
    import random as _random
    choice = _random.choice(rows)
    return jsonify({"id": choice["id"], "variants": choice.get("variant_ids", [choice["id"]])})


@app.get("/api/solution/<pid>")
def api_solution(pid: str):
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "not found"}), 404
    return jsonify({"code": item["solution"], "title": item["title"]})


@app.get("/api/reference/<pid>")
def api_reference(pid: str):
    """Run the reference solution and return its figures (used for plot problems)."""
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "not found"}), 404
    res = run_submission(item, item["solution"])
    if not res.get("ok"):
        return jsonify({"error": res.get("compile_error") or "reference failed"}), 500
    return jsonify({"figures": res.get("figures", [])[:1]})


@app.get("/api/search")
def api_search():
    q = request.args.get("q", "").strip().lower()
    if not q:
        return jsonify({"items": []})
    rows = _filtered_rows(q=q)[:40]
    return jsonify({"items": [{"id": r["id"], "title": r["title"], "topic": r["topic"],
                              "difficulty": r["difficulty"]} for r in rows]})


# --------------------------------------------------------------------------- #
#  API: execution
# --------------------------------------------------------------------------- #
@app.post("/api/run")
def api_run():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    code = body.get("code", "")
    item = _BANK.get(pid)
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    if not code.strip():
        return jsonify({"ok": False, "compile_error": "Write some code first 🙂",
                        "results": []})
    res = run_submission(item, code)
    record_progress(item, code, bool(res.get("ok")))
    res["status"] = "solved" if res.get("ok") else "attempted"
    return jsonify(res)


@app.post("/api/save")
def api_save():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    code = body.get("code", "")
    if pid not in _BANK:
        return jsonify({"ok": False}), 404
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        conn.execute(
            "INSERT INTO progress(pid, status, attempts, last_code, updated_at) "
            "VALUES(?, 'attempted', 0, ?, ?) "
            "ON CONFLICT(pid) DO UPDATE SET last_code=excluded.last_code, updated_at=excluded.updated_at",
            (pid, code, now),
        )
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- #
#  API: notes & bookmarks
# --------------------------------------------------------------------------- #
@app.post("/api/note")
def api_note():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    if pid not in _BANK:
        return jsonify({"ok": False}), 404
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    with db() as conn:
        row = conn.execute("SELECT note, bookmark FROM notes WHERE pid = ?", (pid,)).fetchone()
        note = body.get("note", row["note"] if row else "")
        bookmark = int(body.get("bookmark", row["bookmark"] if row else 0))
        conn.execute(
            "INSERT INTO notes(pid, note, bookmark, updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(pid) DO UPDATE SET note=excluded.note, bookmark=excluded.bookmark, "
            "updated_at=excluded.updated_at",
            (pid, note, bookmark, now),
        )
    return jsonify({"ok": True, "bookmark": bool(bookmark)})


# --------------------------------------------------------------------------- #
#  API: settings
# --------------------------------------------------------------------------- #
@app.get("/api/settings")
def api_settings_get():
    cfg = ai_settings()
    key = cfg["api_key"]
    return jsonify({
        "api_key_hint": ("…" + key[-4:]) if key else "",
        "has_key": bool(key),
        "model": cfg["model"],
        "base_url": cfg["base_url"],
        "temperature": cfg["temperature"],
        "max_tokens": cfg["max_tokens"],
        "defaults": {"model": DEFAULT_MODEL, "base_url": DEFAULT_BASE_URL},
        "data_dir": str(DATA_DIR),
    })


@app.post("/api/settings")
def api_settings_post():
    body = request.get_json(force=True, silent=True) or {}
    if "api_key" in body:
        key = (body.get("api_key") or "").strip()
        set_setting("api_key", key)
    if body.get("model"):
        set_setting("model", str(body["model"]).strip())
    if body.get("base_url"):
        set_setting("base_url", str(body["base_url"]).strip())
    if "temperature" in body:
        try:
            set_setting("temperature", str(float(body["temperature"])))
        except Exception:
            pass
    if "max_tokens" in body:
        try:
            set_setting("max_tokens", str(int(body["max_tokens"])))
        except Exception:
            pass
    cfg = ai_settings()
    return jsonify({"ok": True, "has_key": bool(cfg["api_key"]),
                    "api_key_hint": ("…" + cfg["api_key"][-4:]) if cfg["api_key"] else ""})


@app.post("/api/settings/test")
def api_settings_test():
    text, err = _ai_or_error(
        ai_complete,
        [{"role": "user", "content": "Reply with exactly: TensorForge ready"}],
        max_tokens=16, temperature=0.0,
    )
    if err:
        return jsonify({"ok": False, "error": err})
    return jsonify({"ok": True, "reply": (text or "").strip()[:120]})


@app.get("/api/models")
def api_models():
    cfg = ai_settings()
    if not cfg["api_key"]:
        return jsonify({"ok": False, "error": "NO_API_KEY"})
    try:
        req = urllib.request.Request(
            cfg["base_url"] + "/models",
            headers={"Authorization": "Bearer " + cfg["api_key"],
                     "User-Agent": "TensorForge/1.0"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        ids = sorted(m["id"] for m in data.get("data", []) if m.get("id"))
        return jsonify({"ok": True, "models": ids})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:300]})


# --------------------------------------------------------------------------- #
#  API: AI features
# --------------------------------------------------------------------------- #
HINT_SYSTEM = (
    "You are TensorForge's PyTorch/NumPy coach. You give graded hints that help a "
    "learner get unstuck without handing them the answer. Keep the reply under 130 "
    "words, plain markdown, no preamble."
)


@app.post("/api/hint")
def api_hint():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    level = int(body.get("level", 1))
    static_hints = item.get("hints", [])
    fallback = static_hints[min(level - 1, len(static_hints) - 1)] if static_hints else ""

    messages = [
        {"role": "system", "content": HINT_SYSTEM},
        {"role": "user", "content": problem_context(item, code=body.get("code", ""))
         + f"\n\nGive hint #{level} of 3: hint 1 = a nudge about the concept, hint 2 = the "
           f"concrete approach/API to use, hint 3 = the precise gotcha that usually breaks it. "
           f"Do not write the full solution."},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=350)
    if err:
        return jsonify({"hint": fallback, "source": "builtin", "error": err})
    return jsonify({"hint": text.strip(), "source": "ai"})


REVIEW_SYSTEM = (
    "You are a senior deep-learning engineer reviewing a learner's attempt in a "
    "practice app. Be specific and kind. Structure: **What happened**, **Why**, "
    "**Fix** (1-3 bullets, tiny code snippet only if essential), **Try next**. "
    "Under 220 words."
)


@app.post("/api/review")
def api_review():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    results = body.get("results", [])
    failures = [r for r in results if not r.get("passed")]
    detail = json.dumps([{k: r.get(k) for k in ("name", "passed", "message")} for r in results],
                        indent=1)[:4000]
    messages = [
        {"role": "system", "content": REVIEW_SYSTEM},
        {"role": "user", "content": problem_context(item, code=body.get("code", ""))
         + ("\n\nTest results:\n" + detail if results else "\n\nNo test run yet.")
         + ("\n\nFocus on the first failing check." if failures else "")},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=600)
    if err:
        return jsonify({"error": err}), 400
    return jsonify({"review": text.strip()})


@app.post("/api/explain")
def api_explain():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    if not item:
        return jsonify({"error": "unknown problem"}), 404
    messages = [
        {"role": "system", "content": (
            "You explain reference solutions to a learner. Walk through the idea, the "
            "shapes, and why each step exists. Then give one 'watch out' note and one "
            "'going further' idea. Under 260 words, markdown.")},
        {"role": "user", "content": problem_context(item, include_solution=True)},
    ]
    text, err = _ai_or_error(ai_complete, messages, max_tokens=700)
    if err:
        return jsonify({"error": err}), 400
    return jsonify({"explanation": text.strip()})


@app.post("/api/chat")
def api_chat():
    body = request.get_json(force=True, silent=True) or {}
    item = _BANK.get(body.get("id", ""))
    history = body.get("messages", [])[-12:]
    code = body.get("code", "")
    system = (
        "You are TensorForge's AI tutor for Python, NumPy, PyTorch and Matplotlib. "
        "You answer questions about the current problem, explain concepts, and debug. "
        "Be concise (under 200 words unless code is needed), use markdown, and never "
        "pretend to run code — the learner runs it with the Run tests button."
    )
    sys_msg = {"role": "system", "content": system}
    if item:
        sys_msg["content"] += "\n\n" + problem_context(item, code=code)
        if body.get("reveal_solution"):
            sys_msg["content"] += "\n\nReference solution:\n```python\n" + item["solution"][:3000] + "\n```"
    messages = [sys_msg] + [{"role": m.get("role", "user"), "content": str(m.get("content", ""))[:4000]}
                            for m in history if m.get("content")]

    try:
        gen = ai_complete(messages, stream=True, max_tokens=900)
    except RuntimeError as exc:
        msg = str(exc)
        if msg == "NO_API_KEY":
            msg = ("No API key configured. Open **Settings → AI** and paste a Groq API key "
                   "to chat with the tutor.")
        return jsonify({"error": msg}), 400

    def sse():
        try:
            for delta in gen:
                yield "data: " + json.dumps({"delta": delta}) + "\n\n"
        except Exception as exc:  # noqa: BLE001
            yield "data: " + json.dumps({"error": str(exc)[:300]}) + "\n\n"
        yield "data: " + json.dumps({"done": True}) + "\n\n"

    return Response(sse(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# --------------------------------------------------------------------------- #
#  API: progress export / reset
# --------------------------------------------------------------------------- #
@app.post("/api/quit")
def api_quit():
    """Close TensorForge (the packaged app has no console window to Ctrl+C in)."""
    WORKER.shutdown()
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


@app.get("/api/export")
def api_export():
    with db() as conn:
        progress = [dict(r) for r in conn.execute("SELECT * FROM progress").fetchall()]
        notes = [dict(r) for r in conn.execute("SELECT * FROM notes").fetchall()]
    payload = {"app": "TensorForge", "version": "1.0.0",
               "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
               "progress": progress, "notes": notes}
    return Response(json.dumps(payload, indent=2), mimetype="application/json",
                    headers={"Content-Disposition": "attachment; filename=tensorforge-progress.json"})


@app.post("/api/reset")
def api_reset():
    body = request.get_json(force=True, silent=True) or {}
    what = body.get("what", "progress")
    with db() as conn:
        if what == "progress":
            conn.execute("DELETE FROM progress")
        elif what == "notes":
            conn.execute("DELETE FROM notes")
        elif what == "all":
            conn.execute("DELETE FROM progress")
            conn.execute("DELETE FROM notes")
        elif what == "api_key":
            conn.execute("DELETE FROM settings WHERE key = 'api_key'")
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- #
#  Entrypoint
# --------------------------------------------------------------------------- #
def _port_busy(port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.4)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def _is_tensorforge(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/home", timeout=2) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return "total_problems" in data and "total_concepts" in data
    except Exception:
        return False


def main() -> None:
    port = 8765
    host = "127.0.0.1"
    open_browser = True
    args = sys.argv[1:]
    for i, a in enumerate(args):
        if a == "--port" and i + 1 < len(args):
            port = int(args[i + 1])
        elif a == "--host" and i + 1 < len(args):
            host = args[i + 1]
        elif a == "--no-browser":
            open_browser = False

    url = f"http://127.0.0.1:{port}"

    # If TensorForge is already up on this port (very common: the user
    # double-clicks the exe twice, or rebuilds while it runs), reuse that
    # instance instead of dying with "Address already in use" in a windowless
    # build — and instead of holding a second lock on the exe.
    if _port_busy(port):
        if _is_tensorforge(port):
            _log(f"  TensorForge is already running on {url} — opening it.")
            if open_browser:
                webbrowser.open(url)
            return
        _log(f"  Port {port} is used by another program. Try: --port {port + 1}")
        return

    _log("=" * 62)
    _log("  TensorForge — PyTorch / NumPy / Python / Matplotlib practice")
    _log("=" * 62)
    _log(f"  {len(_BANK)} problems loaded from {BANK_DIR}")
    _log(f"  Progress + API key stored in: {DATA_DIR}")
    _log(f"  Open: {url}")
    _log("=" * 62)

    threading.Thread(target=WORKER.warm, daemon=True).start()

    if open_browser and host in ("127.0.0.1", "localhost"):
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    app.run(host=host, port=port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    if "--tf-worker" in sys.argv:
        # Frozen mode: `TensorForge.exe --tf-worker --serve` is the test engine.
        # Keep --serve so the process stays warm between submissions.
        sys.argv = [sys.argv[0]] + [a for a in sys.argv[1:] if a == "--serve"]
        import runner

        runner.main()
    else:
        main()
