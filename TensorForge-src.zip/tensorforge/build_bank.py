"""Build the TensorForge question bank into bank/*.json + bank/manifest.json"""
from __future__ import annotations

import json
import os
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "tools"))

import dsl  # noqa: E402

# Registers all problems through dsl.q(...)
import specs_python  # noqa: F401,E402
import specs_numpy  # noqa: F401,E402
import specs_torch  # noqa: F401,E402
import specs_mpl  # noqa: F401,E402


def main() -> None:
    t0 = time.time()
    print(f"specs registered: {len(dsl.BANK)}")
    by_topic = dsl.finalize()
    outdir = os.path.join(HERE, "bank")
    os.makedirs(outdir, exist_ok=True)

    manifest = {"built_at": time.strftime("%Y-%m-%d %H:%M:%S"), "topics": {}, "total": 0}
    for topic, items in by_topic.items():
        # newest instance ordering: keep authoring order, but stable
        path = os.path.join(outdir, f"{topic}.json")
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(items, fh, ensure_ascii=False, separators=(",", ":"))
        manifest["topics"][topic] = len(items)
        manifest["total"] += len(items)
        sz = os.path.getsize(path) / 1024
        dif = Counter(i["difficulty"] for i in items)
        print(f"  {topic:10s} {len(items):5d} problems  {sz:8.1f} KB  {dict(dif)}")

    with open(os.path.join(outdir, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    print(f"TOTAL {manifest['total']} problems in {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
