# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for TensorForge.

Build with:   python build_exe.py        (recommended — picks sane defaults)
Or directly:  pyinstaller tensorforge.spec --noconfirm

Produces ONE executable:
  Windows : dist\\TensorForge.exe     (~200-300 MB; unpacks to a temp dir on launch)
  macOS   : dist/TensorForge
  Linux   : dist/TensorForge

Notes
-----
PyInstaller ships official hooks for numpy / matplotlib / flask, and
pyinstaller-hooks-contrib ships one for torch, so we only pass explicit
hidden imports for the submodules the problem bank touches. We deliberately
avoid ``collect_all('torch')``: it recursively imports every torch submodule,
which is slow and can exhaust memory on small machines.
"""
import sys
from pathlib import Path

ROOT = Path(SPECPATH).resolve()          # noqa: F821 - provided by PyInstaller
IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"

# --------------------------------------------------------------------------- #
#  Data files: question bank + single-page UI + icon
# --------------------------------------------------------------------------- #
datas = [
    (str(ROOT / "bank"), "bank"),
    (str(ROOT / "templates"), "templates"),
    (str(ROOT / "static_favicon.png"), "."),
]

# torch needs this helper executable at import time (torch/__init__.py checks it).
try:
    import importlib.util
    import importlib

    # find_spec does not import torch (importing it here would add ~300 MB of
    # peak memory to the build on small machines).
    _spec = importlib.util.find_spec("torch")
    _torch_dir = Path(_spec.origin).parent
    _shm = _torch_dir / "bin" / "torch_shm_manager"
    if _shm.exists():
        datas.append((str(_shm), "torch/bin"))
except Exception as _exc:                       # pragma: no cover
    print(f"[spec] could not locate torch_shm_manager: {_exc}")

# Some torch builds load zlib1.dll through ctypes. If the interpreter (or any
# wheel) ships a copy, bundle it so the warning cannot turn into a crash.
for _root in {Path(sys.base_prefix), Path(sys.base_prefix) / "DLLs",
              Path(sys.base_prefix) / "Library" / "bin"}:
    _z = _root / "zlib1.dll"
    if _z.exists():
        datas.append((str(_z), "."))
        break
else:
    try:
        import site
        for _sp in site.getsitepackages():
            _z = Path(_sp) / "zlib1.dll"
            if _z.exists():
                datas.append((str(_z), "."))
                break
    except Exception:
        pass

# Microsoft Visual C++ runtime: torch's DLLs link against these, and a clean
# Windows install does not always have them (they normally come from the VC++
# redistributable). When they sit next to the build interpreter, ship them.
for _dll in ("msvcp140.dll", "msvcp140_1.dll", "msvcp140_2.dll",
             "msvcp140_atomic_wait.dll", "vcruntime140.dll", "vcruntime140_1.dll",
             "concrt140.dll", "vcomp140.dll"):
    _candidate = Path(sys.base_prefix) / _dll
    if _candidate.exists():
        datas.append((str(_candidate), "."))

hiddenimports = [
    # stdlib pieces that exec'd user code imports
    "dataclasses", "itertools", "functools", "operator", "collections",
    "contextlib", "copy", "types", "math", "random", "io", "json", "textwrap",
    "ctypes", "ctypes.util", "ctypes.wintypes", "ctypes.macholib",
    # flask stack
    "werkzeug.middleware.proxy_fix", "jinja2.ext",
    # torch submodules referenced by the problem bank
    "torch.nn", "torch.nn.functional", "torch.nn.init", "torch.nn.utils",
    "torch.nn.utils.clip_grad", "torch.nn.utils.parametrizations",
    "torch.optim", "torch.optim.sgd", "torch.optim.adam", "torch.optim.adamw",
    "torch.optim.rmsprop", "torch.optim.lr_scheduler",
    "torch.autograd", "torch.autograd.functional", "torch.autograd.gradcheck",
    "torch.utils", "torch.utils.data", "torch.utils.data.dataloader",
    "torch.utils.data.dataset", "torch.utils.data.sampler",
    "torch.linalg", "torch.fft", "torch.special", "torch.distributions",
    "torch.backends", "torch.overrides",
    # matplotlib backends used by the figure capture
    "matplotlib.backends.backend_agg",
    "matplotlib.backends.backend_pdf",
    "matplotlib.backends.backend_svg",
]

# The splash screen is drawn by PyInstaller's bootloader and needs Tcl/Tk at
# *build* time to compile its image. If tkinter is missing (embeddable Python,
# some Store builds) we build without a splash instead of failing, and we must
# then not ship tkinter at all.
USE_SPLASH = False
if IS_WIN:
    try:
        import tkinter  # noqa: F401
        USE_SPLASH = (ROOT / "build_assets" / "splash.png").exists()
    except Exception:
        USE_SPLASH = False
    print(f"[spec] splash screen: {'on' if USE_SPLASH else 'off'}")

excludes = [
    *([] if USE_SPLASH else ["tkinter", "_tkinter", "tkinter.ttk"]),
    "PyQt5", "PyQt6", "PySide2", "PySide6", "wx",
    "IPython", "ipykernel", "jupyter", "jupyter_client", "notebook", "nbformat",
    "pytest", "sphinx", "docutils",
    "torchvision", "torchaudio", "tensorboard", "onnx",
    "sqlalchemy", "pandas", "scipy", "sklearn", "numba", "cupy",
    "bokeh", "panel", "plotly", "holoviews", "tornado", "zmq",
]

# --------------------------------------------------------------------------- #
#  Build the executable
# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
#  Binary-dependency probe
#
#  PyInstaller imports every collected package in one scratch process to see
#  which DLLs they load. Importing torch (plus sympy, networkx, fsspec) there
#  needs >1 GB and dies on small machines and under Wine. torch's DLLs are all
#  inside torch/lib and are collected by hooks/hook-torch.py, so we simply skip
#  torch in that probe and let the hook-provided binaries stand.
# --------------------------------------------------------------------------- #
import PyInstaller.building.build_main as _bm

_orig_find_binaries = _bm.find_binary_dependencies


# Only probe packages that actually ship out-of-tree DLLs. Importing torch,
# sympy, networkx and functorch into the probe process costs ~1 GB and is
# pointless: torch's libraries are collected wholesale by hooks/hook-torch.py.
_PROBE_PACKAGES = {
    "numpy", "matplotlib", "PIL", "contourpy", "kiwisolver",
    "fontTools", "pyparsing", "dateutil", "cycler", "packaging", "sqlite3",
}


def _find_binary_dependencies(binaries, import_packages, symlink_suppression):
    filtered = [p for p in import_packages if p.split(".")[0] in _PROBE_PACKAGES]
    skipped = len(import_packages) - len(filtered)
    if skipped:
        print(f"[spec] DLL probe: probing {len(filtered)} packages, skipping {skipped} "
              f"(torch & friends are bundled by hook-torch)")
    return _orig_find_binaries(binaries, filtered, symlink_suppression)


_bm.find_binary_dependencies = _find_binary_dependencies

a = Analysis(                                    # noqa: F821
    [str(ROOT / "app.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[str(ROOT / "hooks")],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    noarchive=False,
    optimize=1,
)

# Drop bulky files that torch never needs at runtime (tests, C++ headers, tools).
_SKIP = ("/torch/test/", "/torch/include/")
# torch/bin contains ~50 MB of distribution tests and protoc; only the shared
# memory manager is required at import time.
_KEEP_IN_BIN = ("torch_shm_manager",)


def _prune(path: str) -> bool:
    p = str(path).replace("\\", "/")
    if any(part in p for part in _SKIP):
        return True
    if "/torch/bin/" in p and not any(k in p for k in _KEEP_IN_BIN):
        return True
    return False


a.datas = [d for d in a.datas if not _prune(d[0])]
a.binaries = [b for b in a.binaries if not _prune(b[0])]

pyz = PYZ(a.pure)                                 # noqa: F821

splash = None
if USE_SPLASH:
    try:
        splash = Splash(                         # noqa: F821
            str(ROOT / "build_assets" / "splash.png"),
            binaries=[],
            datas=[],
            text_pos=(24, 250),
            text_size=11,
            text_color="#dbe7ff",
            full_tk=False,
        )
    except Exception as _exc:                    # pragma: no cover
        print(f"[spec] splash disabled: {_exc}")
        splash = None

exe = EXE(                                        # noqa: F821
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    *([splash] if splash is not None else []),
    [],
    name="TensorForge",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False if (IS_WIN or IS_MAC) else True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(ROOT / "build_assets" / "icon.ico") if IS_WIN
    else (str(ROOT / "build_assets" / "icon.png") if IS_MAC else None),
)
