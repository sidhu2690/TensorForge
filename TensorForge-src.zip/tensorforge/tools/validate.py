"""
Validate the built question bank.

  1. every reference solution must pass 100% of its own checks
  2. starter code must fail (otherwise the test is vacuous)
  3. checks must not leak state into each other

Runs in-process for speed (thousands of problems).  Usage:
    python tools/validate.py [--bank DIR] [--starter] [--topic torch]
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import signal
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


class Timeout(Exception):
    pass


def _alarm(signum, frame):
    raise Timeout("check timed out (10s)")


def run_check(source: str, solve, kind: str, n: int) -> tuple[bool, str]:
    g = {"__name__": "_tf_check", "solve": solve}
    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(15)
    try:
        exec(compile(source, "<check>", "exec"), g)
        if kind == "cases":
            for i in range(n):
                g["_case"](i)
        return True, ""
    except Timeout as exc:
        return False, str(exc)
    except AssertionError as exc:
        return False, str(exc) or "assertion failed"
    except Exception:
        import os
        if os.environ.get("TF_DEBUG"):
            traceback.print_exc()
        return False, traceback.format_exc(limit=3).strip().splitlines()[-1]
    finally:
        signal.alarm(0)
        try:
            import matplotlib.pyplot as plt
            plt.close("all")
        except Exception:
            pass


def load_solve(code: str):
    """Execute into a real module object so dataclasses / pickling work."""
    import types
    mod = types.ModuleType("_tf_user")
    sys.modules["_tf_user"] = mod
    exec(compile(code, "<solution>", "exec"), mod.__dict__)
    return mod.__dict__.get("solve")


def validate(items, with_starter: bool, verbose: bool) -> int:
    bad = []
    for idx, item in enumerate(items):
        try:
            solve = load_solve(item["solution"])
        except Exception:
            bad.append((item["id"], "solution does not compile", traceback.format_exc(limit=2)))
            continue
        if solve is None:
            bad.append((item["id"], "solution has no solve()", ""))
            continue
        ok_all = True
        for chk in item["checks"]:
            ok, msg = run_check(chk["source"], solve, chk["kind"], chk["n"])
            if not ok:
                ok_all = False
                bad.append((item["id"], f"[solution] {chk['name']}: {msg}", item["title"]))
                break
        if ok_all and with_starter and not item.get("weak"):
            try:
                st = load_solve(item["starter"])
            except Exception:
                st = None
            if st is not None:
                passed_any = False
                for chk in item["checks"]:
                    ok, _ = run_check(chk["source"], st, chk["kind"], chk["n"])
                    if ok:
                        passed_any = True
                        break
                if passed_any:
                    bad.append((item["id"], "[starter] starter code passes the tests!", item["title"]))
        if verbose and (idx + 1) % 200 == 0:
            print(f"  ... {idx + 1}/{len(items)}", flush=True)
    if bad:
        print(f"\n{len(bad)} problem(s) failed validation:")
        for pid, msg, extra in bad[:40]:
            print(f"  - {pid}: {msg}  {extra}")
        if len(bad) > 40:
            print(f"  ... and {len(bad) - 40} more")
        return len(bad)
    print(f"OK: {len(items)} problems validated (solutions pass, starters fail)")
    return 0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bank", default=os.path.join(ROOT, "bank"))
    ap.add_argument("--starter", action="store_true", help="also check starter code fails")
    ap.add_argument("--topic")
    ap.add_argument("--limit", type=int)
    args = ap.parse_args()

    total = 0
    files = sorted(glob.glob(os.path.join(args.bank, "*.json")))
    files = [f for f in files if not f.endswith("manifest.json")]
    for path in files:
        topic = os.path.basename(path)[:-5]
        if args.topic and topic != args.topic:
            continue
        with open(path, encoding="utf-8") as fh:
            items = json.load(fh)
        if args.limit:
            items = items[: args.limit]
        print(f"== {topic}: {len(items)} problems", flush=True)
        total += validate(items, args.starter, verbose=True)
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()
