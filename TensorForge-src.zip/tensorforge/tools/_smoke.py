"""Smoke test for the DSL: build a few problems, check solutions pass + starters fail."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import dsl  # noqa: E402
from validate import run_check, load_solve  # noqa: E402


def main():
    dsl.q(
        topic="python", diff="easy", tags=["strings"], title="Reverse a string",
        ask="Return `s` reversed.", sig="solve(s)", sol="return s[::-1]",
        mk="cases = [('abc',), ('',), ('tensor',), ('a b',)]\n    return cases[i % len(cases)]",
        arg_names=["s"],
        hints=["Python slices accept a step of -1.", "s[::-1]"],
    )
    dsl.q(
        topic="numpy", diff="easy", tags=["reductions"], title="Sum along axis 0",
        ask="Return the column sums of `x`.", sig="solve(x)", sol="return x.sum(axis=0)",
        mk="return (np.random.randn(3, 4),)", arg_names=["x"],
    )
    dsl.q(
        topic="torch", diff="easy", tags=["autograd"], title="Gradient of sum of squares",
        ask="Given x (requires_grad), compute loss = (x**2).sum(), backward, return x.grad.",
        sig="solve(x)", sol="loss = (x ** 2).sum()\nloss.backward()\nreturn x.grad",
        mk="return (torch.randn(4, requires_grad=True),)", arg_names=["x"],
        props=["assert _got.shape == torch.Size([4])"],
    )
    dsl.q(
        topic="torch", diff="easy", tags=["optim"], title="SGD step",
        ask="Take one SGD step on w with grad manually set.", sig="solve(w)",
        sol="with torch.no_grad():\n    w -= 0.1 * w.grad\nw.grad.zero_()\nreturn w",
        mk="w = torch.randn(3, requires_grad=True)\n    (w.sum()).backward()\n    return (w,)",
        cmp="mut", arg_names=["w"],
    )
    dsl.q(
        topic="matplotlib", diff="easy", tags=["plot"], title="Title the axes",
        ask="Create a figure, plot x, set title to 'demo'.", sig="solve()",
        sol="fig, ax = plt.subplots()\nax.plot([1, 2, 3])\nax.set_title('demo')\nreturn ax",
        mk="return ()", props=["assert _got.get_title() == 'demo'"], cmp="none",
        no_example=True, variants=1,
    )

    out = dsl.finalize()
    n = sum(len(v) for v in out.values())
    print("built", n, "problems")
    fails = 0
    for topic, items in out.items():
        for item in items:
            solve = load_solve(item["solution"])
            for chk in item["checks"]:
                ok, msg = run_check(chk["source"], solve, chk["kind"], chk["n"])
                if not ok:
                    fails += 1
                    print("SOLUTION FAIL", item["id"], chk["name"], msg)
            st = load_solve(item["starter"])
            if st is not None:
                passed = any(run_check(c["source"], st, c["kind"], c["n"])[0] for c in item["checks"])
                if passed:
                    fails += 1
                    print("STARTER PASSED (bad)", item["id"])
            print(item["id"], "|", item["difficulty"], "|", item["title"], "|", item["focus"])
            if item.get("example"):
                print("   example:", item["example"].replace("\n", " ")[:130])
    print("FAILS:", fails)
    with open(os.path.join(HERE, "_smoke.json"), "w") as fh:
        json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main()
