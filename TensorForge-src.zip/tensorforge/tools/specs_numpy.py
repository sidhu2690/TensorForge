"""NumPy question bank — part 1: creation, attributes, indexing, shape ops."""
from dsl import q, auto

# =========================================================================== #
#  Creation
# =========================================================================== #
q(topic="numpy", diff="easy", tags=["creation"], title="Array from a list",
  ask="Create a NumPy array from the nested Python list `data`.",
  sig="solve(data)", sol="return np.array(data)",
  mk="""
  cases = [([1, 2, 3],), ([[1.5, 2.5], [3.5, 4.5]],), ([],), ([0],), ([[1, 2], [3, 4]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["data"],
  hints=["`np.array` infers the dtype.", "Nested lists become 2-D arrays."])

auto(topic="numpy", diff="easy", tags=["creation"], title="Zeros array",
     ask="Return an array of zeros with the given shape.",
     args=["shape = (3, 4)", "shape = (5,)", "shape = (2, 2, 2)"],
     op="np.zeros(shape)")

auto(topic="numpy", diff="easy", tags=["creation"], title="Ones array",
     ask="Return an array of ones with the given shape and `float32` dtype.",
     args=["shape = (2, 3)", "shape = (4,)", "shape = (1, 2)"],
     op="np.ones(shape, dtype=np.float32)")

auto(topic="numpy", diff="easy", tags=["creation"], title="Full array",
     ask="Return an array of the given shape filled with `value`.",
     args=["shape = (2, 3)\nvalue = 7", "shape = (4,)\nvalue = -1.5", "shape = (1, 2, 2)\nvalue = 0"],
     op="np.full(shape, value)")

auto(topic="numpy", diff="easy", tags=["creation", "arange"], title="Arange",
     ask="Return the integers from `start` to `stop` (exclusive).",
     args=["start = 0\nstop = 5", "start = 3\nstop = 9", "start = -2\nstop = 3"],
     op="np.arange(start, stop)")

auto(topic="numpy", diff="medium", tags=["creation", "arange"], title="Arange with step",
     ask="Return the values from `start` to `stop` with the given step.",
     args=["start = 0\nstop = 10\nstep = 3", "start = 5\nstop = 0\nstep = -1", "start = 0.0\nstop = 1.0\nstep = 0.25"],
     op="np.arange(start, stop, step)")

auto(topic="numpy", diff="easy", tags=["creation", "linspace"], title="Linspace",
     ask="Return `n` evenly spaced values from `start` to `stop` inclusive.",
     args=["start = 0.0\nstop = 1.0\nn = 5", "start = -1.0\nstop = 1.0\nn = 3", "start = 0\nstop = 10\nn = 11"],
     op="np.linspace(start, stop, n)")

auto(topic="numpy", diff="easy", tags=["creation", "eye"], title="Identity matrix",
     ask="Return the `n x n` identity matrix.",
     args=["n = 3", "n = 1", "n = 5"], op="np.eye(n)")

auto(topic="numpy", diff="medium", tags=["creation", "eye"], title="Identity with an offset diagonal",
     ask="Return an identity-like matrix of shape `(r, c)` whose ones sit on the diagonal "
         "offset by `k` (positive = above the main diagonal).",
     args=["r = 3\nc = 3\nk = 1", "r = 4\nc = 4\nk = -2", "r = 2\nc = 5\nk = 3"],
     op="np.eye(r, c, k=k)")

auto(topic="numpy", diff="easy", tags=["creation", "like"], title="Zeros like",
     ask="Return a zeros array with the same shape and dtype as `a`.",
     args=["a = np.random.randn(3, 4)", "a = np.arange(5)", "a = np.ones((2, 2), dtype=np.float32)"],
     op="np.zeros_like(a)")

auto(topic="numpy", diff="easy", tags=["creation", "like"], title="Ones like",
     ask="Return an array of ones shaped like `a`, with `float64` dtype.",
     args=["a = np.random.randn(2, 3)", "a = np.arange(4)", "a = np.zeros((1, 5))"],
     op="np.ones_like(a, dtype=np.float64)")

auto(topic="numpy", diff="medium", tags=["creation", "random"], title="Seeded normal sample",
     ask="Using a local `np.random.default_rng(seed)`, draw a `(3, 4)` standard normal "
         "sample (`.standard_normal`).",
     args=["seed = 0", "seed = 42", "seed = 7"],
     op="np.random.default_rng(seed).standard_normal((3, 4))")

auto(topic="numpy", diff="medium", tags=["creation", "random"], title="Seeded uniform sample",
     ask="Draw 10 samples uniform in `[low, high)` from a local generator seeded with `seed`.",
     args=["low = 0.0\nhigh = 1.0\nseed = 1", "low = -5.0\nhigh = 5.0\nseed = 2",
           "low = 10.0\nhigh = 20.0\nseed = 3"],
     op="np.random.default_rng(seed).uniform(low, high, size=10)")

auto(topic="numpy", diff="medium", tags=["creation", "random"], title="Seeded integers",
     ask="Draw a `(3, 3)` array of integers in `[low, high)` from a generator seeded with `seed`.",
     args=["low = 0\nhigh = 10\nseed = 0", "low = -5\nhigh = 5\nseed = 5", "low = 100\nhigh = 110\nseed = 9"],
     op="np.random.default_rng(seed).integers(low, high, size=(3, 3))")

# =========================================================================== #
#  Attributes & conversion
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["attributes"], title="Shape",
     ask="Return the shape tuple of `a`.",
     args=["a = np.zeros((3, 4))", "a = np.arange(5)", "a = np.zeros((2, 3, 4))"],
     op="a.shape")

auto(topic="numpy", diff="easy", tags=["attributes"], title="Number of dimensions",
     ask="Return `a.ndim`.",
     args=["a = np.zeros((3, 4))", "a = np.array(5.0)", "a = np.zeros((2, 3, 4))"],
     op="a.ndim")

auto(topic="numpy", diff="easy", tags=["attributes"], title="Total number of elements",
     ask="Return the total number of elements in `a`.",
     args=["a = np.zeros((3, 4))", "a = np.arange(10)", "a = np.zeros((2, 3, 4))"],
     op="a.size")

auto(topic="numpy", diff="easy", tags=["attributes", "dtype"], title="dtype",
     ask="Return the dtype object of `a`.",
     args=["a = np.array([1, 2, 3])", "a = np.array([1.5, 2.5])", "a = np.zeros(3, dtype=np.float32)"],
     op="a.dtype")

auto(topic="numpy", diff="medium", tags=["attributes"], title="Itemsize",
     ask="Return the number of bytes per element of `a`.",
     args=["a = np.zeros(3, dtype=np.float32)", "a = np.zeros(3, dtype=np.int64)",
           "a = np.zeros(3, dtype=np.float64)"],
     op="a.itemsize")

auto(topic="numpy", diff="medium", tags=["attributes"], title="Total bytes",
     ask="Return the total number of bytes occupied by `a` (`nbytes`).",
     args=["a = np.zeros((3, 4), dtype=np.float32)", "a = np.arange(10)", "a = np.zeros((2, 2), dtype=np.int16)"],
     op="a.nbytes")

auto(topic="numpy", diff="medium", tags=["attributes"], title="Strides",
     ask="Return the byte strides of `a`.",
     args=["a = np.zeros((3, 4))", "a = np.zeros((2, 3), dtype=np.int32)", "a = np.zeros((3, 4)).T"],
     op="a.strides")

auto(topic="numpy", diff="easy", tags=["convert"], title="To list",
     ask="Return `a` as a nested Python list.",
     args=["a = np.array([1, 2, 3])", "a = np.eye(2)", "a = np.array([[1.5, 2.5]])"],
     op="a.tolist()")

auto(topic="numpy", diff="easy", tags=["dtype", "cast"], title="Cast to float32",
     ask="Return `a` converted to `float32`.",
     args=["a = np.arange(5)", "a = np.random.randn(3, 3)", "a = np.ones(2, dtype=np.float64)"],
     op="a.astype(np.float32)")

auto(topic="numpy", diff="medium", tags=["dtype", "cast"], title="Cast to int",
     ask="Return `a` truncated toward zero and cast to `int64`.",
     args=["a = np.array([1.7, -1.7, 0.2])", "a = np.random.randn(3) * 10", "a = np.array([[2.9, -0.9]])"],
     op="a.astype(np.int64)")

auto(topic="numpy", diff="easy", tags=["attributes", "transpose"], title="Transpose",
     ask="Return the transpose of the 2-D array `a`.",
     args=["a = np.arange(6).reshape(2, 3)", "a = np.ones((1, 4))", "a = np.random.randn(3, 3)"],
     op="a.T")

# =========================================================================== #
#  Indexing
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["indexing"], title="Select an element",
     ask="Return the element at row `i`, column `j`.",
     args=["a = np.arange(12).reshape(3, 4)\ni = 1\nj = 2", "a = np.eye(3)\ni = 2\nj = 0",
           "a = np.random.randn(2, 2)\ni = 0\nj = 1"],
     op="a[i, j]")

auto(topic="numpy", diff="easy", tags=["indexing"], title="Select a row",
     ask="Return row `i` of `a`.",
     args=["a = np.arange(12).reshape(3, 4)\ni = 0", "a = np.random.randn(5, 2)\ni = 4",
           "a = np.eye(3)\ni = 1"],
     op="a[i]")

auto(topic="numpy", diff="easy", tags=["indexing"], title="Select a column",
     ask="Return column `j` of `a`.",
     args=["a = np.arange(12).reshape(3, 4)\nj = 3", "a = np.random.randn(5, 2)\nj = 0",
           "a = np.eye(3)\nj = 2"],
     op="a[:, j]")

auto(topic="numpy", diff="medium", tags=["indexing", "slicing"], title="Slice a block",
     ask="Return the sub-array `a[r0:r1, c0:c1]`.",
     args=["a = np.arange(20).reshape(4, 5)\nr0 = 1\nr1 = 3\nc0 = 2\nc1 = 5",
           "a = np.random.randn(5, 5)\nr0 = 0\nr1 = 2\nc0 = 1\nc1 = 3",
           "a = np.arange(9).reshape(3, 3)\nr0 = 2\nr1 = 3\nc0 = 0\nc1 = 2"],
     op="a[r0:r1, c0:c1]")

auto(topic="numpy", diff="medium", tags=["indexing", "slicing"], title="Slice with a step",
     ask="Return every `step`-th row of `a` starting at row 0.",
     args=["a = np.arange(20).reshape(20, 1)\nstep = 2", "a = np.arange(10).reshape(5, 2)\nstep = 3",
           "a = np.arange(12).reshape(6, 2)\nstep = 1"],
     op="a[::step]")

auto(topic="numpy", diff="medium", tags=["indexing", "negative"], title="Last row and column",
     ask="Return the bottom-right element of `a` using negative indices.",
     args=["a = np.arange(12).reshape(3, 4)", "a = np.random.randn(5, 5)", "a = np.eye(2)"],
     op="a[-1, -1]")

auto(topic="numpy", diff="medium", tags=["indexing", "fancy"], title="Fancy indexing rows",
     ask="Return the rows of `a` listed in the integer array `idx` (in that order).",
     args=["a = np.arange(12).reshape(4, 3)\nidx = np.array([3, 0, 2])",
           "a = np.random.randn(5, 2)\nidx = np.array([1, 1, 4])",
           "a = np.eye(3)\nidx = np.array([2])"],
     op="a[idx]")

auto(topic="numpy", diff="medium", tags=["indexing", "fancy"], title="Fancy indexing columns",
     ask="Return the columns of `a` listed in `idx`.",
     args=["a = np.arange(12).reshape(3, 4)\nidx = np.array([0, 2])",
           "a = np.random.randn(2, 5)\nidx = np.array([4, 1, 3])",
           "a = np.eye(3)\nidx = np.array([1])"],
     op="a[:, idx]")

auto(topic="numpy", diff="medium", tags=["indexing", "fancy"], title="Advanced index pairs",
     ask="Return the elements `a[i, i]` for every index in the integer array `idx` "
         "(pairwise indexing, not a sub-matrix).",
     args=["a = np.arange(9).reshape(3, 3)\nidx = np.array([0, 1, 2])",
           "a = np.random.randn(4, 4)\nidx = np.array([3, 0])",
           "a = np.eye(5)\nidx = np.array([1, 4])"],
     op="a[idx, idx]")

auto(topic="numpy", diff="medium", tags=["indexing", "boolean"], title="Boolean mask",
     ask="Return the elements of `a` greater than `t` (flattened order).",
     args=["a = np.array([1.0, -1.0, 3.0, 0.5])\nt = 0.0", "a = np.random.randn(3, 3)\nt = 0.5",
           "a = np.arange(6)\nt = 3"],
     op="a[a > t]")

auto(topic="numpy", diff="medium", tags=["indexing", "boolean"], title="Boolean mask on rows",
     ask="`mask` is a boolean array over the rows of `a`. Return only the selected rows.",
     args=["a = np.arange(12).reshape(4, 3)\nmask = np.array([True, False, True, False])",
           "a = np.random.randn(3, 2)\nmask = np.array([False, False, True])",
           "a = np.eye(2)\nmask = np.array([True, True])"],
     op="a[mask]")

auto(topic="numpy", diff="medium", tags=["where"], title="np.where selection",
     ask="Return an array taking values from `x` where `cond` is true and from `y` otherwise.",
     args=["cond = np.array([True, False, True])\nx = np.array([1.0, 2.0, 3.0])\ny = np.array([10.0, 20.0, 30.0])",
           "cond = np.zeros((2, 2), dtype=bool)\nx = np.ones((2, 2))\ny = np.zeros((2, 2))",
           "cond = np.ones(4, dtype=bool)\nx = np.arange(4)\ny = np.arange(4) * 10"],
     op="np.where(cond, x, y)")

auto(topic="numpy", diff="medium", tags=["where"], title="Indices of true values",
     ask="Return the indices where `cond` is true as a tuple of arrays "
         "(`np.where(cond)` with a single argument).",
     args=["cond = np.array([True, False, True, True])",
           "cond = np.eye(2, dtype=bool)", "cond = np.zeros(3, dtype=bool)"],
     op="np.where(cond)")

auto(topic="numpy", diff="medium", tags=["nonzero"], title="Non-zero positions",
     ask="Return the indices of the non-zero elements of `a` with `np.nonzero`.",
     args=["a = np.array([0, 1, 0, 2])", "a = np.array([[1, 0], [0, 1]])", "a = np.zeros((2, 3))"],
     op="np.nonzero(a)")

auto(topic="numpy", diff="medium", tags=["take"], title="Take by index",
     ask="Return `np.take(a, idx)` — elements of `a` at the flat positions `idx`.",
     args=["a = np.array([10, 20, 30, 40])\nidx = np.array([0, 3])",
           "a = np.arange(6).reshape(2, 3)\nidx = np.array([1, 4])",
           "a = np.array([5])\nidx = np.array([0])"],
     op="np.take(a, idx)")

auto(topic="numpy", diff="medium", tags=["clip"], title="Clip",
     ask="Clip the values of `a` into `[lo, hi]`.",
     args=["a = np.array([-2.0, 0.5, 3.0])\nlo = 0.0\nhi = 1.0", "a = np.random.randn(3, 3)\nlo = -0.5\nhi = 0.5",
           "a = np.arange(6)\nlo = 2\nhi = 4"],
     op="np.clip(a, lo, hi)")

q(topic="numpy", diff="easy", tags=["indexing", "mut"], title="Set a slice in place",
  ask="Set every element of the first row of `a` to `value` **in place** and return `a`.",
  sig="solve(a, value)", sol="""
  a[0, :] = value
  return a
  """,
  mk="""
  cases = [(np.random.randn(3, 4), 5.0), (np.zeros((2, 2)), -1.0), (np.ones((4, 3)), 0.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "value"], cmp="mut",
  hints=["Slice assignment mutates the original buffer.",
         "`a[0] = value` also works."])

q(topic="numpy", diff="medium", tags=["indexing", "mut"], title="Fill the diagonal",
  ask="Write `value` onto the main diagonal of the square matrix `a` **in place** "
      "(`np.fill_diagonal`) and return `a`.",
  sig="solve(a, value)", sol="""
  np.fill_diagonal(a, value)
  return a
  """,
  mk="""
  cases = [(np.random.randn(3, 3), 0.0), (np.ones((4, 4)), 2.5), (np.zeros((1, 1)), 9.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "value"], cmp="mut",
  hints=["`np.fill_diagonal` modifies the array in place.",
         "Only the main diagonal is affected."])

# =========================================================================== #
#  Shape manipulation
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["shape", "reshape"], title="Reshape",
     ask="Reshape `a` to `(r, c)`.",
     args=["a = np.arange(12)\nr = 3\nc = 4", "a = np.arange(6)\nr = 2\nc = 3", "a = np.arange(8)\nr = 4\nc = 2"],
     op="a.reshape(r, c)")

auto(topic="numpy", diff="easy", tags=["shape", "reshape"], title="Reshape with -1",
     ask="Reshape `a` into `rows` rows and let NumPy infer the column count with `-1`.",
     args=["a = np.arange(12)\nrows = 4", "a = np.arange(10)\nrows = 5", "a = np.arange(6)\nrows = 1"],
     op="a.reshape(rows, -1)")

auto(topic="numpy", diff="easy", tags=["shape", "ravel"], title="Ravel",
     ask="Flatten `a` into 1-D with `np.ravel` (view when possible).",
     args=["a = np.arange(12).reshape(3, 4)", "a = np.arange(6).reshape(2, 3).T", "a = np.zeros((2, 2, 2))"],
     op="np.ravel(a)")

auto(topic="numpy", diff="medium", tags=["shape", "flatten"], title="Flatten a copy",
     ask="Return a flattened **copy** of `a` with `.flatten()`.",
     args=["a = np.arange(6).reshape(2, 3)", "a = np.arange(4).reshape(2, 2).T", "a = np.zeros((2, 3))"],
     op="a.flatten()")

auto(topic="numpy", diff="medium", tags=["shape", "expand"], title="Add an axis",
     ask="Insert a new axis at position `axis` using `np.expand_dims`.",
     args=["a = np.arange(6).reshape(2, 3)\naxis = 0", "a = np.arange(4)\naxis = 1", "a = np.arange(6).reshape(2, 3)\naxis = -1"],
     op="np.expand_dims(a, axis)")

auto(topic="numpy", diff="medium", tags=["shape", "squeeze"], title="Squeeze",
     ask="Remove all length-1 axes from `a`.",
     args=["a = np.zeros((1, 3, 1, 4))", "a = np.zeros((1, 1))", "a = np.zeros((2, 3))"],
     op="np.squeeze(a)")

auto(topic="numpy", diff="medium", tags=["shape", "squeeze"], title="Squeeze one axis",
     ask="Remove axis `axis` of length 1 using `np.squeeze(a, axis=...)`.",
     args=["a = np.zeros((3, 1, 4))\naxis = 1", "a = np.zeros((1, 5))\naxis = 0", "a = np.zeros((2, 1))\naxis = 1"],
     op="np.squeeze(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["shape", "swapaxes"], title="Swap axes",
     ask="Swap axes `i` and `j` of `a`.",
     args=["a = np.zeros((2, 3, 4))\ni = 0\nj = 2", "a = np.zeros((2, 3))\ni = 0\nj = 1",
           "a = np.zeros((2, 3, 4))\ni = 1\nj = 2"],
     op="np.swapaxes(a, i, j)")

auto(topic="numpy", diff="medium", tags=["shape", "moveaxis"], title="Move an axis",
     ask="Move axis `src` of `a` to position `dst`.",
     args=["a = np.zeros((2, 3, 4))\nsrc = 0\ndst = 2", "a = np.zeros((2, 3, 4))\nsrc = 2\ndst = 0",
           "a = np.zeros((2, 3))\nsrc = 1\ndst = 0"],
     op="np.moveaxis(a, src, dst)")

auto(topic="numpy", diff="easy", tags=["shape", "concatenate"], title="Concatenate",
     ask="Concatenate `x` and `y` along axis 0.",
     args=["x = np.zeros((2, 3))\ny = np.ones((1, 3))", "x = np.arange(3)\ny = np.arange(2)",
           "x = np.zeros((1, 2))\ny = np.ones((2, 2))"],
     op="np.concatenate([x, y], axis=0)")

auto(topic="numpy", diff="medium", tags=["shape", "concatenate"], title="Concatenate along axis 1",
     ask="Concatenate `x` and `y` along axis 1.",
     args=["x = np.zeros((2, 1))\ny = np.ones((2, 3))", "x = np.zeros((3, 2))\ny = np.ones((3, 1))",
           "x = np.zeros((1, 1))\ny = np.ones((1, 1))"],
     op="np.concatenate([x, y], axis=1)")

auto(topic="numpy", diff="easy", tags=["shape", "stack"], title="Stack 1-D arrays",
     ask="Stack `x` and `y` into a `(2, n)` array with `np.stack`.",
     args=["x = np.arange(3)\ny = np.arange(3) + 10", "x = np.ones(2)\ny = np.zeros(2)",
           "x = np.array([1.5])\ny = np.array([2.5])"],
     op="np.stack([x, y], axis=0)")

auto(topic="numpy", diff="medium", tags=["shape", "stack"], title="Stack along a new last axis",
     ask="Stack `x` and `y` along `axis=-1`.",
     args=["x = np.arange(3)\ny = np.arange(3) + 10", "x = np.ones((2, 2))\ny = np.zeros((2, 2))",
           "x = np.arange(1)\ny = np.arange(1)"],
     op="np.stack([x, y], axis=-1)")

auto(topic="numpy", diff="easy", tags=["shape", "vstack"], title="Vertical stack",
     ask="Stack `x` and `y` vertically with `np.vstack`.",
     args=["x = np.array([1, 2, 3])\ny = np.array([4, 5, 6])", "x = np.zeros((1, 2))\ny = np.ones((2, 2))",
           "x = np.ones((2, 1))\ny = np.zeros((1, 1))"],
     op="np.vstack([x, y])")

auto(topic="numpy", diff="easy", tags=["shape", "hstack"], title="Horizontal stack",
     ask="Stack `x` and `y` horizontally with `np.hstack`.",
     args=["x = np.array([1, 2])\ny = np.array([3, 4])", "x = np.zeros((2, 1))\ny = np.ones((2, 2))",
           "x = np.arange(3)\ny = np.arange(3)"],
     op="np.hstack([x, y])")

auto(topic="numpy", diff="medium", tags=["shape", "column_stack"], title="Column stack",
     ask="Stack the 1-D arrays as **columns** of a 2-D array with `np.column_stack`.",
     args=["x = np.array([1, 2, 3])\ny = np.array([4, 5, 6])", "x = np.zeros(2)\ny = np.ones(2)",
           "x = np.array([7])\ny = np.array([8])"],
     op="np.column_stack([x, y])")

auto(topic="numpy", diff="medium", tags=["shape", "tile"], title="Tile an array",
     ask="Tile `a` `reps` times along each axis with `np.tile`.",
     args=["a = np.array([[1, 2]])\nreps = (2, 3)", "a = np.array([1, 2])\nreps = 3",
           "a = np.array([[1], [2]])\nreps = (1, 2)"],
     op="np.tile(a, reps)")

auto(topic="numpy", diff="medium", tags=["shape", "repeat"], title="Repeat elements",
     ask="Repeat each element of `a` `r` times consecutively with `np.repeat`.",
     args=["a = np.array([1, 2, 3])\nr = 2", "a = np.array([[1, 2]])\nr = 3", "a = np.array([4])\nr = 1"],
     op="np.repeat(a, r)")

auto(topic="numpy", diff="medium", tags=["shape", "repeat"], title="Repeat along an axis",
     ask="Repeat the whole array `r` times along `axis` with `np.repeat(a, r, axis=axis)`.",
     args=["a = np.array([[1, 2], [3, 4]])\nr = 2\naxis = 0", "a = np.array([[1, 2]])\nr = 2\naxis = 1",
           "a = np.arange(3)\nr = 3\naxis = 0"],
     op="np.repeat(a, r, axis=axis)")

auto(topic="numpy", diff="medium", tags=["shape", "split"], title="Split into equal parts",
     ask="Split `a` into `k` equal parts along axis 0 with `np.split`.",
     args=["a = np.arange(12).reshape(6, 2)\nk = 3", "a = np.arange(8)\nk = 4", "a = np.arange(6).reshape(3, 2)\nk = 3"],
     op="np.split(a, k, axis=0)")

auto(topic="numpy", diff="medium", tags=["shape", "split"], title="Array split",
     ask="Split `a` into `k` parts along axis 0 with `np.array_split` (unequal sizes "
         "allowed) and return the list.",
     args=["a = np.arange(10)\nk = 3", "a = np.arange(7)\nk = 2", "a = np.arange(5)\nk = 4"],
     op="np.array_split(a, k)")

auto(topic="numpy", diff="medium", tags=["shape", "pad"], title="Pad an array",
     ask="Pad `a` with `pad` zeros on every side using `np.pad` with mode `'constant'`.",
     args=["a = np.array([1, 2, 3])\npad = 2", "a = np.ones((2, 2))\npad = 1", "a = np.array([5])\npad = 0"],
     op="np.pad(a, pad, mode='constant')")

auto(topic="numpy", diff="medium", tags=["shape", "roll"], title="Roll",
     ask="Roll the elements of `a` by `shift` positions along `axis` (wrap around).",
     args=["a = np.arange(5)\nshift = 2\naxis = 0", "a = np.arange(6).reshape(2, 3)\nshift = 1\naxis = 1",
           "a = np.arange(6).reshape(2, 3)\nshift = -1\naxis = 0"],
     op="np.roll(a, shift, axis=axis)")

auto(topic="numpy", diff="easy", tags=["shape", "flip"], title="Flip",
     ask="Reverse the order of `a` along `axis`.",
     args=["a = np.arange(5)\naxis = 0", "a = np.arange(6).reshape(2, 3)\naxis = 1",
           "a = np.arange(6).reshape(2, 3)\naxis = 0"],
     op="np.flip(a, axis=axis)")

auto(topic="numpy", diff="easy", tags=["shape", "rot90"], title="Rotate 90 degrees",
     ask="Rotate `a` counter-clockwise by 90 degrees `k` times with `np.rot90`.",
     args=["a = np.array([[1, 2], [3, 4]])\nk = 1", "a = np.arange(6).reshape(2, 3)\nk = 2",
           "a = np.array([[1, 2], [3, 4]])\nk = 3"],
     op="np.rot90(a, k)")

auto(topic="numpy", diff="medium", tags=["diag"], title="Extract the diagonal",
     ask="Return the diagonal of `a` offset by `k` using `np.diag`.",
     args=["a = np.arange(9).reshape(3, 3)\nk = 0", "a = np.arange(9).reshape(3, 3)\nk = 1",
           "a = np.arange(9).reshape(3, 3)\nk = -1"],
     op="np.diag(a, k=k)")

auto(topic="numpy", diff="medium", tags=["diag"], title="Diagonal matrix from a vector",
     ask="Build a diagonal matrix from the 1-D array `v`, shifted by `k`.",
     args=["v = np.array([1, 2, 3])\nk = 0", "v = np.array([4, 5])\nk = 1", "v = np.array([6])\nk = -2"],
     op="np.diag(v, k=k)")

auto(topic="numpy", diff="medium", tags=["triu"], title="Upper triangle",
     ask="Zero out everything below the `k`-th diagonal with `np.triu`.",
     args=["a = np.arange(9).reshape(3, 3)\nk = 0", "a = np.ones((4, 4))\nk = 1", "a = np.arange(6).reshape(2, 3)\nk = -1"],
     op="np.triu(a, k=k)")

auto(topic="numpy", diff="medium", tags=["tril"], title="Lower triangle",
     ask="Zero out everything above the `k`-th diagonal with `np.tril`.",
     args=["a = np.arange(9).reshape(3, 3)\nk = 0", "a = np.ones((4, 4))\nk = -1", "a = np.arange(6).reshape(2, 3)\nk = 1"],
     op="np.tril(a, k=k)")

# =========================================================================== #
#  Elementwise math
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["math"], title="Add a scalar", ask="Return `a + s`.",
     args=["a = np.arange(5)\ns = 2", "a = np.random.randn(3, 3)\ns = -0.5", "a = np.zeros((2, 2))\ns = 10.0"],
     op="a + s")

auto(topic="numpy", diff="easy", tags=["math"], title="Square", ask="Return the elementwise square of `a`.",
     args=["a = np.arange(4)\n", "a = np.random.randn(3, 2)\n", "a = np.array([-3.0, 0.5])\n"],
     op="np.square(a)")

auto(topic="numpy", diff="easy", tags=["math", "sqrt"], title="Square root", ask="Return the square root of every element.",
     args=["a = np.array([0.0, 1.0, 4.0, 9.0])", "a = np.random.rand(3, 3)", "a = np.arange(5)"],
     op="np.sqrt(a)")

auto(topic="numpy", diff="medium", tags=["math", "cbrt"], title="Cube root", ask="Return the cube root of every element (works for negatives too).",
     args=["a = np.array([-8.0, 0.0, 27.0])", "a = np.random.randn(4)", "a = np.arange(-3, 4)"],
     op="np.cbrt(a)")

auto(topic="numpy", diff="easy", tags=["math", "exp"], title="Exponential", ask="Return `e ** a` elementwise.",
     args=["a = np.array([0.0, 1.0, -1.0])", "a = np.random.randn(2, 3)", "a = np.linspace(-2, 2, 5)"],
     op="np.exp(a)")

auto(topic="numpy", diff="medium", tags=["math", "log"], title="Natural log", ask="Return the natural logarithm of `a` (positive values).",
     args=["a = np.array([1.0, np.e, 10.0])", "a = np.random.rand(3) + 0.1", "a = np.linspace(0.5, 5, 6)"],
     op="np.log(a)")

auto(topic="numpy", diff="medium", tags=["math", "log"], title="Base-10 log", ask="Return the base-10 logarithm of `a`.",
     args=["a = np.array([1.0, 10.0, 1000.0])", "a = np.random.rand(3) + 1", "a = np.array([[1e-3, 1e3]])"],
     op="np.log10(a)")

auto(topic="numpy", diff="medium", tags=["math", "log"], title="Log of one plus x", ask="Return `log(1 + a)` using the stable `np.log1p`.",
     args=["a = np.array([0.0, 1e-6, 1.0])", "a = np.random.rand(4) * 0.5", "a = np.linspace(0, 1, 5)"],
     op="np.log1p(a)")

auto(topic="numpy", diff="easy", tags=["math", "trig"], title="Sine and cosine", ask="Return the tuple `(sin(a), cos(a))`.",
     args=["a = np.array([0.0, np.pi / 2])", "a = np.linspace(-np.pi, np.pi, 5)", "a = np.random.randn(3)"],
     op="(np.sin(a), np.cos(a))")

auto(topic="numpy", diff="medium", tags=["math", "trig"], title="Degrees to radians", ask="Convert degrees to radians.",
     args=["a = np.array([0.0, 90.0, 180.0])", "a = np.array([45.0])", "a = np.linspace(0, 360, 5)"],
     op="np.deg2rad(a)")

auto(topic="numpy", diff="medium", tags=["math", "trig"], title="Radians to degrees", ask="Convert radians to degrees.",
     args=["a = np.array([0.0, np.pi / 2, np.pi])", "a = np.random.randn(3)", "a = np.linspace(-1, 1, 5)"],
     op="np.rad2deg(a)")

auto(topic="numpy", diff="easy", tags=["math", "abs"], title="Absolute value", ask="Return the absolute value of `a`.",
     args=["a = np.array([-1, 2, -3])", "a = np.random.randn(3, 3)", "a = np.array([[-0.5], [0.5]])"],
     op="np.abs(a)")

auto(topic="numpy", diff="easy", tags=["math", "sign"], title="Sign", ask="Return the sign of every element (-1, 0 or 1).",
     args=["a = np.array([-3.0, 0.0, 2.0])", "a = np.random.randn(4)", "a = np.arange(-2, 3)"],
     op="np.sign(a)")

auto(topic="numpy", diff="easy", tags=["math", "round"], title="Round to integers", ask="Round every element to the nearest integer.",
     args=["a = np.array([0.4, 0.5, 1.5, -0.5])", "a = np.random.randn(3) * 3", "a = np.linspace(-2.5, 2.5, 6)"],
     op="np.round(a)")

auto(topic="numpy", diff="medium", tags=["math", "round"], title="Round to decimals", ask="Round every element to `d` decimal places.",
     args=["a = np.array([1.2345, 2.3456])\nd = 2", "a = np.random.rand(3)\nd = 3", "a = np.array([[9.876]])\nd = 1"],
     op="np.round(a, d)")

auto(topic="numpy", diff="easy", tags=["math", "floor"], title="Floor and ceiling", ask="Return `(floor(a), ceil(a))`.",
     args=["a = np.array([1.2, -1.2, 0.0])", "a = np.random.randn(2, 3)", "a = np.linspace(-1.5, 1.5, 5)"],
     op="(np.floor(a), np.ceil(a))")

auto(topic="numpy", diff="medium", tags=["math", "trunc"], title="Truncate toward zero", ask="Return `np.trunc(a)`.",
     args=["a = np.array([1.7, -1.7, 0.2])", "a = np.random.randn(4) * 5", "a = np.array([[-2.9, 2.9]])"],
     op="np.trunc(a)")

auto(topic="numpy", diff="medium", tags=["math", "mod"], title="Modulo", ask="Return `a` modulo `m` (same sign as the divisor).",
     args=["a = np.array([5, -5, 2])\nm = 3", "a = np.arange(-4, 5)\nm = 4", "a = np.array([[7.5]])\nm = 2.0"],
     op="np.mod(a, m)")

auto(topic="numpy", diff="medium", tags=["math"], title="Floor division", ask="Return the elementwise floor division `a // d`.",
     args=["a = np.array([7, -7, 9])\nd = 2", "a = np.arange(10)\nd = 3", "a = np.array([[5.5, -5.5]])\nd = 2.0"],
     op="np.floor_divide(a, d)")

auto(topic="numpy", diff="medium", tags=["math"], title="Power", ask="Raise every element of `a` to the power `p`.",
     args=["a = np.array([1.0, 2.0, 3.0])\np = 3.0", "a = np.random.rand(2, 2)\np = 0.5", "a = np.arange(1, 6).astype(float)\np = -1"],
     op="np.power(a, p)")

auto(topic="numpy", diff="medium", tags=["math", "max"], title="Elementwise maximum", ask="Return the elementwise maximum of `a` and `b`.",
     args=["a = np.array([1, 5, 3])\nb = np.array([4, 2, 6])", "a = np.random.randn(3, 3)\nb = 0.0",
           "a = np.arange(4)\nb = np.full(4, 2)"],
     op="np.maximum(a, b)")

auto(topic="numpy", diff="medium", tags=["math", "min"], title="Elementwise minimum", ask="Return the elementwise minimum of `a` and `b`.",
     args=["a = np.array([1, 5, 3])\nb = np.array([4, 2, 6])", "a = np.random.randn(3)\nb = 0.0",
           "a = np.arange(4)\nb = np.full(4, 2)"],
     op="np.minimum(a, b)")

auto(topic="numpy", diff="medium", tags=["math", "hypot"], title="Hypotenuse", ask="Return `sqrt(a^2 + b^2)` using the stable `np.hypot`.",
     args=["a = np.array([3.0, 5.0])\nb = np.array([4.0, 12.0])", "a = np.random.randn(3)\nb = np.random.randn(3)",
           "a = np.ones(2)\nb = np.ones(2)"],
     op="np.hypot(a, b)")

auto(topic="numpy", diff="medium", tags=["math", "nan"], title="Replace NaN", ask="Replace NaN with 0 and infinities with the given large values using `np.nan_to_num`.",
     args=["a = np.array([np.nan, np.inf, -np.inf, 2.0])\npos = 1e9\nneg = -1e9",
           "a = np.array([np.nan])\npos = 0.0\nneg = 0.0", "a = np.array([[np.inf, 1.0]])\npos = 5.0\nneg = -5.0"],
     op="np.nan_to_num(a, posinf=pos, neginf=neg)")

auto(topic="numpy", diff="medium", tags=["math", "isclose"], title="Elementwise closeness", ask="Return a boolean array using `np.isclose(a, b)` (default tolerances).",
     args=["a = np.array([1.0, 1.0000001, 2.0])\nb = np.array([1.0, 1.0, 3.0])",
           "a = np.random.randn(3)\nb = a.copy()", "a = np.array([0.0])\nb = np.array([1e-9])"],
     op="np.isclose(a, b)")

# =========================================================================== #
#  Reductions
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["reduction"], title="Sum", ask="Return the sum of all elements.",
     args=["a = np.arange(10)", "a = np.random.randn(3, 4)", "a = np.ones((2, 3))"],
     op="np.sum(a)")

auto(topic="numpy", diff="easy", tags=["reduction", "axis"], title="Sum along an axis", ask="Sum `a` along `axis`.",
     args=["a = np.random.randn(3, 4)\naxis = 0", "a = np.random.randn(3, 4)\naxis = 1", "a = np.random.randn(2, 3, 4)\naxis = 2"],
     op="np.sum(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "keepdims"], title="Sum keeping dims", ask="Sum `a` along `axis` while keeping that axis (result has size 1 there).",
     args=["a = np.random.randn(3, 4)\naxis = 0", "a = np.random.randn(3, 4)\naxis = 1", "a = np.random.randn(5)\naxis = 0"],
     op="np.sum(a, axis=axis, keepdims=True)")

auto(topic="numpy", diff="easy", tags=["reduction", "mean"], title="Mean", ask="Return the mean of `a`.",
     args=["a = np.arange(6)", "a = np.random.randn(3, 4)", "a = np.array([[2.0, 4.0]])"],
     op="np.mean(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "mean", "axis"], title="Mean along an axis", ask="Return the mean of `a` along `axis`.",
     args=["a = np.random.randn(4, 3)\naxis = 0", "a = np.random.randn(4, 3)\naxis = 1", "a = np.random.randn(2, 2, 5)\naxis = -1"],
     op="np.mean(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "std"], title="Standard deviation (population)", ask="Return the population standard deviation of `a` (ddof=0).",
     args=["a = np.random.randn(4, 5)", "a = np.arange(10)", "a = np.ones((3, 3))"],
     op="np.std(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "std", "ddof"], title="Sample standard deviation", ask="Return the sample standard deviation (ddof=1) along `axis`.",
     args=["a = np.random.randn(4, 5)\naxis = 0", "a = np.random.randn(10)\naxis = 0", "a = np.random.randn(3, 6)\naxis = 1"],
     op="np.std(a, axis=axis, ddof=1)")

auto(topic="numpy", diff="medium", tags=["reduction", "var"], title="Variance", ask="Return the population variance of `a` along `axis`.",
     args=["a = np.random.randn(4, 5)\naxis = 0", "a = np.random.randn(4, 5)\naxis = 1", "a = np.arange(8)\naxis = 0"],
     op="np.var(a, axis=axis)")

auto(topic="numpy", diff="easy", tags=["reduction", "min"], title="Minimum", ask="Return the smallest element of `a`.",
     args=["a = np.array([3, -1, 2])", "a = np.random.randn(3, 4)", "a = np.array([[5.0, 0.5]])"],
     op="np.min(a)")

auto(topic="numpy", diff="easy", tags=["reduction", "max"], title="Maximum", ask="Return the largest element of `a`.",
     args=["a = np.array([3, -1, 2])", "a = np.random.randn(3, 4)", "a = np.array([[5.0, 0.5]])"],
     op="np.max(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "argmin"], title="Index of the minimum", ask="Return the flat index of the minimum element.",
     args=["a = np.array([3, -1, 2])", "a = np.array([[4, 1], [0.5, 2]])", "a = np.random.randn(8)"],
     op="np.argmin(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "argmax"], title="Index of the maximum along an axis", ask="Return the index of the maximum along `axis`.",
     args=["a = np.random.randn(3, 4)\naxis = 0", "a = np.random.randn(3, 4)\naxis = 1", "a = np.array([[1, 9], [3, 2]])\naxis = 1"],
     op="np.argmax(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "ptp"], title="Peak-to-peak range", ask="Return `max(a) - min(a)` using `np.ptp`.",
     args=["a = np.array([3, -1, 2])", "a = np.random.randn(3, 4)", "a = np.arange(10).reshape(2, 5)"],
     op="np.ptp(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "prod"], title="Product", ask="Return the product of all elements.",
     args=["a = np.array([1, 2, 3, 4])", "a = np.ones((2, 2))", "a = np.array([[2.0, -3.0]])"],
     op="np.prod(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "cumsum"], title="Cumulative sum", ask="Return the cumulative sum along `axis`.",
     args=["a = np.array([1, 2, 3, 4])\naxis = 0", "a = np.arange(6).reshape(2, 3)\naxis = 1", "a = np.ones((4, 2))\naxis = 0"],
     op="np.cumsum(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "cumprod"], title="Cumulative product", ask="Return the cumulative product along `axis`.",
     args=["a = np.array([1, 2, 3])\naxis = 0", "a = np.array([[1, 2], [3, 4]])\naxis = 1", "a = np.full(3, 0.5)\naxis = 0"],
     op="np.cumprod(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "median"], title="Median", ask="Return the median of `a`.",
     args=["a = np.array([3.0, 1.0, 2.0, 4.0])", "a = np.random.randn(4, 5)", "a = np.arange(7)"],
     op="np.median(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "median"], title="Median along an axis", ask="Return the median along `axis`.",
     args=["a = np.random.randn(4, 5)\naxis = 0", "a = np.random.randn(4, 5)\naxis = 1", "a = np.arange(6).reshape(2, 3)\naxis = 1"],
     op="np.median(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "percentile"], title="Percentile", ask="Return the `q`-th percentile of `a` (linear interpolation).",
     args=["a = np.arange(10.0)\nq = 50", "a = np.random.randn(20)\nq = 90", "a = np.array([[1.0, 2.0, 3.0, 4.0]])\nq = 25"],
     op="np.percentile(a, q)")

auto(topic="numpy", diff="medium", tags=["reduction", "percentile"], title="Percentiles along an axis", ask="Return the percentiles `qs` along `axis`.",
     args=["a = np.random.randn(4, 5)\nqs = [25, 75]\naxis = 0", "a = np.random.randn(3, 6)\nqs = [10, 50, 90]\naxis = 1",
           "a = np.arange(10.0)\nqs = [0, 100]\naxis = 0"],
     op="np.percentile(a, qs, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "quantile"], title="Quantile", ask="Return the quantile `q` (in [0, 1]) of `a`.",
     args=["a = np.arange(10.0)\nq = 0.5", "a = np.random.randn(10)\nq = 0.25", "a = np.linspace(0, 1, 11)\nq = 0.9"],
     op="np.quantile(a, q)")

auto(topic="numpy", diff="medium", tags=["reduction", "average"], title="Weighted average", ask="Return the weighted average of `a` with weights `w`.",
     args=["a = np.array([1.0, 2.0, 3.0])\nw = np.array([1.0, 1.0, 2.0])",
           "a = np.random.randn(5)\nw = np.arange(1, 6).astype(float)", "a = np.array([1.0, 5.0])\nw = np.array([3.0, 1.0])"],
     op="np.average(a, weights=w)")

auto(topic="numpy", diff="medium", tags=["reduction", "count_nonzero"], title="Count non-zeros", ask="Return how many elements are non-zero.",
     args=["a = np.array([0, 1, 0, 2])", "a = np.zeros((3, 3))", "a = np.random.randn(10)"],
     op="np.count_nonzero(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "any"], title="Any and all", ask="Return the tuple `(np.any(a), np.all(a))` for the boolean array `a`.",
     args=["a = np.array([True, False, True])", "a = np.ones(2, dtype=bool)", "a = np.zeros(3, dtype=bool)"],
     op="(np.any(a), np.all(a))")

auto(topic="numpy", diff="medium", tags=["reduction", "any", "axis"], title="Any along an axis", ask="Return `np.any(a, axis=axis)` for the boolean array `a`.",
     args=["a = np.array([[True, False], [False, False]])\naxis = 1",
           "a = np.eye(3, dtype=bool)\naxis = 0", "a = np.zeros((2, 3), dtype=bool)\naxis = 1"],
     op="np.any(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["reduction", "nan"], title="Sum ignoring NaN", ask="Return the sum of `a` ignoring NaN (`np.nansum`).",
     args=["a = np.array([1.0, np.nan, 3.0])", "a = np.random.randn(3, 3)", "a = np.array([np.nan, np.nan])"],
     op="np.nansum(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "nan"], title="Mean ignoring NaN", ask="Return the mean of `a` ignoring NaN.",
     args=["a = np.array([1.0, np.nan, 3.0])", "a = np.random.randn(2, 3)", "a = np.array([[np.nan, 4.0]])"],
     op="np.nanmean(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "nan"], title="Detect NaN", ask="Return a boolean array that is True where `a` is NaN.",
     args=["a = np.array([1.0, np.nan])", "a = np.random.randn(2, 3)", "a = np.array([[np.nan, np.inf]])"],
     op="np.isnan(a)")

auto(topic="numpy", diff="medium", tags=["reduction", "argmax", "nan"], title="Argmax ignoring NaN", ask="Return the index of the maximum ignoring NaN using `np.nanargmax`.",
     args=["a = np.array([1.0, np.nan, 3.0])", "a = np.array([np.nan, 5.0, 2.0])", "a = np.array([[np.nan, 1.0]])"],
     op="np.nanargmax(a)")

# =========================================================================== #
#  Sorting & searching
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["sorting"], title="Sort ascending", ask="Return a sorted copy of `a` (ascending).",
     args=["a = np.array([3, 1, 2])", "a = np.random.randn(5)", "a = np.array([[3.0, 1.0], [2.0, 4.0]])"],
     op="np.sort(a)")

auto(topic="numpy", diff="medium", tags=["sorting", "axis"], title="Sort along an axis", ask="Sort `a` along `axis`.",
     args=["a = np.array([[3, 1], [2, 4]])\naxis = 0", "a = np.array([[3, 1], [2, 4]])\naxis = 1",
           "a = np.random.randn(3, 4)\naxis = 1"],
     op="np.sort(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["sorting"], title="Argsort", ask="Return the indices that would sort `a` ascending.",
     args=["a = np.array([3.0, 1.0, 2.0])", "a = np.array([0.0, 0.0, -1.0])", "a = np.random.randn(6)"],
     op="np.argsort(a)")

auto(topic="numpy", diff="medium", tags=["sorting", "descending"], title="Sort descending", ask="Return `a` sorted in descending order.",
     args=["a = np.array([3, 1, 2])", "a = np.random.randn(5)", "a = np.array([[1.0, 5.0, 2.0]])"],
     op="np.sort(a)[::-1]")

auto(topic="numpy", diff="medium", tags=["sorting", "unique"], title="Unique values", ask="Return the sorted unique values of `a`.",
     args=["a = np.array([3, 1, 2, 3, 1])", "a = np.random.randint(0, 5, 10)", "a = np.array([[1, 1], [2, 2]])"],
     op="np.unique(a)")

auto(topic="numpy", diff="medium", tags=["sorting", "unique"], title="Unique with counts", ask="Return `np.unique(a, return_counts=True)` — the tuple `(values, counts)`.",
     args=["a = np.array([1, 1, 2, 3, 3, 3])", "a = np.random.randint(0, 3, 12)", "a = np.array([5])"],
     op="np.unique(a, return_counts=True)")

auto(topic="numpy", diff="medium", tags=["sorting", "searchsorted"], title="Searchsorted", ask="Return the insertion positions for `v` in the sorted array `a` (`side='left'`).",
     args=["a = np.array([1, 3, 5, 7])\nv = np.array([0, 3, 4, 9])", "a = np.array([2.0])\nv = np.array([1.0, 2.0, 3.0])",
           "a = np.arange(0, 10, 2)\nv = np.array([1, 6])"],
     op="np.searchsorted(a, v, side='left')")

auto(topic="numpy", diff="medium", tags=["sorting", "bincount"], title="Bincount", ask="Return the counts of each non-negative integer in `a` using `np.bincount`.",
     args=["a = np.array([0, 1, 1, 3])", "a = np.array([2, 2, 2])", "a = np.zeros(5, dtype=int)"],
     op="np.bincount(a)")

auto(topic="numpy", diff="medium", tags=["sorting", "digitize"], title="Digitize", ask="Return the bin index of each value in `a` given the increasing bin edges `bins`.",
     args=["a = np.array([0.5, 1.5, 2.5])\nbins = np.array([0.0, 1.0, 2.0, 3.0])",
           "a = np.array([-1.0, 5.0])\nbins = np.array([0.0])", "a = np.array([[0.2, 0.8]])\nbins = np.array([0.0, 0.5, 1.0])"],
     op="np.digitize(a, bins)")

auto(topic="numpy", diff="medium", tags=["sorting", "partition"], title="k smallest values", ask="Return the `k` smallest values (sorted) using `np.partition`.",
     args=["a = np.array([5.0, 1.0, 4.0, 2.0, 3.0])\nk = 3", "a = np.random.randn(10)\nk = 2", "a = np.array([[3, 1, 2]])\nk = 1"],
     op="np.sort(np.partition(a, k - 1)[..., :k])")

auto(topic="numpy", diff="hard", tags=["sorting", "lexsort"], title="Sort rows by the last column",
     ask="`a` is (n, m). Return its rows sorted by the **last** column ascending, ties "
         "preserved. Use `np.lexsort` (keys are the *last* primary key).",
     args=["a = np.array([[1, 5], [2, 3], [3, 5]])", "a = np.random.randn(6, 3)", "a = np.array([[0.1, 2.0], [0.2, 1.0]])"],
     op="a[np.lexsort((np.arange(a.shape[0]), a[:, -1]))]")

auto(topic="numpy", diff="hard", tags=["sorting"], title="Sort rows by a column",
     ask="Return the rows of `a` sorted by column `c` ascending.",
     args=["a = np.array([[3, 1], [1, 2], [2, 0]])\nc = 0", "a = np.random.randn(5, 3)\nc = 2",
           "a = np.array([[5.0, 2.0]])\nc = 1"],
     op="a[np.argsort(a[:, c])]")

# =========================================================================== #
#  Statistics & standard recipes
# =========================================================================== #
q(topic="numpy", diff="medium", tags=["stats", "corrcoef"], title="Correlation matrix",
  ask="Return the Pearson correlation matrix of the columns of the 2-D array `a`.",
  sig="solve(a)", sol="return np.corrcoef(a, rowvar=False)",
  mk="""
  cases = [(np.random.randn(20, 3),), (np.random.randn(10, 2),), (np.arange(20).reshape(10, 2).astype(float),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  props=["assert np.allclose(np.diagonal(_got), 1.0), 'correlations of a variable with itself are 1'"],
  hints=["`rowvar=False` treats columns as the variables.",
         "The diagonal is always 1."])

q(topic="numpy", diff="medium", tags=["stats", "cov"], title="Covariance matrix",
  ask="Return the covariance matrix of the rows of `a` (`np.cov`, default ddof=1).",
  sig="solve(a)", sol="return np.cov(a)",
  mk="""
  cases = [(np.random.randn(4, 20),), (np.random.randn(2, 10),), (np.arange(10).reshape(2, 5).astype(float),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  props=["assert _got.shape[0] == _got.shape[1], 'covariance matrix is square'",
         "assert np.allclose(_got, _got.T, atol=1e-8), 'covariance matrix is symmetric'"],
  hints=["`np.cov` treats each row as a variable by default.",
         "The result is symmetric."])

q(topic="numpy", diff="medium", tags=["stats", "histogram"], title="Histogram counts",
  ask="Return only the counts of the histogram of `a` with `bins` equal-width bins.",
  sig="solve(a, bins)", sol="return np.histogram(a, bins=bins)[0]",
  mk="""
  cases = [(np.arange(10.0), 5), (np.random.randn(50), 4), (np.zeros(5), 2)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "bins"],
  props=["assert _got.shape == (_args[1],)", "assert _got.sum() == _args[0].size"],
  hints=["`np.histogram` returns `(counts, edges)`.",
         "The counts always sum to the number of samples."])

q(topic="numpy", diff="medium", tags=["stats", "zscore"], title="Z-score standardisation",
  ask="Standardise `a` to zero mean and unit variance (population std) and return it.",
  sig="solve(a)", sol="return (a - a.mean()) / a.std()",
  mk="""
  cases = [(np.random.randn(20) * 3 + 1,), (np.random.rand(5, 4),), (np.arange(10.0),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  props=["assert abs(float(_got.mean())) < 1e-8", "assert abs(float(_got.std()) - 1.0) < 1e-8"],
  hints=["Subtract the mean, divide by the std.",
         "Using `std(ddof=1)` here would not give unit standard deviation."])

q(topic="numpy", diff="medium", tags=["stats", "minmax"], title="Min-max scaling",
  ask="Scale `a` into `[0, 1]`: `(a - min) / (max - min)`.",
  sig="solve(a)", sol="return (a - a.min()) / (a.max() - a.min())",
  mk="""
  cases = [(np.random.randn(10),), (np.random.rand(3, 3) * 10,), (np.array([1.0, 5.0, 3.0]),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  props=["assert np.isclose(_got.min(), 0.0)", "assert np.isclose(_got.max(), 1.0)"],
  hints=["Shift by the minimum, then divide by the range.",
         "The largest value becomes exactly 1."])

q(topic="numpy", diff="medium", tags=["recipes", "softmax"], title="Softmax from scratch",
  ask="Implement a numerically stable softmax over the last axis of `a` (subtract the max).",
  sig="solve(a)", sol="""
  shifted = a - a.max(axis=-1, keepdims=True)
  e = np.exp(shifted)
  return e / e.sum(axis=-1, keepdims=True)
  """,
  mk="""
  cases = [(np.random.randn(3, 5),), (np.random.randn(4) * 10,), (np.array([[1000.0, 1001.0, 1002.0]]),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  props=["assert np.allclose(_got.sum(axis=-1), 1.0)", "assert (_got >= 0).all()"],
  hints=["The max shift prevents overflow without changing the result.",
         "Normalise along the same axis you subtracted on."])

q(topic="numpy", diff="medium", tags=["recipes", "logsumexp"], title="Log-sum-exp",
  ask="Compute `log(sum(exp(a)))` along the last axis in a stable way (keepdims), "
      "matching `scipy.special.logsumexp(a, axis=-1, keepdims=True)`.",
  sig="solve(a)", sol="""
  m = a.max(axis=-1, keepdims=True)
  return m + np.log(np.exp(a - m).sum(axis=-1, keepdims=True))
  """,
  mk="""
  cases = [(np.random.randn(3, 4),), (np.random.randn(2, 3) * 50,), (np.zeros((1, 5)),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  hints=["`m + log(sum(exp(a - m)))` is exact and overflow-free.",
         "Keep the reduced axis so broadcasting works."])

q(topic="numpy", diff="medium", tags=["recipes", "one-hot"], title="One-hot encoding",
  ask="`idx` is a 1-D integer array. Return the `(len(idx), classes)` one-hot matrix of "
      "dtype `float64`.",
  sig="solve(idx, classes)", sol="""
  out = np.zeros((idx.size, classes))
  out[np.arange(idx.size), idx] = 1.0
  return out
  """,
  mk="""
  cases = [(np.array([0, 2, 1]), 3), (np.array([0]), 1), (np.array([1, 1, 0, 2]), 4)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["idx", "classes"],
  props=["assert _got.shape == (_args[0].size, _args[1])",
         "assert np.allclose(_got.sum(axis=1), 1.0)"],
  hints=["Allocate zeros, then set one entry per row.",
         "Advanced indexing with two index arrays assigns the whole diagonal at once."])

q(topic="numpy", diff="hard", tags=["recipes", "distance"], title="Pairwise Euclidean distances",
  ask="Return the `(n, m)` matrix of Euclidean distances between the rows of `a` and the "
      "rows of `b`, without loops.",
  sig="solve(a, b)", sol="""
  diff = a[:, None, :] - b[None, :, :]
  return np.sqrt((diff ** 2).sum(axis=-1))
  """,
  mk="""
  cases = [(np.random.randn(3, 4), np.random.randn(5, 4)), (np.zeros((2, 2)), np.ones((2, 2))),
           (np.random.randn(1, 3), np.random.randn(1, 3),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  props=["""
  a, b = _args
  ref = np.linalg.norm(a[:, None, :] - b[None, :, :], axis=-1)
  assert np.allclose(_got, ref)
  """],
  hints=["Broadcast to `(n, m, d)` with `a[:, None, :]` and `b[None, :, :]`.",
         "Sum the squares over the last axis, then take the root."])

q(topic="numpy", diff="hard", tags=["recipes", "cosine"], title="Pairwise cosine similarity",
  ask="Return the `(n, m)` matrix of cosine similarities between rows of `a` and `b`.",
  sig="solve(a, b)", sol="""
  an = a / np.linalg.norm(a, axis=1, keepdims=True)
  bn = b / np.linalg.norm(b, axis=1, keepdims=True)
  return an @ bn.T
  """,
  mk="""
  cases = [(np.random.randn(3, 5), np.random.randn(4, 5)), (np.ones((2, 3)), np.ones((2, 3))),
           (np.random.randn(1, 2), np.random.randn(3, 2))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  props=["""
  a, b = _args
  assert _got.shape == (a.shape[0], b.shape[0])
  if a.shape[0] == b.shape[0]:
      assert np.allclose(np.diagonal(_got), 1.0), "cosine of a row with itself is 1"
  """],
  hints=["Normalise each row first.",
         "The dot product of unit vectors is their cosine."])

q(topic="numpy", diff="medium", tags=["recipes", "moving-average"], title="Moving average",
  ask="Return the moving average of `x` over a window of `w` (valid positions only, using "
      "`np.convolve` with `mode='valid'` divided by `w`).",
  sig="solve(x, w)", sol="return np.convolve(x, np.ones(w) / w, mode='valid')",
  mk="""
  cases = [(np.arange(10.0), 3), (np.random.randn(8), 2), (np.arange(5.0), 5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "w"],
  props=["assert _got.shape == (_args[0].size - _args[1] + 1,)"],
  hints=["Convolving with `ones(w)/w` averages each window.",
         "`mode='valid'` drops the padded positions."])

q(topic="numpy", diff="medium", tags=["recipes", "diff"], title="Successive differences",
  ask="Return the first-order differences of `a` along the last axis (`np.diff`).",
  sig="solve(a)", sol="return np.diff(a)",
  mk="""
  cases = [(np.array([1, 4, 9, 16]),), (np.random.randn(3, 5),), (np.arange(10.0),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a"],
  props=["assert _got.shape[-1] == _args[0].shape[-1] - 1"],
  hints=["The result is one shorter than the input.",
         "`np.diff` subtracts neighbours."])

q(topic="numpy", diff="hard", tags=["recipes", "cumsum-window"], title="Windowed sum via cumsum",
  ask="Return the sum of every consecutive window of length `w` using a cumulative sum "
      "(one subtraction per position, no loop over windows).",
  sig="solve(x, w)", sol="""
  c = np.concatenate([[0.0], np.cumsum(x)])
  return c[w:] - c[:-w]
  """,
  mk="""
  cases = [(np.arange(10.0), 3), (np.random.randn(6), 2), (np.ones(5), 5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "w"],
  props=["m = np.convolve(_args[0], np.ones(_args[1]), mode='valid')",
         "assert np.allclose(_got, m)"],
  hints=["Prepend a zero to the cumulative sum.",
         "Subtract the prefix sums `w` apart — this is O(n)."])

q(topic="numpy", diff="medium", tags=["recipes", "interp"], title="Linear interpolation",
  ask="Interpolate the values of `y` (defined at `xp`) at the query points `x` using "
      "`np.interp`.",
  sig="solve(x, xp, y)", sol="return np.interp(x, xp, y)",
  mk="""
  cases = [(np.array([0.5, 1.5]), np.array([0.0, 1.0, 2.0]), np.array([0.0, 10.0, 20.0])),
           (np.array([-1.0, 3.0]), np.array([0.0, 2.0]), np.array([0.0, 4.0])),
           (np.linspace(0, 1, 5), np.linspace(0, 1, 3), np.array([1.0, 2.0, 3.0]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "xp", "y"],
  props=["assert _got.shape == _args[0].shape"],
  hints=["`xp` must be increasing.",
         "Points outside the range are clamped to the edge values."])

q(topic="numpy", diff="medium", tags=["recipes", "gradient"], title="Numerical gradient",
  ask="Return the numerical gradient of `y` with respect to `x` using `np.gradient(y, x)`.",
  sig="solve(y, x)", sol="return np.gradient(y, x)",
  mk="""
  cases = [(np.array([0.0, 1.0, 4.0, 9.0]), np.array([0.0, 1.0, 2.0, 3.0])),
           (np.array([1.0, 2.0, 4.0]), np.array([0.0, 2.0, 4.0])),
           (np.linspace(0, 4, 5) ** 2, np.linspace(0, 4, 5))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["y", "x"],
  props=["assert _got.shape == _args[0].shape"],
  hints=["The spacing `x` can be non-uniform.",
         "Interior points use central differences."])

q(topic="numpy", diff="medium", tags=["linalg", "poly"], title="Polynomial fit",
  ask="Fit a degree-`deg` polynomial to `(x, y)` with `np.polyfit` and return the "
      "coefficients (highest power first).",
  sig="solve(x, y, deg)", sol="return np.polyfit(x, y, deg)",
  mk="""
  x = np.linspace(-2, 2, 30)
  return (x, 3 * x ** 2 - 2 * x + 1, 2)
  """, arg_names=["x", "y", "deg"],
  props=["assert np.allclose(_got, [3.0, -2.0, 1.0], atol=1e-6)"],
  hints=["`np.polyfit` returns coefficients from the highest power down.",
         "For exact quadratic data the fit is exact."])

q(topic="numpy", diff="medium", tags=["linalg", "poly"], title="Evaluate a polynomial",
  ask="Evaluate the polynomial with coefficients `coef` (highest power first) at `x` "
      "using `np.polyval`.",
  sig="solve(coef, x)", sol="return np.polyval(coef, x)",
  mk="""
  cases = [(np.array([1.0, -2.0, 1.0]), np.array([0.0, 1.0, 2.0])),
           (np.array([2.0]), np.array([1.0, 3.0])), (np.array([1.0, 0.0]), np.arange(4.0))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["coef", "x"],
  props=["assert _got.shape == _args[1].shape"],
  hints=["`polyval` uses Horner's method.",
         "`[1, -2, 1]` is `x^2 - 2x + 1`."])

# =========================================================================== #
#  Linear algebra
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["linalg", "matmul"], title="Matrix product", ask="Return `a @ b`.",
     args=["a = np.random.randn(3, 4)\nb = np.random.randn(4, 2)", "a = np.eye(3)\nb = np.random.randn(3, 3)",
           "a = np.random.randn(1, 5)\nb = np.random.randn(5, 1)"],
     op="a @ b")

auto(topic="numpy", diff="medium", tags=["linalg", "dot"], title="np.dot", ask="Return the dot product `np.dot(a, b)`.",
     args=["a = np.random.randn(3)\nb = np.random.randn(3)", "a = np.random.randn(2, 3)\nb = np.random.randn(3, 4)",
           "a = np.random.randn(4)\nb = np.random.randn(4, 2)"],
     op="np.dot(a, b)")

auto(topic="numpy", diff="medium", tags=["linalg", "inner"], title="Inner product", ask="Return `np.inner(a, b)` (sum over the last axis of both).",
     args=["a = np.random.randn(3)\nb = np.random.randn(3)", "a = np.random.randn(2, 3)\nb = np.random.randn(4, 3)",
           "a = np.random.randn(1, 5)\nb = np.random.randn(5)"],
     op="np.inner(a, b)")

auto(topic="numpy", diff="medium", tags=["linalg", "outer"], title="Outer product", ask="Return the outer product of the 1-D arrays `a` and `b`.",
     args=["a = np.random.randn(3)\nb = np.random.randn(4)", "a = np.array([1.0, 2.0])\nb = np.array([3.0])",
           "a = np.ones(2)\nb = np.ones(2)"],
     op="np.outer(a, b)")

auto(topic="numpy", diff="medium", tags=["linalg", "trace"], title="Trace", ask="Return the trace (sum of the diagonal) of `a`.",
     args=["a = np.random.randn(3, 3)", "a = np.eye(4)", "a = np.arange(9).reshape(3, 3)"],
     op="np.trace(a)")

auto(topic="numpy", diff="medium", tags=["linalg", "trace"], title="Trace with offset", ask="Return the trace along the diagonal offset by `k`.",
     args=["a = np.arange(9).reshape(3, 3)\nk = 1", "a = np.arange(16).reshape(4, 4)\nk = -2",
           "a = np.ones((3, 3))\nk = 0"],
     op="np.trace(a, offset=k)")

auto(topic="numpy", diff="medium", tags=["linalg", "det"], title="Determinant", ask="Return the determinant of the square matrix `a`.",
     args=["a = np.array([[2.0, 0.0], [0.0, 3.0]])", "a = np.eye(4)", "a = np.array([[1.0, 2.0], [3.0, 4.0]])"],
     op="np.linalg.det(a)")

q(topic="numpy", diff="medium", tags=["linalg", "inv"], title="Matrix inverse",
  ask="Return the inverse of the invertible matrix `a` using `np.linalg.inv`.",
  sig="solve(a)", sol="return np.linalg.inv(a)",
  mk="""
  M = np.random.randn(3, 3)
  return (M @ M.T + 3.0 * np.eye(3),)
  """, arg_names=["a"],
  props=["assert np.allclose(_got @ _args[0], np.eye(3), atol=1e-8), 'A @ inv(A) must be the identity'"],
  hints=["Only square, non-singular matrices are invertible.",
         "Check your answer with `A @ inv(A)`."])

q(topic="numpy", diff="medium", tags=["linalg", "solve"], title="Solve a linear system",
  ask="Solve `a @ x = b` for `x` using `np.linalg.solve`.",
  sig="solve(a, b)", sol="return np.linalg.solve(a, b)",
  mk="""
  M = np.random.randn(3, 3)
  A = M @ M.T + 2.0 * np.eye(3)
  return (A, np.random.randn(3))
  """, arg_names=["a", "b"],
  props=["assert np.allclose(_args[0] @ _got, _args[1], atol=1e-8)"],
  hints=["`solve` is more stable than multiplying by the inverse.",
         "Verify with `a @ x`."])

auto(topic="numpy", diff="medium", tags=["linalg", "norm"], title="Vector norm", ask="Return the L2 norm of `a` along `axis`.",
     args=["a = np.random.randn(3, 4)\naxis = 1", "a = np.random.randn(5)\naxis = 0", "a = np.random.randn(2, 3)\naxis = 0"],
     op="np.linalg.norm(a, axis=axis)")

auto(topic="numpy", diff="medium", tags=["linalg", "norm"], title="L1 norm", ask="Return the L1 norm (sum of absolute values) of the vector `a`.",
     args=["a = np.array([3.0, -4.0])", "a = np.random.randn(6)", "a = np.array([[-1.0, 2.0, -3.0]])"],
     op="np.linalg.norm(a, ord=1)")

auto(topic="numpy", diff="medium", tags=["linalg", "norm"], title="Frobenius norm", ask="Return the Frobenius norm of the matrix `a`.",
     args=["a = np.random.randn(3, 4)", "a = np.eye(3)", "a = np.ones((2, 2))"],
     op="np.linalg.norm(a, ord='fro')")

auto(topic="numpy", diff="hard", tags=["linalg", "eig"], title="Eigenvalues of a symmetric matrix", ask="Return the eigenvalues (ascending) of the symmetric matrix `a` using `np.linalg.eigvalsh`.",
     args=["a = np.array([[2.0, 1.0], [1.0, 2.0]])", "a = np.eye(4)", "a = np.diag(np.array([3.0, 1.0, 2.0]))"],
     op="np.linalg.eigvalsh(a)")

auto(topic="numpy", diff="hard", tags=["linalg", "svd"], title="Singular values", ask="Return the singular values of `a` using `np.linalg.svd(..., compute_uv=False)`.",
     args=["a = np.array([[3.0, 0.0], [0.0, 2.0]])", "a = np.ones((2, 2))", "a = np.random.randn(4, 3)"],
     op="np.linalg.svd(a, compute_uv=False)")

auto(topic="numpy", diff="medium", tags=["linalg", "rank"], title="Matrix rank", ask="Return the rank of `a`.",
     args=["a = np.eye(3)", "a = np.ones((3, 3))", "a = np.array([[1.0, 2.0], [2.0, 4.0]])"],
     op="np.linalg.matrix_rank(a)")

auto(topic="numpy", diff="hard", tags=["linalg", "cholesky"], title="Cholesky factor", ask="Return the lower Cholesky factor of the positive-definite matrix `a`.",
     args=["a = np.array([[4.0, 2.0], [2.0, 3.0]])", "a = np.eye(3) * 2", "a = np.array([[9.0]])"],
     op="np.linalg.cholesky(a)")

auto(topic="numpy", diff="hard", tags=["linalg", "kron"], title="Kronecker product", ask="Return `np.kron(a, b)`.",
     args=["a = np.array([[1.0, 2.0], [3.0, 4.0]])\nb = np.eye(2)", "a = np.ones((2, 2))\nb = np.arange(4).reshape(2, 2)",
           "a = np.array([[2.0]])\nb = np.array([[1.0, 0.0], [0.0, 1.0]])"],
     op="np.kron(a, b)")

auto(topic="numpy", diff="medium", tags=["linalg", "cross"], title="Cross product", ask="Return the cross product of the 3-vectors `a` and `b`.",
     args=["a = np.array([1.0, 0.0, 0.0])\nb = np.array([0.0, 1.0, 0.0])", "a = np.random.randn(3)\nb = np.random.randn(3)",
           "a = np.array([0.0, 0.0, 1.0])\nb = np.array([1.0, 0.0, 0.0])"],
     op="np.cross(a, b)")

q(topic="numpy", diff="hard", tags=["linalg", "lstsq"], title="Least squares",
  ask="Return only the solution `x` of `np.linalg.lstsq(a, b, rcond=None)`.",
  sig="solve(a, b)", sol="return np.linalg.lstsq(a, b, rcond=None)[0]",
  mk="""
  x = np.random.randn(4, 3)
  coef = np.array([1.0, -2.0, 0.5])
  return (x, x @ coef)
  """, arg_names=["a", "b"],
  props=["assert np.allclose(_got, [1.0, -2.0, 0.5], atol=1e-6)"],
  hints=["`lstsq` returns a tuple; index `[0]` for the solution.",
         "For consistent systems it recovers the exact coefficients."])

q(topic="numpy", diff="hard", tags=["linalg", "multi_dot"], title="Chain matrix product",
  ask="Compute the product `a @ b @ c` with `np.linalg.multi_dot`, which chooses a cheap "
      "multiplication order.",
  sig="solve(a, b, c)", sol="return np.linalg.multi_dot([a, b, c])",
  mk="""
  cases = [(np.random.randn(2, 5), np.random.randn(5, 3), np.random.randn(3, 4)),
           (np.eye(2), np.random.randn(2, 2), np.eye(2)),
           (np.random.randn(1, 3), np.random.randn(3, 2), np.random.randn(2, 1))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b", "c"],
  props=["assert np.allclose(_got, _args[0] @ _args[1] @ _args[2], atol=1e-8)"],
  hints=["`multi_dot` orders the multiplications to minimise flops.",
         "It is equivalent to the plain chain product."])

# =========================================================================== #
#  Broadcasting & fancy tricks
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["broadcast"], title="Add a row vector", ask="Add the row vector `b` to every row of `a`.",
     args=["a = np.random.randn(3, 4)\nb = np.random.randn(4)", "a = np.random.randn(2, 2, 3)\nb = np.random.randn(3)",
           "a = np.zeros((5, 1))\nb = np.array([1.0])"],
     op="a + b")

auto(topic="numpy", diff="medium", tags=["broadcast"], title="Add a column vector", ask="Add the column vector `b` of shape `(n, 1)` to every column of `a`.",
     args=["a = np.random.randn(4, 3)\nb = np.random.randn(4, 1)", "a = np.zeros((3, 3))\nb = np.arange(3).reshape(3, 1)",
           "a = np.ones((2, 5))\nb = np.full((2, 1), 2.0)"],
     op="a + b")

auto(topic="numpy", diff="medium", tags=["broadcast", "shape"], title="Broadcast shape", ask="Return the shape that broadcasting `a` and `b` would produce, using `np.broadcast_shapes`.",
     args=["a = np.zeros((3, 1))\nb = np.zeros((1, 4))", "a = np.zeros((5,))\nb = np.zeros((2, 5))",
           "a = np.zeros((1, 3, 1))\nb = np.zeros((2, 1, 4))"],
     op="np.broadcast_shapes(a.shape, b.shape)")

auto(topic="numpy", diff="medium", tags=["broadcast"], title="Broadcast to a shape", ask="Return a read-only view of `a` broadcast to `shape` (`np.broadcast_to`).",
     args=["a = np.array([1, 2, 3])\nshape = (4, 3)", "a = np.ones((3, 1))\nshape = (3, 5)",
           "a = np.arange(2)\nshape = (2, 2)"],
     op="np.broadcast_to(a, shape)")

auto(topic="numpy", diff="medium", tags=["meshgrid"], title="Meshgrid", ask="Return the tuple `np.meshgrid(x, y, indexing='ij')`.",
     args=["x = np.arange(2)\ny = np.arange(3)", "x = np.array([0.0, 1.0])\ny = np.array([10.0])",
           "x = np.arange(3)\ny = np.arange(2)"],
     op="np.meshgrid(x, y, indexing='ij')")

auto(topic="numpy", diff="hard", tags=["einsum"], title="Einsum matmul", ask="Reproduce `a @ b` with `np.einsum('ij,jk->ik', a, b)`.",
     args=["a = np.random.randn(3, 4)\nb = np.random.randn(4, 2)", "a = np.eye(2)\nb = np.random.randn(2, 3)",
           "a = np.random.randn(5, 2)\nb = np.random.randn(2, 5)"],
     op="np.einsum('ij,jk->ik', a, b)")

auto(topic="numpy", diff="hard", tags=["einsum"], title="Einsum trace", ask="Return the trace of `a` using `np.einsum('ii->', a)`.",
     args=["a = np.random.randn(3, 3)", "a = np.eye(4)", "a = np.arange(9).reshape(3, 3)"],
     op="np.einsum('ii->', a)")

auto(topic="numpy", diff="hard", tags=["einsum"], title="Einsum diagonal", ask="Return the diagonal of `a` using `np.einsum('ii->i', a)`.",
     args=["a = np.random.randn(3, 3)", "a = np.eye(4)", "a = np.arange(9).reshape(3, 3)"],
     op="np.einsum('ii->i', a)")

auto(topic="numpy", diff="hard", tags=["tensordot"], title="Tensordot", ask="Return `np.tensordot(a, b, axes=1)` for the given 2-D inputs.",
     args=["a = np.random.randn(3, 4)\nb = np.random.randn(4, 2)", "a = np.eye(2)\nb = np.random.randn(2, 2)",
           "a = np.random.randn(1, 3)\nb = np.random.randn(3, 1)"],
     op="np.tensordot(a, b, axes=1)")

auto(topic="numpy", diff="hard", tags=["sliding-window"], title="Sliding windows", ask="Return all sliding windows of length `w` along the last axis using `np.lib.stride_tricks.sliding_window_view`.",
     args=["a = np.arange(10)\nw = 3", "a = np.arange(6)\nw = 2", "a = np.arange(5)\nw = 5"],
     op="np.lib.stride_tricks.sliding_window_view(a, w)")

auto(topic="numpy", diff="hard", tags=["apply_along_axis"], title="Apply along an axis", ask="Apply `np.max` along `axis` using `np.apply_along_axis`.",
     args=["a = np.random.randn(3, 4)\naxis = 0", "a = np.random.randn(3, 4)\naxis = 1", "a = np.arange(6).reshape(2, 3)\naxis = 1"],
     op="np.apply_along_axis(np.max, axis, a)")

auto(topic="numpy", diff="hard", tags=["take_along_axis"], title="Take along an axis", ask="Return `np.take_along_axis(a, idx, axis=1)` for the 2-D inputs.",
     args=["a = np.array([[10, 20, 30], [40, 50, 60]])\nidx = np.array([[0, 2], [1, 1]])",
           "a = np.arange(12).reshape(3, 4)\nidx = np.array([[3], [0], [2]])",
           "a = np.eye(2)\nidx = np.array([[1, 0], [0, 1]])"],
     op="np.take_along_axis(a, idx, axis=1)")

auto(topic="numpy", diff="medium", tags=["insert"], title="Insert values", ask="Insert `values` at position `pos` along the flattened array using `np.insert`.",
     args=["a = np.array([1, 2, 3])\npos = 1\nvalues = 99", "a = np.arange(4)\npos = 0\nvalues = -1",
           "a = np.array([5])\npos = 1\nvalues = 6"],
     op="np.insert(a, pos, values)")

auto(topic="numpy", diff="medium", tags=["delete"], title="Delete elements", ask="Delete the elements at `idx` using `np.delete`.",
     args=["a = np.array([1, 2, 3, 4])\nidx = 1", "a = np.arange(6)\nidx = [0, 5]", "a = np.array([7, 8])\nidx = 0"],
     op="np.delete(a, idx)")

auto(topic="numpy", diff="medium", tags=["append"], title="Append values", ask="Append `values` to the end of `a` using `np.append`.",
     args=["a = np.array([1, 2])\nvalues = np.array([3])", "a = np.arange(3)\nvalues = -1",
           "a = np.array([[1, 2]])\nvalues = np.array([[3, 4]])"],
     op="np.append(a, values)")

# =========================================================================== #
#  Sets & membership
# =========================================================================== #
auto(topic="numpy", diff="medium", tags=["sets"], title="Intersection", ask="Return the sorted intersection of the arrays `a` and `b`.",
     args=["a = np.array([1, 2, 3, 4])\nb = np.array([3, 4, 5])", "a = np.arange(5)\nb = np.arange(3, 8)",
           "a = np.array([1])\nb = np.array([2])"],
     op="np.intersect1d(a, b)")

auto(topic="numpy", diff="medium", tags=["sets"], title="Union", ask="Return the sorted union of `a` and `b`.",
     args=["a = np.array([1, 2])\nb = np.array([2, 3])", "a = np.arange(3)\nb = np.arange(5, 7)",
           "a = np.array([0])\nb = np.array([0])"],
     op="np.union1d(a, b)")

auto(topic="numpy", diff="medium", tags=["sets"], title="Difference", ask="Return the sorted values in `a` that are not in `b`.",
     args=["a = np.array([1, 2, 3, 4])\nb = np.array([2, 4])", "a = np.arange(5)\nb = np.arange(5, 9)",
           "a = np.array([1, 1, 2])\nb = np.array([2])"],
     op="np.setdiff1d(a, b)")

auto(topic="numpy", diff="medium", tags=["sets"], title="Membership mask", ask="Return a boolean array telling which elements of `a` appear in `b` (`np.isin`).",
     args=["a = np.array([1, 2, 3])\nb = np.array([2, 3, 4])", "a = np.arange(5)\nb = np.array([0, 4])",
           "a = np.array([[1, 2], [3, 4]])\nb = np.array([1])"],
     op="np.isin(a, b)")

auto(topic="numpy", diff="medium", tags=["sets"], title="Unique with inverse", ask="Return `np.unique(a, return_inverse=True)` — the tuple `(values, inverse)`.",
     args=["a = np.array([2, 1, 2, 3])", "a = np.array([5, 5])", "a = np.array([0, 1, 0])"],
     op="np.unique(a, return_inverse=True)")

# =========================================================================== #
#  Random number generation
# =========================================================================== #
auto(topic="numpy", diff="medium", tags=["random"], title="Seeded permutation", ask="Return a permutation of `n` from a generator seeded with `seed`.",
     args=["n = 5\nseed = 0", "n = 8\nseed = 3", "n = 1\nseed = 9"],
     op="np.random.default_rng(seed).permutation(n)")

auto(topic="numpy", diff="medium", tags=["random"], title="Seeded choice with replacement", ask="Draw `k` samples from `a` **with** replacement using a seeded generator.",
     args=["a = np.arange(5)\nk = 4\nseed = 1", "a = np.array([10, 20, 30])\nk = 2\nseed = 2",
           "a = np.arange(3)\nk = 6\nseed = 4"],
     op="np.random.default_rng(seed).choice(a, size=k, replace=True)")

auto(topic="numpy", diff="medium", tags=["random"], title="Seeded choice without replacement", ask="Draw `k` distinct samples from `a` using a seeded generator.",
     args=["a = np.arange(10)\nk = 3\nseed = 0", "a = np.arange(4)\nk = 4\nseed = 5", "a = np.array([1, 2, 3])\nk = 1\nseed = 7"],
     op="np.random.default_rng(seed).choice(a, size=k, replace=False)")

q(topic="numpy", diff="medium", tags=["random", "mut"], title="Shuffle in place",
  ask="Shuffle `a` in place with a generator seeded with `seed` and return `a`.",
  sig="solve(a, seed)", sol="""
  np.random.default_rng(seed).shuffle(a)
  return a
  """,
  mk="""
  cases = [(np.arange(10), 0), (np.arange(5), 3), (np.arange(2), 1)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "seed"], cmp="mut",
  hints=["`Generator.shuffle` mutates the array.",
         "Seeding makes the result reproducible."])

# =========================================================================== #
#  Strings, complex numbers, dates
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["strings"], title="Uppercase strings", ask="Return the array of strings converted to upper case with `np.char.upper`.",
     args=["a = np.array(['ab', 'Cd'])", "a = np.array(['tensor'])", "a = np.array([['x', 'y']])"],
     op="np.char.upper(a)")

auto(topic="numpy", diff="medium", tags=["strings"], title="Concatenate strings", ask="Concatenate the string arrays `a` and `b` elementwise with `np.char.add`.",
     args=["a = np.array(['foo', 'bar'])\nb = np.array(['!', '?'])", "a = np.array(['x'])\nb = np.array(['y'])",
           "a = np.array([['a', 'b']])\nb = np.array([['1', '2']])"],
     op="np.char.add(a, b)")

auto(topic="numpy", diff="medium", tags=["strings"], title="Strip whitespace", ask="Strip leading/trailing whitespace from every string with `np.char.strip`.",
     args=["a = np.array(['  a  ', ' b'])", "a = np.array([' c '])", "a = np.array([['  x', 'y  ']])"],
     op="np.char.strip(a)")

auto(topic="numpy", diff="medium", tags=["strings"], title="String replace", ask="Replace `old` with `new` in every string with `np.char.replace`.",
     args=["a = np.array(['aXb', 'XX'])\nold = 'X'\nnew = 'y'", "a = np.array(['abc'])\nold = 'b'\nnew = ''",
           "a = np.array([['a-a']])\nold = '-'\nnew = '+'"],
     op="np.char.replace(a, old, new)")

auto(topic="numpy", diff="medium", tags=["strings"], title="Find substring", ask="Return the position of `sub` in each string (`-1` when absent) with `np.char.find`.",
     args=["a = np.array(['abc', 'xyz'])\nsub = 'b'", "a = np.array(['hello'])\nsub = 'lo'",
           "a = np.array([['aa', 'ab']])\nsub = 'a'"],
     op="np.char.find(a, sub)")

auto(topic="numpy", diff="medium", tags=["strings"], title="Count occurrences", ask="Count how many times `sub` appears in each string with `np.char.count`.",
     args=["a = np.array(['aaa', 'ab'])\nsub = 'a'", "a = np.array(['xyz'])\nsub = 'q'",
           "a = np.array([['aa-bb']])\nsub = '-'"],
     op="np.char.count(a, sub)")

auto(topic="numpy", diff="medium", tags=["complex"], title="Real and imaginary parts", ask="Return the tuple `(a.real, a.imag)` for the complex array `a`.",
     args=["a = np.array([1 + 2j, 3 - 4j])", "a = np.array([1j])", "a = np.array([[2 + 0j]])"],
     op="(a.real, a.imag)")

auto(topic="numpy", diff="medium", tags=["complex"], title="Complex conjugate", ask="Return the complex conjugate of `a`.",
     args=["a = np.array([1 + 2j, 3 - 4j])", "a = np.array([5j])", "a = np.array([[2 + 0j]])"],
     op="np.conj(a)")

auto(topic="numpy", diff="medium", tags=["complex"], title="Magnitude of a complex number", ask="Return the magnitude (absolute value) of the complex array `a`.",
     args=["a = np.array([3 + 4j])", "a = np.array([1j, 2 - 2j])", "a = np.array([[0 + 0j]])"],
     op="np.abs(a)")

auto(topic="numpy", diff="hard", tags=["complex"], title="Phase angle", ask="Return the phase angle (in radians) of the complex array `a`.",
     args=["a = np.array([0 + 1j])", "a = np.array([1 + 0j])", "a = np.array([-1 - 1j])"],
     op="np.angle(a)")

auto(topic="numpy", diff="medium", tags=["datetime"], title="Datetime range", ask="Return monthly datetime64 values from `start` to `end` (exclusive).",
     args=["start = '2020-01'\nend = '2020-05'", "start = '2021-11'\nend = '2022-01'", "start = '2019-06'\nend = '2019-08'"],
     op="np.arange(start, end, dtype='datetime64[M]')")

auto(topic="numpy", diff="medium", tags=["datetime"], title="Add days to a date", ask="Add `days` to the datetime64 value `d`.",
     args=["d = np.datetime64('2020-01-01')\ndays = 10", "d = np.datetime64('2021-12-30')\ndays = 2",
           "d = np.datetime64('2000-02-28')\ndays = 1"],
     op="d + np.timedelta64(days, 'D')")

auto(topic="numpy", diff="medium", tags=["datetime"], title="Date to integer", ask="Convert the datetime64 array `a` (day precision) to `int64` days since the epoch.",
     args=["a = np.array(['2020-01-01'], dtype='datetime64[D]')", "a = np.array(['1970-01-02'], dtype='datetime64[D]')",
           "a = np.array(['2020-01-01', '2020-01-03'], dtype='datetime64[D]')"],
     op="a.astype(np.int64)")

auto(topic="numpy", diff="hard", tags=["datetime"], title="Weekday check", ask="Return a boolean array telling which days in `d` are business days (`np.is_busday`).",
     args=["d = np.array(['2024-01-01', '2024-01-06'], dtype='datetime64[D]')",
           "d = np.array(['2024-03-04'], dtype='datetime64[D]')", "d = np.array(['2024-12-25'], dtype='datetime64[D]')"],
     op="np.is_busday(d)")

# =========================================================================== #
#  FFT & signals
# =========================================================================== #
auto(topic="numpy", diff="hard", tags=["fft"], title="FFT magnitudes", ask="Return the absolute values of `np.fft.fft(x)`.",
     args=["x = np.array([1.0, 0.0, 0.0, 0.0])", "x = np.ones(4)", "x = np.array([1.0, -1.0, 1.0, -1.0])"],
     op="np.abs(np.fft.fft(x))")

auto(topic="numpy", diff="hard", tags=["fft"], title="FFT frequencies", ask="Return the bin frequencies for an FFT of length `n` with sample spacing `d`.",
     args=["n = 4\nd = 1.0", "n = 8\nd = 0.5", "n = 10\nd = 1.0"],
     op="np.fft.fftfreq(n, d)")

auto(topic="numpy", diff="hard", tags=["signals"], title="Convolution", ask="Return the full convolution of `a` and `b` with `np.convolve(a, b, mode='full')`.",
     args=["a = np.array([1.0, 2.0])\nb = np.array([1.0, 1.0])", "a = np.ones(3)\nb = np.array([1.0, -1.0])",
           "a = np.array([2.0])\nb = np.array([3.0])"],
     op="np.convolve(a, b, mode='full')")

auto(topic="numpy", diff="hard", tags=["signals"], title="Cross-correlation", ask="Return the cross-correlation of `a` and `b` with `np.correlate(a, b, mode='full')`.",
     args=["a = np.array([1.0, 2.0, 3.0])\nb = np.array([0.0, 1.0])", "a = np.ones(3)\nb = np.ones(3)",
           "a = np.array([1.0, -1.0])\nb = np.array([1.0, -1.0])"],
     op="np.correlate(a, b, mode='full')")

# =========================================================================== #
#  Misc / recipes
# =========================================================================== #
auto(topic="numpy", diff="easy", tags=["compare"], title="Array equality", ask="Return `np.array_equal(a, b)`.",
     args=["a = np.array([1, 2])\nb = np.array([1, 2])", "a = np.array([1, 2])\nb = np.array([1, 3])",
           "a = np.eye(2)\nb = np.eye(2)"],
     op="np.array_equal(a, b)")

auto(topic="numpy", diff="medium", tags=["compare"], title="Allclose", ask="Return `np.allclose(a, b)`.",
     args=["a = np.array([1.0, 2.0])\nb = np.array([1.0, 2.0 + 1e-9])", "a = np.zeros(3)\nb = np.ones(3)",
           "a = np.array([1e10])\nb = np.array([1e10 + 1])"],
     op="np.allclose(a, b)")

auto(topic="numpy", diff="medium", tags=["diagonal"], title="Diagonal with offset", ask="Return the diagonal of `a` offset by `k` using `np.diagonal`.",
     args=["a = np.arange(9).reshape(3, 3)\nk = 0", "a = np.arange(9).reshape(3, 3)\nk = 1",
           "a = np.arange(16).reshape(4, 4)\nk = -2"],
     op="np.diagonal(a, offset=k)")

auto(topic="numpy", diff="medium", tags=["cumsum", "max"], title="Running maximum", ask="Return the running maximum along the last axis (`np.maximum.accumulate`).",
     args=["a = np.array([1.0, 3.0, 2.0, 5.0])", "a = np.array([[1, 2], [5, 1]])", "a = np.array([-1.0, -5.0])"],
     op="np.maximum.accumulate(a)")

auto(topic="numpy", diff="medium", tags=["cumsum", "min"], title="Running minimum", ask="Return the running minimum along the last axis (`np.minimum.accumulate`).",
     args=["a = np.array([4.0, 3.0, 5.0, 1.0])", "a = np.array([[3, 2], [1, 5]])", "a = np.array([2.0, 8.0])"],
     op="np.minimum.accumulate(a)")

auto(topic="numpy", diff="medium", tags=["sorting", "argpartition"], title="k-th smallest index", ask="Return the index of the `k`-th smallest element (0-based) using `np.argpartition`.",
     args=["a = np.array([5.0, 1.0, 4.0, 2.0])\nk = 2", "a = np.random.randn(10)\nk = 0",
           "a = np.array([3.0, 1.0, 2.0])\nk = 1"],
     op="np.argpartition(a, k)[k]")

auto(topic="numpy", diff="medium", tags=["roots"], title="Polynomial roots", ask="Return the roots of the polynomial with coefficients `coef` (highest power first).",
     args=["coef = np.array([1.0, -3.0, 2.0])", "coef = np.array([1.0, 0.0, -1.0])", "coef = np.array([1.0, 0.0])"],
     op="np.roots(coef)")

auto(topic="numpy", diff="medium", tags=["conditions"], title="Select with conditions", ask="Return `np.select(condlist, choicelist, default=0)`.",
     args=["condlist = [np.array([True, False]), np.array([False, False])]\nchoicelist = [np.array([1, 1]), np.array([2, 2])]",
           "condlist = [np.array([False, True, False])]\nchoicelist = [np.array([7, 7, 7])]",
           "condlist = [np.array([True]), np.array([True])]\nchoicelist = [np.array([1]), np.array([2])]"],
     op="np.select(condlist, choicelist, default=0)")
