"""PyTorch question bank — part 1: creation, indexing, shape manipulation."""
from dsl import q, auto

# =========================================================================== #
#  Tensor creation
# =========================================================================== #
q(topic="torch", diff="easy", tags=["creation"], title="Tensor from a list",
  ask="Build a `torch.Tensor` from the Python list `data`. Use `torch.tensor` so the "
      "dtype is inferred from the values.",
  sig="solve(data)", sol="return torch.tensor(data)",
  mk="""
  cases = [([1, 2, 3],), ([],), ([[1.5, 2.5], [3.5, 4.5]],), ([0],), ([[1, 2], [3, 4]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["data"],
  hints=["`torch.tensor` copies the data and infers the dtype.",
         "A list of ints becomes `int64`, a list of floats becomes `float32`."])

auto(topic="torch", diff="easy", tags=["creation"], title="Zeros tensor",
     ask="Return a tensor of zeros with the given shape and floating dtype.",
     args=["n = 3\nm = 4", "n = 1\nm = 1", "n = 5\nm = 2"],
     op=["torch.zeros(n, m)", "torch.zeros(n, m)", "torch.zeros(n, m, dtype=torch.float64)"])

auto(topic="torch", diff="easy", tags=["creation"], title="Ones tensor",
     ask="Return a tensor filled with ones of the given shape (default float dtype).",
     args=["n = 2\nm = 3", "n = 4", "n = 0\nm = 3"],
     op=["torch.ones(n, m)", "torch.ones(n)", "torch.ones(n, m)"])

auto(topic="torch", diff="easy", tags=["creation", "full"], title="Fill with a constant",
     ask="Return a tensor of shape `shape` filled with the scalar `value`.",
     args=["shape = (2, 3)\nvalue = 7.0", "shape = (4,)\nvalue = -1.5", "shape = (1, 2, 2)\nvalue = 0.5"],
     op=["torch.full(shape, value)", "torch.full(shape, value)", "torch.full(shape, value)"])

auto(topic="torch", diff="easy", tags=["creation", "arange"], title="Arange",
     ask="Return the values `start, start+1, ..., stop-1` as a tensor.",
     args=["start = 0\nstop = 5", "start = 2\nstop = 10", "start = -3\nstop = 2"],
     op=["torch.arange(start, stop)", "torch.arange(start, stop)", "torch.arange(start, stop)"])

auto(topic="torch", diff="medium", tags=["creation", "arange"], title="Arange with a step",
     ask="Return the values from `start` to `stop` (exclusive) with the given step.",
     args=["start = 0\nstop = 10\nstep = 2", "start = 5\nstop = 0\nstep = -1", "start = 0.0\nstop = 1.0\nstep = 0.25"],
     op=["torch.arange(start, stop, step)", "torch.arange(start, stop, step)", "torch.arange(start, stop, step)"])

auto(topic="torch", diff="easy", tags=["creation", "linspace"], title="Linspace",
     ask="Return `n` evenly spaced values from `start` to `stop` **inclusive**.",
     args=["start = 0.0\nstop = 1.0\nn = 5", "start = -1.0\nstop = 1.0\nn = 3", "start = 2.0\nstop = 10.0\nn = 9"],
     op=["torch.linspace(start, stop, n)", "torch.linspace(start, stop, n)", "torch.linspace(start, stop, n)"])

auto(topic="torch", diff="easy", tags=["creation", "eye"], title="Identity matrix",
     ask="Return the `n x n` identity matrix.",
     args=["n = 3", "n = 1", "n = 4"], op=["torch.eye(n)", "torch.eye(n)", "torch.eye(n)"])

auto(topic="torch", diff="medium", tags=["creation", "eye"], title="Rectangular identity",
     ask="Return a matrix with ones on the main diagonal and zeros elsewhere, "
         "with `rows` rows and `cols` columns.",
     args=["rows = 3\ncols = 4", "rows = 4\ncols = 2", "rows = 2\ncols = 2"],
     op=["torch.eye(rows, cols)", "torch.eye(rows, cols)", "torch.eye(rows, cols)"])

auto(topic="torch", diff="medium", tags=["creation", "random", "seed"], title="Seeded random tensor",
     ask="Using a **local** `torch.Generator` seeded with `seed`, return `torch.randn(3, 4)` "
         "drawn from that generator (so the result is reproducible regardless of global state).",
     args=["seed = 0", "seed = 42", "seed = 1234"],
     op=["torch.randn(3, 4, generator=torch.Generator().manual_seed(seed))",
         "torch.randn(3, 4, generator=torch.Generator().manual_seed(seed))",
         "torch.randn(3, 4, generator=torch.Generator().manual_seed(seed))"])

auto(topic="torch", diff="medium", tags=["creation", "random"], title="Random integers",
     ask="Return a `(3, 4)` tensor of random integers in `[low, high)` using the global "
         "RNG (the tests seed it for you).",
     args=["low = 0\nhigh = 10", "low = -5\nhigh = 5", "low = 100\nhigh = 101"],
     op=["torch.randint(low, high, (3, 4))", "torch.randint(low, high, (3, 4))",
         "torch.randint(low, high, (3, 4))"])

auto(topic="torch", diff="easy", tags=["creation", "like"], title="Zeros like another tensor",
     ask="Return a tensor of zeros with the same shape and dtype as `x`.",
     args=["x = torch.randn(3, 4)", "x = torch.randint(0, 5, (2, 2))", "x = torch.randn(5)"],
     op=["torch.zeros_like(x)", "torch.zeros_like(x)", "torch.zeros_like(x)"])

auto(topic="torch", diff="easy", tags=["creation", "like"], title="Ones like another tensor",
     ask="Return a tensor of ones with the same shape, dtype and device as `x`.",
     args=["x = torch.randn(2, 3)", "x = torch.empty(4)", "x = torch.zeros(1, 2, 3)"],
     op=["torch.ones_like(x)", "torch.ones_like(x)", "torch.ones_like(x)"])

auto(topic="torch", diff="medium", tags=["creation", "arange"], title="Arange in a dtype",
     ask="Return `torch.arange(n)` cast to `torch.float32` — do it with the `dtype` "
         "argument, not with `.float()`.",
     args=["n = 5", "n = 1", "n = 10"],
     op=["torch.arange(n, dtype=torch.float32)", "torch.arange(n, dtype=torch.float32)",
         "torch.arange(n, dtype=torch.float32)"])

q(topic="torch", diff="medium", tags=["creation", "numpy"], title="From NumPy, no copy",
  ask="`a` is a `float32` NumPy array. Return a tensor that **shares memory** with it "
      "(use `torch.from_numpy`). The harness mutates the tensor afterwards and checks "
      "that the NumPy array changed too.",
  sig="solve(a)", sol="return torch.from_numpy(a)",
  mk="""
  return (np.random.randn(3, 4).astype(np.float32),)
  """, arg_names=["a"], cmp="none",
  props=["""
  a = _args[0]
  assert isinstance(_got, torch.Tensor), "return a torch.Tensor"
  assert _got.data_ptr() == a.__array_interface__["data"][0], "the tensor must share memory with the array"
  """],
  hints=["`torch.from_numpy` does not copy the buffer.",
         "`torch.tensor(a)` would copy — that's not what we want here."])

q(topic="torch", diff="medium", tags=["numpy", "convert"], title="Tensor to NumPy",
  ask="Return `x` as a NumPy array. The tensor does not require grad.",
  sig="solve(x)", sol="return x.numpy()",
  mk="""
  return (torch.randn(3, 2),)
  """, arg_names=["x"],
  hints=["`.numpy()` shares memory with the tensor.",
         "If the tensor required grad you would need `.detach()` first."])

auto(topic="torch", diff="easy", tags=["attributes"], title="Tensor shape",
     ask="Return the shape of `x` as a `torch.Size` (i.e. `x.shape`).",
     args=["x = torch.randn(3, 4)", "x = torch.randn(5)", "x = torch.zeros(2, 3, 4)"],
     op=["x.shape", "x.shape", "x.shape"])

auto(topic="torch", diff="easy", tags=["attributes"], title="Number of elements",
     ask="Return the total number of elements in `x`.",
     args=["x = torch.randn(3, 4)", "x = torch.randn(2, 3, 4)", "x = torch.tensor(5.0)"],
     op=["x.numel()", "x.numel()", "x.numel()"])

auto(topic="torch", diff="easy", tags=["attributes"], title="Cast dtype",
     ask="Return `x` converted to `torch.float64`.",
     args=["x = torch.randn(3)", "x = torch.arange(4)", "x = torch.ones(2, 2, dtype=torch.float16)"],
     op=["x.to(torch.float64)", "x.to(torch.float64)", "x.to(torch.float64)"])

auto(topic="torch", diff="easy", tags=["attributes", "python"], title="Extract a Python number",
     ask="`x` is a 0-dim tensor. Return its value as a Python `float`.",
     args=["x = torch.tensor(3.5)", "x = torch.tensor(-0.25)", "x = torch.tensor(1e3)"],
     op=["x.item()", "x.item()", "x.item()"])

auto(topic="torch", diff="easy", tags=["attributes", "python"], title="Tensor to list",
     ask="Return the tensor `x` as a nested Python list.",
     args=["x = torch.tensor([1, 2, 3])", "x = torch.tensor([[1.0, 2.0], [3.0, 4.0]])",
           "x = torch.tensor([[1, 2], [3, 4]])"],
     op=["x.tolist()", "x.tolist()", "x.tolist()"])

q(topic="torch", diff="easy", tags=["mut", "inplace"], title="Zero a tensor in place",
  ask="Zero every element of `x` **in place** and return it.",
  sig="solve(x)", sol="""
  x.zero_()
  return x
  """,
  mk="return (torch.randn(3, 4),)", arg_names=["x"], cmp="mut",
  hints=["Methods ending in `_` mutate the tensor.", "`x.zero_()` or `x.fill_(0)`."])

q(topic="torch", diff="easy", tags=["mut", "inplace"], title="Fill in place",
  ask="Fill `x` with the value `value` in place and return it.",
  sig="solve(x, value)", sol="""
  x.fill_(value)
  return x
  """,
  mk="""
  cases = [(torch.randn(2, 3), 4.0), (torch.zeros(4), -1.0), (torch.ones(1), 0.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "value"], cmp="mut",
  hints=["`fill_` is the in-place version of `full`.",
         "The tests also verify the caller's tensor was modified."])

# =========================================================================== #
#  Indexing / slicing
# =========================================================================== #
auto(topic="torch", diff="easy", tags=["indexing"], title="Select a row",
     ask="Return row `i` of the 2-D tensor `x` (a 1-D tensor).",
     args=["x = torch.randn(4, 5)\ni = 1", "x = torch.arange(12).reshape(3, 4)\ni = 2",
           "x = torch.randn(2, 2)\ni = 0"],
     op=["x[i]", "x[i]", "x[i]"])

auto(topic="torch", diff="easy", tags=["indexing"], title="Select a column",
     ask="Return column `j` of the 2-D tensor `x` as a 1-D tensor.",
     args=["x = torch.randn(4, 5)\nj = 2", "x = torch.arange(12).reshape(3, 4)\nj = 0",
           "x = torch.randn(2, 3)\nj = 1"],
     op=["x[:, j]", "x[:, j]", "x[:, j]"])

auto(topic="torch", diff="medium", tags=["indexing", "slicing"], title="Slice a block",
     ask="Return the sub-tensor `x[r0:r1, c0:c1]`.",
     args=["x = torch.arange(20).reshape(4, 5)\nr0 = 1\nr1 = 3\nc0 = 2\nc1 = 5",
           "x = torch.randn(5, 5)\nr0 = 0\nr1 = 2\nc0 = 1\nc1 = 3",
           "x = torch.arange(9).reshape(3, 3)\nr0 = 2\nr1 = 3\nc0 = 0\nc1 = 2"],
     op=["x[r0:r1, c0:c1]", "x[r0:r1, c0:c1]", "x[r0:r1, c0:c1]"])

auto(topic="torch", diff="medium", tags=["indexing", "dtype"], title="Select a column as int",
     ask="Return integer column `j` of `x`; the tensor holds ints.",
     args=["x = torch.tensor([[1, 2], [3, 4]])\nj = 0",
           "x = torch.tensor([[5, 6, 7]])\nj = 2", "x = torch.randint(0, 9, (3, 3))\nj = 1"],
     op=["x[:, j]", "x[:, j]", "x[:, j]"])

auto(topic="torch", diff="medium", tags=["boolean-mask"], title="Boolean mask",
     ask="Return the elements of `x` that are strictly greater than `t`, keeping "
         "the flattened order.",
     args=["x = torch.tensor([-1.0, 2.0, 0.0, 3.0])\nt = 0.0", "x = torch.randn(3, 4)\nt = 0.5",
           "x = torch.arange(6).float()\nt = 2.0"],
     op=["x[x > t]", "x[x > t]", "x[x > t]"])

auto(topic="torch", diff="medium", tags=["masked_select"], title="Masked select",
     ask="Return the selected elements of `x` where `mask` is `True`, using "
         "`torch.masked_select`.",
     args=["x = torch.tensor([1.0, 2.0, 3.0, 4.0])\nmask = torch.tensor([True, False, True, True])",
           "x = torch.randn(2, 3)\nmask = torch.zeros(2, 3, dtype=torch.bool)",
           "x = torch.arange(5)\nmask = torch.tensor([False, True, False, True, False])"],
     op=["torch.masked_select(x, mask)", "torch.masked_select(x, mask)", "torch.masked_select(x, mask)"])

auto(topic="torch", diff="medium", tags=["index_select"], title="Gather rows by index",
     ask="Return the rows of `x` selected by the integer index tensor `idx`, using "
         "`torch.index_select(x, 0, idx)`.",
     args=["x = torch.randn(5, 3)\nidx = torch.tensor([0, 2, 4])",
           "x = torch.arange(12).reshape(4, 3)\nidx = torch.tensor([3, 3, 0])",
           "x = torch.randn(2, 2)\nidx = torch.tensor([1])"],
     op=["torch.index_select(x, 0, idx)", "torch.index_select(x, 0, idx)", "torch.index_select(x, 0, idx)"])

auto(topic="torch", diff="medium", tags=["gather"], title="Gather along a dimension",
     ask="Return `torch.gather(x, 1, idx)` where `x` is 2-D and `idx` is a long tensor "
         "of the same height.",
     args=["x = torch.tensor([[1, 2, 3], [4, 5, 6]])\nidx = torch.tensor([[0, 2], [1, 0]])",
           "x = torch.arange(12).reshape(3, 4)\nidx = torch.tensor([[0], [3], [2]])",
           "x = torch.randn(2, 2)\nidx = torch.tensor([[1, 1], [0, 1]])"],
     op=["torch.gather(x, 1, idx)", "torch.gather(x, 1, idx)", "torch.gather(x, 1, idx)"])

auto(topic="torch", diff="medium", tags=["where"], title="Select with torch.where",
     ask="Return a tensor that takes values from `a` where `cond` is true and from `b` "
         "elsewhere, using `torch.where`.",
     args=["cond = torch.tensor([True, False, True])\na = torch.tensor([1.0, 2.0, 3.0])\nb = torch.tensor([10.0, 20.0, 30.0])",
           "cond = torch.zeros(2, 3, dtype=torch.bool)\na = torch.ones(2, 3)\nb = torch.zeros(2, 3)",
           "cond = torch.ones(4, dtype=torch.bool)\na = torch.arange(4)\nb = torch.arange(4) * 10"],
     op=["torch.where(cond, a, b)", "torch.where(cond, a, b)", "torch.where(cond, a, b)"])

auto(topic="torch", diff="medium", tags=["clamp"], title="Clamp values",
     ask="Clamp every element of `x` into `[lo, hi]` using `torch.clamp`.",
     args=["x = torch.tensor([-2.0, 0.5, 3.0])\nlo = 0.0\nhi = 1.0", "x = torch.randn(3, 3)\nlo = -0.5\nhi = 0.5",
           "x = torch.arange(6).float()\nlo = 2.0\nhi = 4.0"],
     op=["torch.clamp(x, lo, hi)", "torch.clamp(x, lo, hi)", "torch.clamp(x, lo, hi)"])

auto(topic="torch", diff="medium", tags=["nonzero"], title="Where are the non-zeros?",
     ask="Return the indices of the non-zero elements of `x` as an `(N, ndim)` long "
         "tensor, using `torch.nonzero` (no `as_tuple`).",
     args=["x = torch.tensor([0.0, 2.0, 0.0, 3.0])", "x = torch.tensor([[1, 0], [0, 1]])",
           "x = torch.zeros(3, 2)"],
     op=["torch.nonzero(x)", "torch.nonzero(x)", "torch.nonzero(x)"])

auto(topic="torch", diff="medium", tags=["sorting", "topk"], title="Top-k values",
     ask="Return the `k` largest values of `x` **sorted descending**, using `torch.topk`.",
     args=["x = torch.tensor([1.0, 5.0, 2.0, 4.0, 3.0])\nk = 3",
           "x = torch.tensor([[1.0, 2.0, 3.0]])\nk = 1", "x = torch.randn(10)\nk = 10"],
     op=["torch.topk(x, k).values", "torch.topk(x, k).values", "torch.topk(x, k).values"])

auto(topic="torch", diff="medium", tags=["sorting"], title="Sort values",
     ask="Return the sorted values of `x` ascending (use `torch.sort` and return only "
         "the values).",
     args=["x = torch.tensor([3.0, 1.0, 2.0])", "x = torch.tensor([[4, 1], [2, 3]])", "x = torch.randn(7)"],
     op=["torch.sort(x).values", "torch.sort(x).values", "torch.sort(x).values"])

auto(topic="torch", diff="medium", tags=["sorting"], title="Argsort indices",
     ask="Return the indices that would sort `x` ascending, using `torch.argsort`.",
     args=["x = torch.tensor([3.0, 1.0, 2.0])", "x = torch.tensor([0.0, 0.0, -1.0])", "x = torch.randn(6)"],
     op=["torch.argsort(x)", "torch.argsort(x)", "torch.argsort(x)"])

auto(topic="torch", diff="medium", tags=["mask", "triu"], title="Upper triangular part",
     ask="Return the upper-triangular part of `x` (diagonal kept), zeroing the rest.",
     args=["x = torch.arange(9).reshape(3, 3)", "x = torch.randn(4, 4)", "x = torch.tensor([[1.0, 2.0], [3.0, 4.0]])"],
     op=["torch.triu(x)", "torch.triu(x)", "torch.triu(x)"])

auto(topic="torch", diff="medium", tags=["mask", "tril"], title="Lower triangular part",
     ask="Return the lower-triangular part of `x` shifted down by `diagonal` "
         "(`diagonal=-1` drops the main diagonal).",
     args=["x = torch.arange(9).reshape(3, 3)\ndiagonal = 0", "x = torch.randn(4, 4)\ndiagonal = -1",
           "x = torch.tensor([[1.0, 2.0], [3.0, 4.0]])\ndiagonal = 1"],
     op=["torch.tril(x, diagonal)", "torch.tril(x, diagonal)", "torch.tril(x, diagonal)"])

auto(topic="torch", diff="medium", tags=["mask"], title="Causal mask",
     ask="Build the additive causal mask used in transformers: shape `(n, n)`, zeros "
         "on and below the diagonal and `-inf` above it. Use `torch.triu` with "
         "`diagonal=1`, then `masked_fill` (or bincount-free trickery).",
     args=["n = 3\nneg_inf = float('-inf')", "n = 1\nneg_inf = float('-inf')", "n = 4\nneg_inf = float('-inf')"],
     op=["torch.triu(torch.full((n, n), neg_inf), diagonal=1)", "torch.triu(torch.full((n, n), neg_inf), diagonal=1)",
         "torch.triu(torch.full((n, n), neg_inf), diagonal=1)"])

auto(topic="torch", diff="easy", tags=["flip"], title="Flip a dimension",
     ask="Reverse the order of `x` along `dim`.",
     args=["x = torch.arange(5)\ndim = 0", "x = torch.arange(6).reshape(2, 3)\ndim = 1",
           "x = torch.arange(6).reshape(2, 3)\ndim = 0"],
     op=["torch.flip(x, [dim])", "torch.flip(x, [dim])", "torch.flip(x, [dim])"])

auto(topic="torch", diff="medium", tags=["roll"], title="Roll a tensor",
     ask="Return `x` rolled by `shift` positions along `dims` (elements wrap around).",
     args=["x = torch.arange(5)\nshift = 2\ndims = 0", "x = torch.arange(6).reshape(2, 3)\nshift = 1\ndims = 1",
           "x = torch.arange(6).reshape(2, 3)\nshift = -1\ndims = 0"],
     op=["torch.roll(x, shift, dims)", "torch.roll(x, shift, dims)", "torch.roll(x, shift, dims)"])

auto(topic="torch", diff="medium", tags=["diagonal"], title="Diagonal entries",
     ask="Return the main diagonal of the square matrix `x` using `torch.diagonal`.",
     args=["x = torch.arange(9).reshape(3, 3)", "x = torch.eye(4)", "x = torch.tensor([[1.0, 2.0], [3.0, 4.0]])"],
     op=["torch.diagonal(x)", "torch.diagonal(x)", "torch.diagonal(x)"])

auto(topic="torch", diff="medium", tags=["index_put", "mut"], title="Scatter-add rows",
     ask="`x` is a zero tensor of shape `(n, d)`. Add row `row` of `x` into each index "
         "in `idx` (in place, using `index_add_`). Return `x`.",
     args=["n = 4\nd = 3\nx = torch.zeros(n, d)\nrow = torch.ones(d)\nidx = torch.tensor([0, 2, 2])",
           "n = 2\nd = 2\nx = torch.ones(n, d)\nrow = torch.full((d,), 2.0)\nidx = torch.tensor([1])",
           "n = 3\nd = 1\nx = torch.zeros(n, d)\nrow = torch.tensor([5.0])\nidx = torch.tensor([0, 1, 2])"],
     op=["x.index_add_(0, idx, row.expand(idx.numel(), -1))",
         "x.index_add_(0, idx, row.expand(idx.numel(), -1))",
         "x.index_add_(0, idx, row.expand(idx.numel(), -1))"],
     cmp="mut")

# =========================================================================== #
#  Shape manipulation
# =========================================================================== #
auto(topic="torch", diff="easy", tags=["shape", "view"], title="Reshape with view",
     ask="Return `x` reshaped to `(rows, cols)` **using `view`** (the tensor is "
         "contiguous).",
     args=["x = torch.arange(12)\nrows = 3\ncols = 4", "x = torch.arange(6)\nrows = 2\ncols = 3",
           "x = torch.arange(4)\nrows = 1\ncols = 4"],
     op=["x.view(rows, cols)", "x.view(rows, cols)", "x.view(rows, cols)"])

auto(topic="torch", diff="easy", tags=["shape", "reshape"], title="Flatten with -1",
     ask="Flatten `x` into a 1-D tensor using `reshape(-1)`.",
     args=["x = torch.randn(2, 3, 4)", "x = torch.randn(5)", "x = torch.randn(1, 2, 2, 2)"],
     op=["x.reshape(-1)", "x.reshape(-1)", "x.reshape(-1)"])

auto(topic="torch", diff="easy", tags=["shape", "squeeze"], title="Squeeze singleton dims",
     ask="Remove **all** size-1 dimensions from `x`.",
     args=["x = torch.randn(1, 3, 1, 4)", "x = torch.randn(1, 1)", "x = torch.randn(2, 3)"],
     op=["x.squeeze()", "x.squeeze()", "x.squeeze()"])

auto(topic="torch", diff="medium", tags=["shape", "squeeze"], title="Squeeze one dim",
     ask="Remove dimension `dim` from `x` (it must have size 1 there).",
     args=["x = torch.randn(3, 1, 4)\ndim = 1", "x = torch.randn(1, 5)\ndim = 0", "x = torch.randn(2, 1)\ndim = 1"],
     op=["x.squeeze(dim)", "x.squeeze(dim)", "x.squeeze(dim)"])

auto(topic="torch", diff="easy", tags=["shape", "unsqueeze"], title="Add a dimension",
     ask="Insert a size-1 dimension at position `dim` using `unsqueeze`.",
     args=["x = torch.randn(3, 4)\ndim = 0", "x = torch.randn(3, 4)\ndim = 1", "x = torch.randn(5)\ndim = -1"],
     op=["x.unsqueeze(dim)", "x.unsqueeze(dim)", "x.unsqueeze(dim)"])

auto(topic="torch", diff="medium", tags=["shape", "permute"], title="Permute dimensions",
     ask="Return `x` with its dimensions reordered by `order` using `permute`.",
     args=["x = torch.randn(2, 3, 4)\norder = (2, 0, 1)", "x = torch.randn(2, 3)\norder = (1, 0)",
           "x = torch.randn(2, 3, 4, 5)\norder = (0, 3, 1, 2)"],
     op=["x.permute(*order)", "x.permute(*order)", "x.permute(*order)"])

auto(topic="torch", diff="medium", tags=["shape", "transpose"], title="2-D transpose",
     ask="Return the transpose of the 2-D tensor `x`.",
     args=["x = torch.randn(3, 4)", "x = torch.randn(1, 5)", "x = torch.arange(6).reshape(2, 3)"],
     op=["x.T", "x.T", "x.T"])

auto(topic="torch", diff="medium", tags=["shape", "transpose"], title="Swap two dimensions",
     ask="Swap dimensions `d0` and `d1` of `x`.",
     args=["x = torch.randn(2, 3, 4)\nd0 = 0\nd1 = 2", "x = torch.randn(2, 3)\nd0 = 0\nd1 = 1",
           "x = torch.randn(2, 3, 4)\nd0 = 1\nd1 = 2"],
     op=["x.transpose(d0, d1)", "x.transpose(d0, d1)", "x.transpose(d0, d1)"])

auto(topic="torch", diff="medium", tags=["shape", "contiguous"], title="Contiguous copy",
     ask="Return a **contiguous** tensor with the same values and shape as `x` "
         "(which was produced by transposing).",
     args=["x = torch.randn(3, 4).t()", "x = torch.randn(2, 3, 4).permute(2, 0, 1)",
           "x = torch.randn(4, 5).transpose(0, 1)"],
     op=["x.contiguous()", "x.contiguous()", "x.contiguous()"])

auto(topic="torch", diff="medium", tags=["shape", "expand"], title="Expand without copying",
     ask="Broadcast `x` of shape `(1, c)` to `(r, c)` using `expand` (no data copy).",
     args=["x = torch.tensor([[1.0, 2.0]])\nr = 3", "x = torch.ones(1, 1)\nr = 4",
           "x = torch.tensor([[5.0]])\nr = 2"],
     op=["x.expand(r, -1)", "x.expand(r, -1)", "x.expand(r, -1)"])

auto(topic="torch", diff="medium", tags=["shape", "repeat"], title="Repeat tiles data",
     ask="Tile `x` `r` times along rows and `c` times along columns using `repeat`.",
     args=["x = torch.tensor([[1, 2]])\nr = 2\nc = 3", "x = torch.tensor([[0]])\nr = 3\nc = 1",
           "x = torch.tensor([[1], [2]])\nr = 1\nc = 2"],
     op=["x.repeat(r, c)", "x.repeat(r, c)", "x.repeat(r, c)"])

auto(topic="torch", diff="easy", tags=["shape", "cat"], title="Concatenate along dim 0",
     ask="Concatenate tensors `a` and `b` along dimension 0 using `torch.cat`.",
     args=["a = torch.randn(2, 3)\nb = torch.randn(1, 3)", "a = torch.randn(4)\nb = torch.randn(2)",
           "a = torch.zeros(1, 2)\nb = torch.ones(2, 2)"],
     op=["torch.cat([a, b], dim=0)", "torch.cat([a, b], dim=0)", "torch.cat([a, b], dim=0)"])

auto(topic="torch", diff="medium", tags=["shape", "cat"], title="Concatenate along dim 1",
     ask="Concatenate `a` and `b` along dimension 1.",
     args=["a = torch.randn(2, 1)\nb = torch.randn(2, 3)", "a = torch.ones(3, 2)\nb = torch.zeros(3, 1)",
           "a = torch.randn(1, 2)\nb = torch.randn(1, 2)"],
     op=["torch.cat([a, b], dim=1)", "torch.cat([a, b], dim=1)", "torch.cat([a, b], dim=1)"])

auto(topic="torch", diff="easy", tags=["shape", "stack"], title="Stack into a new dimension",
     ask="Stack `a` and `b` (both 1-D) into a 2-D tensor with `torch.stack`.",
     args=["a = torch.tensor([1.0, 2.0])\nb = torch.tensor([3.0, 4.0])",
           "a = torch.zeros(3)\nb = torch.ones(3)", "a = torch.randn(1)\nb = torch.randn(1)"],
     op=["torch.stack([a, b])", "torch.stack([a, b])", "torch.stack([a, b])"])

auto(topic="torch", diff="medium", tags=["shape", "stack"], title="Stack along dim 1",
     ask="Stack the three vectors `a`, `b`, `c` along `dim=1` using `torch.stack`.",
     args=["a = torch.tensor([1.0, 2.0])\nb = torch.tensor([3.0, 4.0])\nc = torch.tensor([5.0, 6.0])",
           "a = torch.zeros(3)\nb = torch.ones(3)\nc = torch.full((3,), 2.0)",
           "a = torch.randn(2)\nb = torch.randn(2)\nc = torch.randn(2)"],
     op=["torch.stack([a, b, c], dim=1)", "torch.stack([a, b, c], dim=1)", "torch.stack([a, b, c], dim=1)"])

auto(topic="torch", diff="medium", tags=["shape", "split"], title="Split into chunks",
     ask="Split `x` into `k` equal parts along dim 0 with `torch.split` and return the "
         "tuple of pieces.",
     args=["x = torch.arange(12).reshape(6, 2)\nk = 3", "x = torch.arange(8)\nk = 4",
           "x = torch.arange(6).reshape(2, 3)\nk = 1"],
     op=["torch.split(x, k, dim=0)", "torch.split(x, k, dim=0)", "torch.split(x, k, dim=0)"])

auto(topic="torch", diff="medium", tags=["shape", "chunk"], title="Chunk a tensor",
     ask="Split `x` into `n` chunks along dim 0 with `torch.chunk`; the last chunk can "
         "be smaller. Return the tuple of chunks.",
     args=["x = torch.arange(10)\nn = 3", "x = torch.arange(6)\nn = 2", "x = torch.arange(5)\nn = 4"],
     op=["torch.chunk(x, n, dim=0)", "torch.chunk(x, n, dim=0)", "torch.chunk(x, n, dim=0)"])

auto(topic="torch", diff="medium", tags=["shape", "unbind"], title="Unbind along rows",
     ask="Split `x` along dim `dim` into a tuple of slices using `torch.unbind`.",
     args=["x = torch.arange(6).reshape(3, 2)\ndim = 0", "x = torch.arange(6).reshape(3, 2)\ndim = 1",
           "x = torch.arange(4)\ndim = 0"],
     op=["torch.unbind(x, dim=dim)", "torch.unbind(x, dim=dim)", "torch.unbind(x, dim=dim)"])

auto(topic="torch", diff="easy", tags=["shape", "broadcast"], title="Broadcast add",
     ask="Add the 1-D tensor `bias` to every row of `x` relying on broadcasting.",
     args=["x = torch.randn(3, 4)\nbias = torch.randn(4)", "x = torch.randn(2, 2, 2)\nbias = torch.randn(2)",
           "x = torch.zeros(5, 1)\nbias = torch.tensor([1.0])"],
     op=["x + bias", "x + bias", "x + bias"])

q(topic="torch", diff="medium", tags=["shape", "view", "error"], title="When view fails: use reshape",
  ask="`x` is a non-contiguous tensor (a transpose). Without calling `.contiguous()`, "
      "return it flattened to 1-D using `reshape(-1)` — `view(-1)` would raise here "
      "because the underlying storage is not compatible.",
  sig="solve(x)", sol="return x.reshape(-1)",
  mk="""
  return (torch.randn(3, 4).t(),)
  """, arg_names=["x"],
  hints=["`reshape` copies when needed; `view` refuses.",
         "The shape is `(d0, d1)` after `.t()`; flattening follows row-major order."])

# =========================================================================== #
#  Elementwise math
# =========================================================================== #
NN = "import torch\nimport torch.nn as nn\nimport torch.nn.functional as F\n"

auto(topic="torch", diff="easy", tags=["math", "scalar"], title="Add a scalar",
     ask="Return `x` plus the scalar `c`.",
     args=["x = torch.randn(3, 4)\nc = 2.5", "x = torch.arange(5).float()\nc = -1.0",
           "x = torch.ones(2, 2)\nc = 10.0"],
     op=["x + c", "x + c", "x + c"])

auto(topic="torch", diff="easy", tags=["math"], title="Square every element",
     ask="Return the elementwise square of `x`.",
     args=["x = torch.randn(3, 4)", "x = torch.tensor([-2.0, 0.0, 3.0])", "x = torch.randn(5)"],
     op=["x ** 2", "x ** 2", "x ** 2"])

auto(topic="torch", diff="easy", tags=["math", "abs"], title="Absolute value",
     ask="Return the absolute value of every element.",
     args=["x = torch.tensor([-1.5, 2.0, -0.0])", "x = torch.randn(3, 3)", "x = torch.arange(-5, 5).float()"],
     op=["torch.abs(x)", "torch.abs(x)", "torch.abs(x)"])

auto(topic="torch", diff="easy", tags=["math", "exp"], title="Exponential",
     ask="Return `e ** x` elementwise.",
     args=["x = torch.tensor([0.0, 1.0, -1.0])", "x = torch.randn(2, 3)", "x = torch.linspace(-2, 2, 5)"],
     op=["torch.exp(x)", "torch.exp(x)", "torch.exp(x)"])

auto(topic="torch", diff="easy", tags=["math", "log"], title="Natural log",
     ask="Return the natural logarithm of `x` (all values are positive).",
     args=["x = torch.tensor([1.0, 2.7182817, 10.0])", "x = torch.rand(3, 4) + 0.1", "x = torch.linspace(0.5, 5, 6)"],
     op=["torch.log(x)", "torch.log(x)", "torch.log(x)"])

auto(topic="torch", diff="easy", tags=["math", "sqrt"], title="Square root",
     ask="Return the square root of `x` (non-negative values only).",
     args=["x = torch.tensor([0.0, 1.0, 4.0, 9.0])", "x = torch.rand(3, 3)", "x = torch.arange(6).float()"],
     op=["torch.sqrt(x)", "torch.sqrt(x)", "torch.sqrt(x)"])

auto(topic="torch", diff="easy", tags=["math", "pow"], title="General power",
     ask="Raise every element of `x` to the power `p`.",
     args=["x = torch.tensor([1.0, 2.0, 3.0])\np = 3.0", "x = torch.rand(2, 2)\np = 0.5",
           "x = torch.arange(1, 6).float()\np = -1.0"],
     op=["torch.pow(x, p)", "torch.pow(x, p)", "torch.pow(x, p)"])

auto(topic="torch", diff="easy", tags=["math", "trig"], title="Sine and cosine",
     ask="Return the tuple `(sin(x), cos(x))`.",
     args=["x = torch.tensor([0.0, 1.5707964])", "x = torch.linspace(-3.14, 3.14, 4)", "x = torch.randn(2, 2)"],
     op="(torch.sin(x), torch.cos(x))")

auto(topic="torch", diff="easy", tags=["math", "round"], title="Round to nearest",
     ask="Round every element of `x` to the nearest integer (ties go to even) and keep "
         "the floating dtype.",
     args=["x = torch.tensor([0.4, 0.5, 1.5, -0.5])", "x = torch.randn(3, 3) * 3", "x = torch.linspace(-2.5, 2.5, 6)"],
     op=["torch.round(x)", "torch.round(x)", "torch.round(x)"])

auto(topic="torch", diff="easy", tags=["math", "floor"], title="Floor and ceiling",
     ask="Return `(floor(x), ceil(x))`.",
     args=["x = torch.tensor([1.2, -1.2, 0.0])", "x = torch.randn(2, 3)", "x = torch.linspace(-1.5, 1.5, 5)"],
     op="(torch.floor(x), torch.ceil(x))")

auto(topic="torch", diff="medium", tags=["math", "sign"], title="Sign of the elements",
     ask="Return `-1`, `0` or `1` for each element of `x` using `torch.sign`.",
     args=["x = torch.tensor([-3.0, 0.0, 2.5])", "x = torch.randn(3, 3)", "x = torch.arange(-2, 3).float()"],
     op=["torch.sign(x)", "torch.sign(x)", "torch.sign(x)"])

auto(topic="torch", diff="medium", tags=["math", "mod"], title="Remainder",
     ask="Return the elementwise remainder of `x` divided by `d` "
         "(same sign as the divisor, like Python's `%`).",
     args=["x = torch.tensor([5.0, -5.0, 2.5])\nd = 2.0", "x = torch.arange(-4, 5).float()\nd = 3.0",
           "x = torch.randn(4)\nd = 0.7"],
     op=["torch.remainder(x, d)", "torch.remainder(x, d)", "torch.remainder(x, d)"])

auto(topic="torch", diff="medium", tags=["math", "reciprocal"], title="Reciprocal",
     ask="Return `1 / x` elementwise using `torch.reciprocal`.",
     args=["x = torch.tensor([1.0, 2.0, 4.0])", "x = torch.rand(3) + 0.5", "x = torch.tensor([[-1.0, -2.0]])"],
     op=["torch.reciprocal(x)", "torch.reciprocal(x)", "torch.reciprocal(x)"])

auto(topic="torch", diff="medium", tags=["math", "log1p"], title="Log of one plus x",
     ask="Return `log(1 + x)` elementwise using the numerically stable `torch.log1p`.",
     args=["x = torch.tensor([0.0, 1e-6, 1.0])", "x = torch.rand(3) * 0.5", "x = torch.linspace(0, 1, 5)"],
     op=["torch.log1p(x)", "torch.log1p(x)", "torch.log1p(x)"])

auto(topic="torch", diff="medium", tags=["math", "hypot"], title="Hypotenuse",
     ask="Return `sqrt(a^2 + b^2)` elementwise using the stable `torch.hypot`.",
     args=["a = torch.tensor([3.0, 5.0])\nb = torch.tensor([4.0, 12.0])",
           "a = torch.randn(3)\nb = torch.randn(3)", "a = torch.ones(2, 2)\nb = torch.ones(2, 2)"],
     op=["torch.hypot(a, b)", "torch.hypot(a, b)", "torch.hypot(a, b)"])

auto(topic="torch", diff="medium", tags=["math", "clamp"], title="Clamp only the minimum",
     ask="Raise every element of `x` to at least `lo`, leaving larger values untouched.",
     args=["x = torch.tensor([-2.0, 0.0, 5.0])\nlo = 0.0", "x = torch.randn(3, 3)\nlo = -0.1",
           "x = torch.arange(-3, 4).float()\nlo = 1.0"],
     op=["torch.clamp_min(x, lo)", "torch.clamp_min(x, lo)", "torch.clamp_min(x, lo)"])

# =========================================================================== #
#  Activations & numerically-stable primitives
# =========================================================================== #
auto(topic="torch", diff="easy", tags=["activation", "relu"], title="ReLU",
     ask="Apply `torch.relu` to `x`.",
     args=["x = torch.tensor([-1.0, 0.0, 2.0])", "x = torch.randn(3, 4)", "x = torch.linspace(-3, 3, 7)"],
     op=["torch.relu(x)", "torch.relu(x)", "torch.relu(x)"])

q(topic="torch", diff="easy", tags=["activation", "relu"], title="ReLU from scratch",
  ask="Implement ReLU **without** `torch.relu` or `F.relu`: return `max(x, 0)` elementwise.",
  sig="solve(x)", sol="return torch.clamp(x, min=0)",
  mk="""
  cases = [(torch.randn(3, 4),), (torch.tensor([-2.0, 0.0, 3.0]),), (torch.linspace(-1, 1, 5),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`torch.clamp(x, min=0)` or `torch.maximum(x, torch.zeros_like(x))`.",
         "ReLU is elementwise — shapes never change."])

auto(topic="torch", diff="medium", tags=["activation", "leaky"], title="Leaky ReLU",
     ask="Apply `F.leaky_relu(x, negative_slope=slope)`.",
     args=["x = torch.tensor([-2.0, 0.0, 2.0])\nslope = 0.1", "x = torch.randn(3, 4)\nslope = 0.01",
           "x = torch.linspace(-2, 2, 5)\nslope = 0.2"],
     op=["F.leaky_relu(x, negative_slope=slope)", "F.leaky_relu(x, negative_slope=slope)",
         "F.leaky_relu(x, negative_slope=slope)"], imports=NN)

auto(topic="torch", diff="medium", tags=["activation", "gelu"], title="GELU",
     ask="Apply the exact GELU (`approximate='none'`) using `F.gelu`.",
     args=["x = torch.tensor([-2.0, 0.0, 2.0])", "x = torch.randn(3, 4)", "x = torch.linspace(-3, 3, 7)"],
     op=["F.gelu(x, approximate='none')", "F.gelu(x, approximate='none')", "F.gelu(x, approximate='none')"],
     imports=NN)

auto(topic="torch", diff="medium", tags=["activation", "silu"], title="SiLU / Swish",
     ask="Apply SiLU (`x * sigmoid(x)`) using `F.silu`.",
     args=["x = torch.tensor([-2.0, 0.0, 2.0])", "x = torch.randn(2, 3)", "x = torch.linspace(-2, 2, 5)"],
     op=["F.silu(x)", "F.silu(x)", "F.silu(x)"], imports=NN)

auto(topic="torch", diff="medium", tags=["activation", "tanh"], title="Hyperbolic tangent",
     ask="Apply `torch.tanh`.",
     args=["x = torch.tensor([-1.0, 0.0, 1.0])", "x = torch.randn(3, 3)", "x = torch.linspace(-4, 4, 5)"],
     op=["torch.tanh(x)", "torch.tanh(x)", "torch.tanh(x)"])

q(topic="torch", diff="medium", tags=["activation", "sigmoid"], title="Sigmoid from scratch",
  ask="Implement the sigmoid `1 / (1 + exp(-x))` using only `torch.exp` — no "
      "`torch.sigmoid` or `F.sigmoid`.",
  sig="solve(x)", sol="return 1.0 / (1.0 + torch.exp(-x))",
  mk="""
  cases = [(torch.randn(3, 4),), (torch.tensor([-10.0, 0.0, 10.0]),), (torch.linspace(-3, 3, 5),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["Negate, exponentiate, add one, take the reciprocal.",
         "`torch.sigmoid(x)` is the built-in equivalent."])

q(topic="torch", diff="medium", tags=["activation", "softmax", "stability"], title="Numerically stable softmax",
  ask="Write softmax along the last dimension **without** `torch.softmax`: subtract the "
      "row max before exponentiating, then normalise.",
  sig="solve(x)", sol="""
  shifted = x - x.max(dim=-1, keepdim=True).values
  e = torch.exp(shifted)
  return e / e.sum(dim=-1, keepdim=True)
  """,
  mk="""
  cases = [(torch.randn(3, 5),), (torch.randn(4, 2) * 10,), (torch.tensor([[1000.0, 1001.0, 1002.0]]),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["Subtracting the max keeps `exp` in range and doesn't change the result.",
         "Normalise with `sum(dim=-1, keepdim=True)`."])

auto(topic="torch", diff="medium", tags=["softmax"], title="Softmax with a dim argument",
     ask="Apply `torch.softmax` along `dim`.",
     args=["x = torch.randn(3, 4)\ndim = 1", "x = torch.randn(2, 3, 4)\ndim = 0", "x = torch.randn(5)\ndim = 0"],
     op=["torch.softmax(x, dim)", "torch.softmax(x, dim)", "torch.softmax(x, dim)"])

auto(topic="torch", diff="medium", tags=["log_softmax", "stability"], title="Log-softmax",
     ask="Apply the numerically stable `torch.log_softmax` along `dim`.",
     args=["x = torch.randn(3, 4)\ndim = 1", "x = torch.randn(2, 5)\ndim = -1", "x = torch.tensor([[0.0, 1000.0]])\ndim = 1"],
     op=["torch.log_softmax(x, dim)", "torch.log_softmax(x, dim)", "torch.log_softmax(x, dim)"])

q(topic="torch", diff="medium", tags=["logsumexp"], title="Log-sum-exp from scratch",
  ask="Compute `log(sum(exp(x)))` along the last dimension in a numerically stable way "
      "(max shift), returning the same shape as `torch.logsumexp(x, dim=-1, keepdim=True)`.",
  sig="solve(x)", sol="""
  m = x.max(dim=-1, keepdim=True).values
  return m + torch.log(torch.exp(x - m).sum(dim=-1, keepdim=True))
  """,
  mk="""
  cases = [(torch.randn(3, 4),), (torch.randn(2, 3) * 50,), (torch.zeros(1, 5),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`m = x.max(dim=-1, keepdim=True).values`.",
         "`m + log(sum(exp(x - m)))` is mathematically identical but stable."])

# =========================================================================== #
#  Reductions
# =========================================================================== #
auto(topic="torch", diff="easy", tags=["reduction"], title="Sum everything",
     ask="Return the sum of all elements of `x` (a 0-dim tensor).",
     args=["x = torch.randn(3, 4)", "x = torch.arange(10).float()", "x = torch.tensor([[1.0, 2.0], [3.0, 4.0]])"],
     op=["x.sum()", "x.sum()", "x.sum()"])

auto(topic="torch", diff="easy", tags=["reduction", "dim"], title="Sum along a dimension",
     ask="Sum `x` along `dim`.",
     args=["x = torch.randn(3, 4)\ndim = 0", "x = torch.randn(3, 4)\ndim = 1", "x = torch.randn(2, 3, 4)\ndim = 2"],
     op=["x.sum(dim=dim)", "x.sum(dim=dim)", "x.sum(dim=dim)"])

auto(topic="torch", diff="medium", tags=["reduction", "dim", "keepdim"], title="Sum keeping the dimension",
     ask="Sum `x` along `dim` **keeping** that dimension (shape `(..., 1, ...)`).",
     args=["x = torch.randn(3, 4)\ndim = 1", "x = torch.randn(2, 3, 4)\ndim = 0", "x = torch.randn(5)\ndim = 0"],
     op=["x.sum(dim=dim, keepdim=True)", "x.sum(dim=dim, keepdim=True)", "x.sum(dim=dim, keepdim=True)"])

auto(topic="torch", diff="easy", tags=["reduction", "mean"], title="Mean of everything",
     ask="Return the mean of all elements of `x`.",
     args=["x = torch.randn(3, 4)", "x = torch.arange(6).float()", "x = torch.tensor([[2.0, 4.0]])"],
     op=["x.mean()", "x.mean()", "x.mean()"])

auto(topic="torch", diff="medium", tags=["reduction", "mean", "dim"], title="Mean along a dimension",
     ask="Return the mean of `x` along `dim`.",
     args=["x = torch.randn(4, 3)\ndim = 0", "x = torch.randn(4, 3)\ndim = 1", "x = torch.randn(2, 2, 5)\ndim = -1"],
     op=["x.mean(dim=dim)", "x.mean(dim=dim)", "x.mean(dim=dim)"])

auto(topic="torch", diff="medium", tags=["reduction", "std"], title="Standard deviation",
     ask="Return the **sample** standard deviation (Bessel-corrected, the PyTorch default) "
         "of `x` along `dim`.",
     args=["x = torch.randn(4, 5)\ndim = 0", "x = torch.randn(4, 5)\ndim = 1", "x = torch.randn(6)\ndim = 0"],
     op=["x.std(dim=dim)", "x.std(dim=dim)", "x.std(dim=dim)"])

auto(topic="torch", diff="medium", tags=["reduction", "var"], title="Population variance",
     ask="Return the variance of `x` along `dim` using the **biased** (population) "
         "estimator: `correction=0`.",
     args=["x = torch.randn(4, 5)\ndim = 0", "x = torch.randn(4, 5)\ndim = 1", "x = torch.randn(7)\ndim = 0"],
     op=["x.var(dim=dim, correction=0)", "x.var(dim=dim, correction=0)", "x.var(dim=dim, correction=0)"])

auto(topic="torch", diff="medium", tags=["reduction", "max", "dim"], title="Max along a dim (values only)",
     ask="Return only the **values** of the maximum of `x` along `dim` (unpack and drop "
         "the indices).",
     args=["x = torch.randn(3, 4)\ndim = 0", "x = torch.randn(3, 4)\ndim = 1", "x = torch.randn(5, 2)\ndim = 0"],
     op="torch.max(x, dim=dim).values")

auto(topic="torch", diff="medium", tags=["reduction", "argmax"], title="Argmax along a dim",
     ask="Return the index of the maximum of `x` along `dim` using `torch.argmax`.",
     args=["x = torch.randn(3, 4)\ndim = 0", "x = torch.randn(3, 4)\ndim = 1", "x = torch.tensor([[1.0, 9.0], [3.0, 2.0]])\ndim = 1"],
     op=["torch.argmax(x, dim=dim)", "torch.argmax(x, dim=dim)", "torch.argmax(x, dim=dim)"])

auto(topic="torch", diff="medium", tags=["reduction", "argmin"], title="Argmin of everything",
     ask="Return the flattened index of the minimum element of `x`.",
     args=["x = torch.tensor([3.0, -1.0, 2.0])", "x = torch.tensor([[4.0, 1.0], [0.5, 2.0]])", "x = torch.randn(8)"],
     op=["torch.argmin(x)", "torch.argmin(x)", "torch.argmin(x)"])

auto(topic="torch", diff="medium", tags=["reduction", "cumsum"], title="Cumulative sum",
     ask="Return the cumulative sum of `x` along `dim`.",
     args=["x = torch.tensor([1.0, 2.0, 3.0, 4.0])\ndim = 0", "x = torch.arange(6).reshape(2, 3).float()\ndim = 1",
           "x = torch.ones(4, 2)\ndim = 0"],
     op=["torch.cumsum(x, dim)", "torch.cumsum(x, dim)", "torch.cumsum(x, dim)"])

auto(topic="torch", diff="medium", tags=["reduction", "cumprod"], title="Cumulative product",
     ask="Return the cumulative product of `x` along `dim`.",
     args=["x = torch.tensor([1.0, 2.0, 3.0, 4.0])\ndim = 0", "x = torch.tensor([[1.0, 2.0], [3.0, 4.0]])\ndim = 1",
           "x = torch.full((3,), 0.5)\ndim = 0"],
     op=["torch.cumprod(x, dim)", "torch.cumprod(x, dim)", "torch.cumprod(x, dim)"])

auto(topic="torch", diff="easy", tags=["reduction", "prod"], title="Product of everything",
     ask="Return the product of all elements of `x`.",
     args=["x = torch.tensor([1.0, 2.0, 3.0])", "x = torch.ones(3, 2)", "x = torch.tensor([2.0, -3.0])"],
     op=["x.prod()", "x.prod()", "x.prod()"])

auto(topic="torch", diff="medium", tags=["reduction", "median"], title="Median along a dim",
     ask="Return the **values** of the median of `x` along `dim`.",
     args=["x = torch.tensor([[3.0, 1.0, 2.0], [9.0, 7.0, 8.0]])\ndim = 1",
           "x = torch.randn(4, 5)\ndim = 0", "x = torch.arange(7).float()\ndim = 0"],
     op="torch.median(x, dim=dim).values")

auto(topic="torch", diff="medium", tags=["reduction", "quantile"], title="Quantile",
     ask="Return the `q`-quantile of `x` (a 0-dim tensor) using `torch.quantile`.",
     args=["x = torch.tensor([1.0, 2.0, 3.0, 4.0, 5.0])\nq = 0.5",
           "x = torch.randn(10)\nq = 0.25", "x = torch.linspace(0, 1, 11)\nq = 0.9"],
     op=["torch.quantile(x, q)", "torch.quantile(x, q)", "torch.quantile(x, q)"])

auto(topic="torch", diff="medium", tags=["reduction", "amax"], title="Max over several dims",
     ask="Return the maximum of `x` over dims `(0, 2)` using `torch.amax`.",
     args=["x = torch.randn(2, 3, 4)", "x = torch.randn(3, 2, 2)", "x = torch.randn(2, 4, 3)"],
     op=["torch.amax(x, dim=(0, 2))", "torch.amax(x, dim=(0, 2))", "torch.amax(x, dim=(0, 2))"])

auto(topic="torch", diff="medium", tags=["reduction", "norm"], title="Vector norms",
     ask="Return the `p`-norm of `x` along `dim`: `(sum(|x|^p))^(1/p)`.",
     args=["x = torch.randn(3, 4)\ndim = 1\np = 2", "x = torch.randn(5)\ndim = 0\np = 1",
           "x = torch.randn(2, 3)\ndim = 0\np = 3"],
     op=["torch.linalg.vector_norm(x, ord=p, dim=dim)", "torch.linalg.vector_norm(x, ord=p, dim=dim)",
         "torch.linalg.vector_norm(x, ord=p, dim=dim)"])

auto(topic="torch", diff="medium", tags=["reduction", "count_nonzero"], title="Count non-zeros",
     ask="Return the number of non-zero elements of `x` (as an int64 tensor).",
     args=["x = torch.tensor([0.0, 1.0, 0.0, 2.0])", "x = torch.zeros(3, 3)", "x = torch.ones(4)"],
     op=["torch.count_nonzero(x)", "torch.count_nonzero(x)", "torch.count_nonzero(x)"])

auto(topic="torch", diff="medium", tags=["reduction", "any"], title="Any and all",
     ask="Return the tuple `(x.any(), x.all())` for the boolean tensor `x`.",
     args=["x = torch.tensor([True, False, True])", "x = torch.ones(2, 2, dtype=torch.bool)",
           "x = torch.zeros(3, dtype=torch.bool)"],
     op="(x.any(), x.all())")

# NaN handling
q(topic="torch", diff="medium", tags=["nan", "reduction"], title="Sum ignoring NaN",
  ask="Return the sum of `x` ignoring `NaN` entries (use `torch.nansum`).",
  sig="solve(x)", sol="return torch.nansum(x)",
  mk="""
  cases = [(torch.tensor([1.0, float('nan'), 3.0]),), (torch.randn(3, 3),),
           (torch.tensor([float('nan'), float('nan')]),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`torch.nansum` skips NaNs.", "`x.sum()` would return NaN instead."])

q(topic="torch", diff="medium", tags=["nan"], title="Detect NaN",
  ask="Return a boolean tensor that is `True` where `x` is NaN.",
  sig="solve(x)", sol="return torch.isnan(x)",
  mk="""
  cases = [(torch.tensor([1.0, float('nan')]),), (torch.randn(2, 3),),
           (torch.tensor([[float('nan'), 0.0], [float('inf'), -float('inf')]]),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`torch.isnan` returns a bool tensor.", "`inf` is not NaN."])

q(topic="torch", diff="medium", tags=["nan"], title="Replace NaN and inf",
  ask="Return `x` with NaN replaced by `nan_value` and ±inf replaced by "
      "`posinf_value` / `neginf_value` using `torch.nan_to_num`.",
  sig="solve(x, nan_value, posinf_value, neginf_value)", sol="""
  return torch.nan_to_num(x, nan=nan_value, posinf=posinf_value, neginf=neginf_value)
  """,
  mk="""
  x = torch.tensor([float('nan'), float('inf'), -float('inf'), 2.0])
  return (x, 0.0, 100.0, -100.0) if v == 0 else ((x, -1.0, 1e9, -1e9) if v == 1 else (x, 5.0, 5.0, 5.0))
  """, arg_names=["x", "nan_value", "posinf_value", "neginf_value"],
  hints=["Keyword names are `nan`, `posinf`, `neginf`.",
         "This is the standard cleanup for unstable training runs."])

auto(topic="torch", diff="medium", tags=["mask", "mut"], title="Masked fill",
     ask="Return a copy of `x` where positions selected by the boolean `mask` are "
         "replaced by `value` (use `masked_fill`, non-mutating).",
     args=["x = torch.randn(3, 4)\nmask = torch.zeros(3, 4, dtype=torch.bool)\nmask[:, 0] = True\nvalue = -1.0",
           "x = torch.randint(0, 10, (2, 3)).float()\nmask = torch.ones(2, 3, dtype=torch.bool)\nvalue = 0.0",
           "x = torch.arange(5).float()\nmask = torch.tensor([True, False, False, True, False])\nvalue = 9.0"],
     op=["x.masked_fill(mask, value)", "x.masked_fill(mask, value)", "x.masked_fill(mask, value)"])

# =========================================================================== #
#  Broadcasting & linear algebra
# =========================================================================== #
auto(topic="torch", diff="medium", tags=["linalg", "matmul"], title="Matrix multiply",
     ask="Return the matrix product `a @ b`.",
     args=["a = torch.randn(3, 4)\nb = torch.randn(4, 2)", "a = torch.randn(1, 5)\nb = torch.randn(5, 1)",
           "a = torch.eye(3)\nb = torch.randn(3, 3)"],
     op=["a @ b", "a @ b", "a @ b"])

auto(topic="torch", diff="medium", tags=["linalg", "bmm"], title="Batched matrix multiply",
     ask="Return the batched product of `a` (b, n, m) and `b` (b, m, p) using `torch.bmm`.",
     args=["a = torch.randn(2, 3, 4)\nb = torch.randn(2, 4, 5)", "a = torch.randn(1, 2, 2)\nb = torch.randn(1, 2, 3)",
           "a = torch.randn(4, 3, 3)\nb = torch.randn(4, 3, 1)"],
     op=["torch.bmm(a, b)", "torch.bmm(a, b)", "torch.bmm(a, b)"])

auto(topic="torch", diff="medium", tags=["linalg", "mv"], title="Matrix-vector product",
     ask="Return `A @ v` for the matrix `A` and vector `v`.",
     args=["A = torch.randn(3, 4)\nv = torch.randn(4)", "A = torch.eye(2)\nv = torch.tensor([1.0, 2.0])",
           "A = torch.ones(2, 3)\nv = torch.ones(3)"],
     op=["A.mv(v)", "A.mv(v)", "A.mv(v)"])

auto(topic="torch", diff="medium", tags=["linalg", "dot"], title="Dot product",
     ask="Return the dot product of the 1-D tensors `a` and `b`.",
     args=["a = torch.randn(5)\nb = torch.randn(5)", "a = torch.tensor([1.0, 2.0])\nb = torch.tensor([3.0, 4.0])",
           "a = torch.ones(3)\nb = torch.arange(3).float()"],
     op=["torch.dot(a, b)", "torch.dot(a, b)", "torch.dot(a, b)"])

auto(topic="torch", diff="medium", tags=["linalg", "outer"], title="Outer product",
     ask="Return the outer product of `a` (length n) and `b` (length m) as an `(n, m)` "
         "tensor.",
     args=["a = torch.randn(3)\nb = torch.randn(4)", "a = torch.tensor([1.0, 2.0])\nb = torch.tensor([3.0])",
           "a = torch.ones(2)\nb = torch.ones(2)"],
     op=["torch.outer(a, b)", "torch.outer(a, b)", "torch.outer(a, b)"])

auto(topic="torch", diff="medium", tags=["einsum"], title="Einsum matmul",
     ask="Reproduce `a @ b` with `torch.einsum('ij,jk->ik', a, b)`.",
     args=["a = torch.randn(3, 4)\nb = torch.randn(4, 2)", "a = torch.randn(2, 2)\nb = torch.randn(2, 3)",
           "a = torch.eye(4)\nb = torch.randn(4, 4)"],
     op=["torch.einsum('ij,jk->ik', a, b)", "torch.einsum('ij,jk->ik', a, b)",
         "torch.einsum('ij,jk->ik', a, b)"])

auto(topic="torch", diff="hard", tags=["einsum", "batched"], title="Einsum batched matmul",
     ask="Reproduce the batched product of `a` (b, n, m) and `b` (b, m, p) with "
         "`torch.einsum('bij,bjk->bik', a, b)`.",
     args=["a = torch.randn(2, 3, 4)\nb = torch.randn(2, 4, 5)", "a = torch.randn(1, 2, 2)\nb = torch.randn(1, 2, 2)",
           "a = torch.randn(3, 2, 2)\nb = torch.randn(3, 2, 1)"],
     op=["torch.einsum('bij,bjk->bik', a, b)", "torch.einsum('bij,bjk->bik', a, b)",
         "torch.einsum('bij,bjk->bik', a, b)"])

auto(topic="torch", diff="hard", tags=["einsum", "trace"], title="Trace with einsum",
     ask="Return the trace of `x` (sum of the diagonal) using `torch.einsum('ii->', x)`.",
     args=["x = torch.randn(3, 3)", "x = torch.randn(4, 4)", "x = torch.eye(2)"],
     op=["torch.einsum('ii->', x)", "torch.einsum('ii->', x)", "torch.einsum('ii->', x)"])

q(topic="torch", diff="medium", tags=["linalg", "trace"], title="Trace of a matrix",
  ask="Return the trace (sum of the main diagonal) of the square matrix `x`.",
  sig="solve(x)", sol="return torch.trace(x)",
  mk="""
  cases = [(torch.randn(3, 3),), (torch.eye(4),), (torch.arange(9).reshape(3, 3).float(),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`torch.trace` sums the main diagonal.",
         "It only accepts 2-D square matrices."])

q(topic="torch", diff="medium", tags=["linalg", "inverse"], title="Matrix inverse",
  ask="Return the inverse of the invertible matrix `A` using `torch.linalg.inv`.",
  sig="solve(A)", sol="return torch.linalg.inv(A)",
  mk="""
  M = torch.randn(3, 3)
  return (M @ M.t() + 3.0 * torch.eye(3),) if v == 0 else ((torch.randn(2, 2) + 3 * torch.eye(2),) if v == 1 else (torch.randn(4, 4) + 4 * torch.eye(4),))
  """, arg_names=["A"],
  hints=["`torch.linalg.inv` requires a square, non-singular matrix.",
         "The test matrices are well conditioned."])

q(topic="torch", diff="medium", tags=["linalg", "det"], title="Determinant",
  ask="Return the determinant of the square matrix `A`.",
  sig="solve(A)", sol="return torch.linalg.det(A)",
  mk="""
  cases = [(torch.tensor([[2.0, 0.0], [0.0, 3.0]]),), (torch.eye(4),),
           (torch.tensor([[1.0, 2.0], [3.0, 4.0]]),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["A"],
  hints=["`torch.linalg.det` returns a 0-dim tensor.",
         "The determinant of the identity is 1."])

q(topic="torch", diff="medium", tags=["linalg", "solve"], title="Linear system",
  ask="Solve `A x = b` for the vector `x` using `torch.linalg.solve`.",
  sig="solve(A, b)", sol="return torch.linalg.solve(A, b)",
  mk="""
  A = torch.randn(3, 3)
  A = A @ A.t() + 2.0 * torch.eye(3)
  return (A, torch.randn(3))
  """, arg_names=["A", "b"],
  hints=["`torch.linalg.solve` is preferred over `inv(A) @ b`.",
         "The result has the shape of `b`."])

q(topic="torch", diff="hard", tags=["linalg", "cholesky"], title="Cholesky factor",
  ask="`A` is symmetric positive definite. Return its lower Cholesky factor `L` such "
      "that `L @ L.T == A`.",
  sig="solve(A)", sol="return torch.linalg.cholesky(A)",
  mk="""
  M = torch.randn(4, 4)
  return (M @ M.t() + 2.0 * torch.eye(4),)
  """, arg_names=["A"],
  hints=["`torch.linalg.cholesky` returns the lower-triangular factor.",
         "Symmetry plus positive eigenvalues is required."])

q(topic="torch", diff="hard", tags=["linalg", "eigh"], title="Eigenvalues of a symmetric matrix",
  ask="Return the eigenvalues (ascending) of the symmetric matrix `A` using "
      "`torch.linalg.eigvalsh`.",
  sig="solve(A)", sol="return torch.linalg.eigvalsh(A)",
  mk="""
  M = torch.randn(4, 4)
  return (M + M.t(),)
  """, arg_names=["A"],
  hints=["`eigvalsh` is for Hermitian/symmetric matrices and is much faster than `eig`.",
         "The eigenvalues come back in ascending order."])

auto(topic="torch", diff="hard", tags=["linalg", "kron"], title="Kronecker product",
     ask="Return the Kronecker product of `a` and `b` using `torch.kron`.",
     args=["a = torch.tensor([[1.0, 2.0], [3.0, 4.0]])\nb = torch.eye(2)",
           "a = torch.tensor([[1.0]])\nb = torch.tensor([[2.0, 0.0], [0.0, 2.0]])",
           "a = torch.arange(4).reshape(2, 2).float()\nb = torch.ones(2, 2)"],
     op=["torch.kron(a, b)", "torch.kron(a, b)", "torch.kron(a, b)"])

auto(topic="torch", diff="medium", tags=["linalg", "cross"], title="Cross product",
     ask="Return the cross product of the 3-vectors `a` and `b`.",
     args=["a = torch.tensor([1.0, 0.0, 0.0])\nb = torch.tensor([0.0, 1.0, 0.0])",
           "a = torch.randn(3)\nb = torch.randn(3)", "a = torch.tensor([0.0, 0.0, 1.0])\nb = torch.tensor([1.0, 0.0, 0.0])"],
     op=["torch.linalg.cross(a, b)", "torch.linalg.cross(a, b)", "torch.linalg.cross(a, b)"])

q(topic="torch", diff="hard", tags=["linalg", "power"], title="Matrix power",
  ask="Return `A` raised to the integer power `k` using `torch.linalg.matrix_power`.",
  sig="solve(A, k)", sol="return torch.linalg.matrix_power(A, k)",
  mk="""
  A = torch.randn(3, 3)
  return (A, [0, 1, 3][v]) if False else ((A, [0, 1, 2][v]))
  """, arg_names=["A", "k"],
  hints=["`matrix_power` handles negative powers by inverting.",
         "Power 0 returns the identity."])

auto(topic="torch", diff="medium", tags=["distance", "cdist"], title="Pairwise distances",
     ask="Return the Euclidean distance matrix between the rows of `a` (n, d) and the "
         "rows of `b` (m, d), using `torch.cdist`.",
     args=["a = torch.randn(3, 4)\nb = torch.randn(5, 4)", "a = torch.zeros(2, 2)\nb = torch.ones(2, 2)",
           "a = torch.randn(1, 3)\nb = torch.randn(1, 3)"],
     op=["torch.cdist(a, b)", "torch.cdist(a, b)", "torch.cdist(a, b)"])

auto(topic="torch", diff="medium", tags=["distance", "cosine"], title="Cosine similarity",
     ask="Return the pairwise cosine similarity between the rows of `a` and `b` using "
         "`F.cosine_similarity` with `dim=1`.",
     args=["a = torch.randn(3, 4)\nb = torch.randn(3, 4)", "a = torch.ones(2, 3)\nb = torch.ones(2, 3)",
           "a = torch.randn(4, 5)\nb = torch.randn(4, 5)"],
     op=["F.cosine_similarity(a, b, dim=1)", "F.cosine_similarity(a, b, dim=1)",
         "F.cosine_similarity(a, b, dim=1)"], imports=NN)

q(topic="torch", diff="medium", tags=["normalize"], title="L2-normalise rows",
  ask="Scale every row of `x` to unit L2 norm using `F.normalize(x, p=2, dim=1)`.",
  sig="solve(x)", sol="return F.normalize(x, p=2, dim=1)",
  mk="""
  cases = [(torch.randn(3, 4),), (torch.randn(5, 2) * 5,), (torch.ones(2, 3),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  hints=["`F.normalize` divides by the norm along `dim`.",
         "Rows that are all zeros stay zero (eps guard)."])

q(topic="torch", diff="medium", tags=["broadcast", "standardize"], title="Standardise columns",
  ask="Standardise every column of the 2-D tensor `x` to zero mean and unit variance "
      "(population std, `correction=0`).",
  sig="solve(x)", sol="""
  mean = x.mean(dim=0, keepdim=True)
  std = x.std(dim=0, keepdim=True, correction=0)
  return (x - mean) / std
  """,
  mk="""
  cases = [(torch.randn(5, 3) * 3 + 1,), (torch.randn(4, 2),), (torch.arange(12).reshape(6, 2).float(),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["Compute the statistics with `keepdim=True` so broadcasting aligns.",
         "Use `correction=0` for the population std."])

q(topic="torch", diff="medium", tags=["one-hot"], title="One-hot encoding",
  ask="`idx` is a 1-D int64 tensor of class indices (0 <= idx < classes). Return the "
      "one-hot matrix of shape `(len(idx), classes)` as `float32`.",
  sig="solve(idx, classes)", sol="return F.one_hot(idx, num_classes=classes).float()",
  mk="""
  cases = [(torch.tensor([0, 2, 1]), 3), (torch.tensor([0]), 1), (torch.tensor([1, 1, 0, 2]), 4)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["idx", "classes"], imports=NN,
  hints=["`F.one_hot` returns int64 — convert with `.float()`.",
         "The number of classes must be explicit when the last class is missing."])

q(topic="torch", diff="medium", tags=["inplace", "mut"], title="In-place scaling",
  ask="Multiply `x` by the scalar `s` **in place** (`x.mul_`), then return `x`.",
  sig="solve(x, s)", sol="""
  x.mul_(s)
  return x
  """,
  mk="""
  cases = [(torch.randn(2, 3), 3.0), (torch.ones(4), -2.0), (torch.zeros(2), 5.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "s"], cmp="mut",
  hints=["Trailing underscore means in-place.", "`x *= s` is also in place on tensors."])

q(topic="torch", diff="medium", tags=["inplace", "mut"], title="Zero a column in place",
  ask="Set column 0 of `x` to zero **in place** and return `x`.",
  sig="solve(x)", sol="""
  x[:, 0] = 0
  return x
  """,
  mk="return (torch.randn(4, 3),)", arg_names=["x"], cmp="mut",
  hints=["Slice assignment on a tensor mutates the storage.",
         "`x[:, 0].zero_()` would *not* work — `.zero_()` on a view is fine, but `x[:, 0] = 0` is clearer."])

# =========================================================================== #
#  Autograd
# =========================================================================== #
q(topic="torch", diff="easy", tags=["autograd", "backward"], title="Gradient of sum of squares",
  ask="`x` requires grad. Compute `loss = (x ** 2).sum()`, call `loss.backward()` and "
      "return `x.grad`.",
  sig="solve(x)", sol="""
  loss = (x ** 2).sum()
  loss.backward()
  return x.grad
  """,
  mk="""
  x = torch.randn(4, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["`backward()` only works on scalar outputs.",
         "d/dx sum(x^2) = 2x."])

q(topic="torch", diff="easy", tags=["autograd", "mean"], title="Gradient of a mean",
  ask="`x` requires grad. Let `loss = x.mean()`, call `backward()` and return `x.grad`.",
  sig="solve(x)", sol="""
  x.mean().backward()
  return x.grad
  """,
  mk="""
  x = torch.randn(3, 4, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["Every element contributes 1/n to the mean.",
         "The gradient is a constant tensor filled with `1/numel`."])

q(topic="torch", diff="medium", tags=["autograd", "linear"], title="Gradient of a linear model",
  ask="`x` (n, d), `w` (d,), `b` scalar. Compute `y = x @ w + b`, `loss = y.sum()`, run "
      "backward and return the tuple `(w.grad, b.grad)`. `x` also requires grad — return "
      "`x.grad` would be the same idea, but we ask for the parameters.",
  sig="solve(x, w, b)", sol="""
  y = x @ w + b
  y.sum().backward()
  return (w.grad, b.grad)
  """,
  mk="""
  n, d = [(4, 3), (2, 2), (5, 1)][v]
  x = torch.randn(n, d, requires_grad=True)
  w = torch.randn(d, requires_grad=True)
  b = torch.randn((), requires_grad=True)
  return (x, w, b)
  """, arg_names=["x", "w", "b"],
  hints=["`w.grad` is the sum of the rows of `x`.",
         "`b.grad` is the batch size n."])

q(topic="torch", diff="medium", tags=["autograd", "chain"], title="Gradient through a matmul",
  ask="Compute `z = a @ b`, then `loss = (z ** 2).sum()`, run backward and return "
      "`a.grad`.",
  sig="solve(a, b)", sol="""
  z = a @ b
  (z ** 2).sum().backward()
  return a.grad
  """,
  mk="""
  a = torch.randn(3, 4, requires_grad=True)
  b = torch.randn(4, 2, requires_grad=True)
  return (a, b)
  """, arg_names=["a", "b"],
  hints=["`dL/da = 2 * (a@b) @ b^T`.",
         "Let autograd do the work — no need for the formula."])

q(topic="torch", diff="medium", tags=["autograd", "relu"], title="Gradient through ReLU",
  ask="Compute `y = torch.relu(x)`, `loss = y.sum()`, run backward and return `x.grad`. "
      "The gradient is 1 where `x > 0` and 0 elsewhere.",
  sig="solve(x)", sol="""
  torch.relu(x).sum().backward()
  return x.grad
  """,
  mk="""
  x = torch.randn(6, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["The subgradient at exactly 0 is 0 in PyTorch.",
         "Compare the result with `(x > 0).float()`."])

q(topic="torch", diff="medium", tags=["autograd", "no_grad"], title="Stop gradients with no_grad",
  ask="Inside `torch.no_grad()`, compute `y = x * 2` from the tensor `x` that requires "
      "grad and return `y`. The result must **not** require grad.",
  sig="solve(x)", sol="""
  with torch.no_grad():
      y = x * 2
  return y
  """,
  mk="""
  x = torch.randn(3, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["`torch.no_grad()` disables graph recording.",
         "The returned tensor has `requires_grad=False`."])

q(topic="torch", diff="medium", tags=["autograd", "detach"], title="Detach a tensor",
  ask="Return `x.detach()` — same values, but detached from the graph so it does not "
      "require grad.",
  sig="solve(x)", sol="return x.detach()",
  mk="""
  x = torch.randn(3, 3, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["`detach()` shares storage but not the graph.",
         "`clone()` alone would still track gradients."])

q(topic="torch", diff="medium", tags=["autograd", "requires_grad"], title="Enable grad on a leaf",
  ask="`x` is a leaf tensor with `requires_grad=False`. Turn tracking on **in place** "
      "and return it.",
  sig="solve(x)", sol="""
  x.requires_grad_(True)
  return x
  """,
  mk="""
  x = torch.randn(3, requires_grad=False)
  return (x,)
  """, arg_names=["x"], cmp="none",
  props=["assert _got.requires_grad is True",
         "assert _got.is_leaf is True"],
  hints=["Methods ending in `_` change the tensor itself.",
         "Only floating-point leaf tensors can require grad."])

q(topic="torch", diff="medium", tags=["autograd", "accumulation"], title="Gradients accumulate",
  ask="`x` already has `x.grad` filled with ones (from a previous `backward()`). Now "
      "compute `(2 * x).sum()`, run another backward and return `x.grad`. "
      "Notice that the gradients **add up**.",
  sig="solve(x)", sol="""
  (2 * x).sum().backward()
  return x.grad
  """,
  mk="""
  x = torch.randn(3, requires_grad=True)
  x.sum().backward()      # x.grad == ones
  return (x,)
  """, arg_names=["x"],
  hints=["PyTorch accumulates into `.grad` — it never resets automatically.",
         "With the existing ones the final gradient is 3 everywhere."])

q(topic="torch", diff="medium", tags=["autograd", "retain_graph"], title="Backward twice with retain_graph",
  ask="Run `backward()` on the same graph **twice** (use `retain_graph=True` the first "
      "time) for `loss = (x ** 2).sum()` and return the accumulated `x.grad`.",
  sig="solve(x)", sol="""
  loss = (x ** 2).sum()
  loss.backward(retain_graph=True)
  loss.backward()
  return x.grad
  """,
  mk="""
  x = torch.randn(4, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["The graph is freed after the first backward unless retained.",
         "Two passes give 2 * 2x = 4x."])

q(topic="torch", diff="medium", tags=["autograd", "grad"], title="torch.autograd.grad",
  ask="Use `torch.autograd.grad` (not `.backward()`) to compute the gradient of "
      "`(x ** 3).sum()` with respect to `x`, and return it.",
  sig="solve(x)", sol="""
  g, = torch.autograd.grad((x ** 3).sum(), x)
  return g
  """,
  mk="""
  x = torch.randn(5, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["`torch.autograd.grad` returns a *tuple* of gradients.",
         "It does not populate `.grad`."])

q(topic="torch", diff="medium", tags=["autograd", "non-leaf"], title="Non-leaf tensors have no .grad",
  ask="`y` was produced from a leaf tensor. Return the tuple "
      "`(y.grad is None, x.grad)` after computing `(y ** 2).sum().backward()`.",
  sig="solve(x, y)", sol="""
  (y ** 2).sum().backward()
  return (y.grad is None, x.grad)
  """,
  mk="""
  x = torch.randn(3, requires_grad=True)
  y = x * 2
  return (x, y)
  """, arg_names=["x", "y"],
  hints=["Only leaf tensors keep gradients in `.grad` by default.",
         "Use `torch.autograd.grad(...)` to get gradients of non-leaf tensors."])

q(topic="torch", diff="hard", tags=["autograd", "second-order"], title="Second derivative",
  ask="Compute `d²/dx² sum(x³)` using two `torch.autograd.grad` calls with "
      "`create_graph=True` on the first one, and return it.",
  sig="solve(x)", sol="""
  y = (x ** 3).sum()
  g, = torch.autograd.grad(y, x, create_graph=True)
  gg, = torch.autograd.grad(g.sum(), x)
  return gg
  """,
  mk="""
  x = torch.randn(4, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["`create_graph=True` keeps the gradient itself differentiable.",
         "The second derivative of x³ is 6x."])

q(topic="torch", diff="hard", tags=["autograd", "jacobian"], title="Jacobian of a vector function",
  ask="Return the Jacobian of `f(v) = [v0 * v1, v1 ** 2, v0 + v2]` at `x`, computed with "
      "`torch.autograd.functional.jacobian`.",
  sig="solve(x)", sol="""
  def f(v):
      return torch.stack([v[0] * v[1], v[1] ** 2, v[0] + v[2]])
  return torch.autograd.functional.jacobian(f, x)
  """,
  mk="""
  x = torch.randn(3)
  return (x,)
  """, arg_names=["x"],
  hints=["`jacobian(fn, x)` returns a `(out_dim, in_dim)` tensor.",
         "The function must accept a tensor and return a tensor."])

q(topic="torch", diff="hard", tags=["autograd", "hessian"], title="Hessian of a quadratic form",
  ask="For `f(x) = 0.5 * x^T A x`, return the Hessian at `x` using "
      "`torch.autograd.functional.hessian` (it equals the symmetric `A`).",
  sig="solve(A, x)", sol="""
  def f(v):
      return 0.5 * v @ A @ v
  return torch.autograd.functional.hessian(f, x)
  """,
  mk="""
  A = torch.randn(3, 3)
  A = A + A.t()
  x = torch.randn(3)
  return (A, x)
  """, arg_names=["A", "x"],
  hints=["`hessian(fn, x)` for a scalar function returns an (n, n) tensor.",
         "For a quadratic form the Hessian is constant: `(A + A^T) / 2`."])

q(topic="torch", diff="hard", tags=["autograd", "gradcheck"], title="Gradcheck passes",
  ask="Verify with `torch.autograd.gradcheck` that the analytic gradient of "
      "`f(x) = (sin(x) * x).sum()` matches finite differences. Use a `float64` input "
      "and return a `True` boolean (raise/return False if it fails).",
  sig="solve(x)", sol="""
  def f(v):
      return (torch.sin(v) * v).sum()
  return bool(torch.autograd.gradcheck(f, (x.double().requires_grad_(True),)))
  """,
  mk="""
  x = torch.randn(5)
  return (x,)
  """, arg_names=["x"], cmp="none",
  props=["assert _got is True  # gradcheck should pass for a smooth function"],
  hints=["`gradcheck` needs `float64` inputs and a scalar output.",
         "It compares autograd against numerical finite differences."])

q(topic="torch", diff="medium", tags=["autograd", "hook"], title="Capture gradients with a hook",
  ask="Register a backward hook on `x` that stores the incoming gradient, run "
      "`(x ** 2).sum().backward()`, and return the captured tensor.",
  sig="solve(x)", sol="""
  captured = []
  x.register_hook(lambda g: captured.append(g))
  (x ** 2).sum().backward()
  return captured[0]
  """,
  mk="""
  x = torch.randn(3, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  hints=["Hooks receive the gradient flowing into that tensor.",
         "`register_hook` returns a handle you can `.remove()`."])

q(topic="torch", diff="medium", tags=["autograd", "zero_grad"], title="Reset gradients with zero_grad",
  ask="`w` is a leaf parameter with a stale `.grad`. Zero it with `set_to_none=True` "
      "and return `w.grad is None`.",
  sig="solve(w)", sol="""
  w.grad = torch.ones_like(w)
  w.grad.zero_()
  w.grad = None
  return w.grad is None
  """,
  mk="""
  w = torch.randn(3, requires_grad=True)
  (w.sum()).backward()
  return (w,)
  """, arg_names=["w"], cmp="none",
  props=["assert _got is True, 'grad should be None after set_to_none'"],
  hints=["`zero_grad(set_to_none=True)` frees the gradient buffer.",
         "Assigning `None` is the same effect on a leaf tensor."])

# =========================================================================== #
#  Loss functions (manual implementations)
# =========================================================================== #
q(topic="torch", diff="easy", tags=["loss", "mse"], title="Mean squared error",
  ask="Implement MSE between predictions `p` and targets `t` yourself (mean over all "
      "elements) and return a 0-dim tensor.",
  sig="solve(p, t)", sol="return ((p - t) ** 2).mean()",
  mk="""
  cases = [(torch.randn(3, 4), torch.randn(3, 4)), (torch.zeros(2, 2), torch.ones(2, 2)),
           (torch.randn(5), torch.randn(5))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t"],
  props=["assert torch.allclose(_got, torch.nn.functional.mse_loss(_args[0], _args[1]))"],
  hints=["Square the residuals, then take the mean.",
         "`F.mse_loss` does exactly this."])

q(topic="torch", diff="easy", tags=["loss", "mae"], title="Mean absolute error",
  ask="Implement MAE between `p` and `t` (mean of absolute differences).",
  sig="solve(p, t)", sol="return (p - t).abs().mean()",
  mk="""
  cases = [(torch.randn(3, 4), torch.randn(3, 4)), (torch.zeros(4), torch.tensor([1.0, -2.0, 3.0, -4.0])),
           (torch.randn(2, 2), torch.randn(2, 2))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t"],
  props=["assert torch.allclose(_got, torch.nn.functional.l1_loss(_args[0], _args[1]))"],
  hints=["Absolute value, then mean.", "`F.l1_loss` is the built-in version."])

q(topic="torch", diff="medium", tags=["loss", "huber"], title="Huber loss from scratch",
  ask="Implement the Huber loss with `beta = 1`: per element use `0.5 * d^2` when "
      "`|d| <= 1` and `|d| - 0.5` otherwise, then take the mean.",
  sig="solve(p, t)", sol="""
  d = (p - t).abs()
  loss = torch.where(d <= 1.0, 0.5 * d ** 2, d - 0.5)
  return loss.mean()
  """,
  mk="""
  cases = [(torch.randn(3, 4), torch.randn(3, 4)), (torch.zeros(4), torch.tensor([3.0, -0.2, 0.5, -2.0])),
           (torch.randn(6), torch.randn(6))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t"],
  props=["assert torch.allclose(_got, torch.nn.functional.smooth_l1_loss(_args[0], _args[1], beta=1.0), atol=1e-6)"],
  hints=["`torch.where` selects elementwise between the two regimes.",
         "`F.smooth_l1_loss(beta=1)` is the same thing."])

q(topic="torch", diff="medium", tags=["loss", "bce", "stability"], title="BCE with logits (stable)",
  ask="`logits` are raw scores, `targets` are 0/1 floats. Compute the binary "
      "cross-entropy loss with the numerically stable formula: "
      "`max(z, 0) - z * y + log(1 + exp(-|z|))`, averaged over elements.",
  sig="solve(logits, targets)", sol="""
  z, y = logits, targets
  return (torch.clamp(z, min=0) - z * y + torch.log1p(torch.exp(-z.abs()))).mean()
  """,
  mk="""
  cases = [(torch.randn(4, 3) * 5, torch.randint(0, 2, (4, 3)).float()),
           (torch.tensor([[100.0, -100.0]]), torch.tensor([[1.0, 0.0]])),
           (torch.randn(6), torch.randint(0, 2, (6,)).float())]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets"],
  props=["assert torch.allclose(_got, torch.nn.functional.binary_cross_entropy_with_logits(_args[0], _args[1]), atol=1e-5)"],
  hints=["`log(1 + exp(-|z|))` never overflows.",
         "`F.binary_cross_entropy_with_logits` fuses sigmoid and BCE."])

q(topic="torch", diff="medium", tags=["loss", "cross-entropy"], title="Cross-entropy from logits",
  ask="`logits` is `(n, c)` and `targets` is an int64 tensor of class indices `(n,)`. "
      "Implement the mean cross-entropy yourself: "
      "`mean(logsumexp(logits) - logits[range(n), targets])`.",
  sig="solve(logits, targets)", sol="""
  n = logits.shape[0]
  log_probs = logits - torch.logsumexp(logits, dim=1, keepdim=True)
  return -log_probs[torch.arange(n), targets].mean()
  """,
  mk="""
  cases = [(torch.randn(5, 3), torch.randint(0, 3, (5,))),
           (torch.randn(2, 4) * 10, torch.tensor([0, 3])),
           (torch.randn(1, 2), torch.tensor([1]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets"],
  props=["assert torch.allclose(_got, torch.nn.functional.cross_entropy(_args[0], _args[1]), atol=1e-5)"],
  hints=["`torch.logsumexp` stabilises the normaliser.",
         "Gather the target logits with advanced indexing."])

q(topic="torch", diff="hard", tags=["loss", "cross-entropy", "gradient"], title="Gradient of softmax CE",
  ask="`logits` (n, c) and integer `targets` (n,). Return `dL/dlogits` for the **mean** "
      "cross-entropy: `(softmax(logits) - one_hot(targets)) / n`.",
  sig="solve(logits, targets)", sol="""
  n = logits.shape[0]
  probs = torch.softmax(logits, dim=1)
  onehot = torch.nn.functional.one_hot(targets, num_classes=logits.shape[1]).float()
  return (probs - onehot) / n
  """,
  mk="""
  cases = [(torch.randn(4, 3), torch.randint(0, 3, (4,))),
           (torch.randn(2, 5), torch.tensor([0, 4])),
           (torch.randn(3, 2), torch.tensor([1, 1, 0]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets"],
  props=["""
  lg, tg = _args[0].clone().requires_grad_(True), _args[1]
  loss = torch.nn.functional.cross_entropy(lg, tg)
  g, = torch.autograd.grad(loss, lg)
  assert torch.allclose(_got, g, atol=1e-6), "formula should match autograd"
  """],
  hints=["Subtracting the one-hot row from the softmax gives the logits gradient.",
         "Dividing by n accounts for the mean reduction."])

q(topic="torch", diff="medium", tags=["loss", "nll"], title="Negative log-likelihood",
  ask="`log_probs` holds log-probabilities `(n, c)`, `targets` are indices `(n,)`. "
      "Return the mean NLL using `F.nll_loss`.",
  sig="solve(log_probs, targets)", sol="return F.nll_loss(log_probs, targets)",
  mk="""
  x = torch.randn(5, 3)
  return (torch.log_softmax(x, dim=1), torch.randint(0, 3, (5,)))
  """, arg_names=["log_probs", "targets"], imports=NN,
  hints=["`nll_loss` expects **log**-probabilities, not probabilities.",
         "`cross_entropy = nll_loss(log_softmax(logits))`."])

q(topic="torch", diff="medium", tags=["loss", "kl"], title="KL divergence",
  ask="Given the log-probabilities `q_log` and the probabilities `p`, return "
      "`F.kl_div(q_log, p, reduction='batchmean')` — the standard `KL(p || q)` in "
      "PyTorch with `log_target=False`.",
  sig="solve(q_log, p)", sol="return F.kl_div(q_log, p, reduction='batchmean')",
  mk="""
  p = torch.softmax(torch.randn(4, 3), dim=1)
  q = torch.softmax(torch.randn(4, 3), dim=1)
  return (torch.log(q), p)
  """, arg_names=["q_log", "p"], imports=NN,
  hints=["Pass **log-probabilities** of q and plain probabilities of p.",
         "`reduction='batchmean'` divides by the batch size."])

q(topic="torch", diff="hard", tags=["loss", "focal"], title="Focal loss",
  ask="Implement binary focal loss on **logits**: "
      "`p = sigmoid(z)`, `pt = p*y + (1-p)*(1-y)`, "
      "`loss = -(alpha * (1 - pt)^gamma * log(pt))` with `alpha`, `gamma` given; return "
      "the mean. Use a stable log-sigmoid (`F.logsigmoid`) to avoid NaNs.",
  sig="solve(logits, targets, alpha, gamma)", sol="""
  p = torch.sigmoid(logits)
  ce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
  pt = p * targets + (1 - p) * (1 - targets)
  alpha_t = alpha * targets + (1 - alpha) * (1 - targets)
  return (alpha_t * (1 - pt) ** gamma * ce).mean()
  """,
  mk="""
  cases = [(torch.randn(6), torch.randint(0, 2, (6,)).float(), 0.25, 2.0),
           (torch.randn(3, 3) * 3, torch.randint(0, 2, (3, 3)).float(), 0.5, 0.0),
           (torch.randn(4), torch.tensor([1.0, 0.0, 0.0, 1.0]), 0.75, 1.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets", "alpha", "gamma"], imports=NN,
  hints=["With `gamma=0` focal loss reduces to weighted BCE.",
         "Use the BCE-with-logits value for the `-log(pt)` term — it is already stable."])

q(topic="torch", diff="hard", tags=["loss", "label-smoothing"], title="Label-smoothed cross-entropy",
  ask="`logits` (n, c), integer `targets` (n,), smoothing `eps`. Build the smoothed "
      "target distribution `(1 - eps) * one_hot + eps / c` and return the mean "
      "`-(softmax_log_probs * targets).sum(dim=1)` loss (use `log_softmax`).",
  sig="solve(logits, targets, eps)", sol="""
  n, c = logits.shape
  log_probs = torch.log_softmax(logits, dim=1)
  onehot = F.one_hot(targets, num_classes=c).float()
  smooth = (1 - eps) * onehot + eps / c
  return -(smooth * log_probs).sum(dim=1).mean()
  """,
  mk="""
  cases = [(torch.randn(5, 3), torch.randint(0, 3, (5,)), 0.1),
           (torch.randn(2, 4), torch.tensor([1, 2]), 0.0),
           (torch.randn(3, 2) * 2, torch.tensor([0, 1, 1]), 0.5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets", "eps"], imports=NN,
  props=["""
  assert torch.isfinite(_got), "loss must be finite"
  assert _got.ndim == 0, "return a 0-dim tensor"
  if _args[2] == 0.0:
      assert torch.allclose(_got, torch.nn.functional.cross_entropy(_args[0], _args[1]), atol=1e-6)
  """],
  hints=["Smearing eps/c into every class is the standard recipe.",
         "With `eps=0` you get plain cross-entropy."])

q(topic="torch", diff="hard", tags=["loss", "dice"], title="Dice loss",
  ask="For probabilistic predictions `p` and binary targets `t` (floats), return "
      "`1 - (2*sum(p*t) + smooth) / (sum(p) + sum(t) + smooth)`.",
  sig="solve(p, t, smooth)", sol="""
  num = 2 * (p * t).sum() + smooth
  den = p.sum() + t.sum() + smooth
  return 1 - num / den
  """,
  mk="""
  cases = [(torch.rand(4, 5), (torch.rand(4, 5) > 0.5).float(), 1.0),
           (torch.ones(2, 2), torch.ones(2, 2), 0.0),
           (torch.zeros(3), torch.zeros(3), 1e-6)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t", "smooth"],
  hints=["Dice is the harmonic mean of precision and recall.",
         "The smoothing term avoids 0/0 for empty masks."])

q(topic="torch", diff="hard", tags=["loss", "iou"], title="IoU loss for boxes",
  ask="Boxes are `(x1, y1, x2, y2)` corners, shape (n, 4). Return the mean "
      "`1 - IoU(box_a, box_b)` where IoU = intersection area / union area.",
  sig="solve(box_a, box_b)", sol="""
  x1 = torch.max(box_a[:, 0], box_b[:, 0])
  y1 = torch.max(box_a[:, 1], box_b[:, 1])
  x2 = torch.min(box_a[:, 2], box_b[:, 2])
  y2 = torch.min(box_a[:, 3], box_b[:, 3])
  inter = (x2 - x1).clamp(min=0) * (y2 - y1).clamp(min=0)
  area_a = (box_a[:, 2] - box_a[:, 0]) * (box_a[:, 3] - box_a[:, 1])
  area_b = (box_b[:, 2] - box_b[:, 0]) * (box_b[:, 3] - box_b[:, 1])
  union = area_a + area_b - inter
  iou = inter / union.clamp(min=1e-9)
  return (1 - iou).mean()
  """,
  mk="""
  a = torch.tensor([[0.0, 0.0, 2.0, 2.0], [1.0, 1.0, 3.0, 3.0], [0.0, 0.0, 4.0, 4.0]])
  b = torch.tensor([[1.0, 1.0, 3.0, 3.0], [1.0, 1.0, 3.0, 3.0], [2.0, 2.0, 6.0, 6.0]])
  return (a, b)
  """, arg_names=["box_a", "box_b"],
  hints=["Clamp the corner differences at zero for disjoint boxes.",
         "Divide by the union area, guarding against zero."])

q(topic="torch", diff="medium", tags=["loss", "hinge"], title="Hinge loss",
  ask="Binary labels `y` are -1/+1 and scores are `s`. Return the mean "
      "`clamp(1 - y*s, min=0)` loss.",
  sig="solve(s, y)", sol="return torch.clamp(1 - y * s, min=0).mean()",
  mk="""
  cases = [(torch.randn(6), torch.where(torch.rand(6) > 0.5, 1.0, -1.0)),
           (torch.tensor([1.0, -1.0]), torch.tensor([1.0, 1.0])),
           (torch.randn(3, 2), torch.ones(3, 2))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s", "y"],
  hints=["Correctly classified points beyond the margin contribute 0.",
         "`clamp(min=0)` implements the max(0, ·)."])

q(topic="torch", diff="hard", tags=["loss", "triplet"], title="Triplet margin loss",
  ask="Given `anchor`, `positive`, `negative` batches of embeddings and `margin`, return "
      "the mean `clamp(||a - p|| - ||a - n|| + margin, min=0)`. Use L2 norm over dim 1.",
  sig="solve(anchor, positive, negative, margin)", sol="""
  d_pos = (anchor - positive).pow(2).sum(dim=1).sqrt()
  d_neg = (anchor - negative).pow(2).sum(dim=1).sqrt()
  return torch.clamp(d_pos - d_neg + margin, min=0).mean()
  """,
  mk="""
  cases = [(torch.randn(5, 8), torch.randn(5, 8), torch.randn(5, 8), 1.0),
           (torch.zeros(2, 3), torch.ones(2, 3), torch.full((2, 3), 5.0), 0.5),
           (torch.randn(1, 4), torch.randn(1, 4), torch.randn(1, 4), 2.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["anchor", "positive", "negative", "margin"],
  hints=["Compute both distances with the same norm.",
         "The margin keeps a gap between positive and negative distances."])

q(topic="torch", diff="medium", tags=["loss", "cosine"], title="Cosine embedding loss",
  ask="Return `F.cosine_embedding_loss(x1, x2, target, margin=0.5)` for the given "
      "inputs and targets.",
  sig="solve(x1, x2, target)", sol="return F.cosine_embedding_loss(x1, x2, target, margin=0.5)",
  mk="""
  cases = [(torch.randn(3, 4), torch.randn(3, 4), torch.tensor([1.0, -1.0, 1.0])),
           (torch.ones(2, 3), torch.ones(2, 3), torch.tensor([1.0, 1.0])),
           (torch.randn(4, 2), torch.randn(4, 2), torch.tensor([-1.0, 1.0, -1.0, 1.0]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x1", "x2", "target"], imports=NN,
  hints=["Target 1 means 'similar', -1 means 'dissimilar beyond margin'.",
         "Similarity is the cosine between the rows."])

q(topic="torch", diff="medium", tags=["loss", "weights"], title="Weighted cross-entropy",
  ask="Implement weighted cross-entropy with per-class weights `w` (shape (c,)): weight "
      "each sample loss by `w[target]`, then normalise by the **sum of the used weights** "
      "(this is PyTorch's `mean` convention for the `weight` argument).",
  sig="solve(logits, targets, w)", sol="""
  log_probs = torch.log_softmax(logits, dim=1)
  per_sample = -log_probs[torch.arange(logits.shape[0]), targets]
  w_t = w[targets]
  return (per_sample * w_t).sum() / w_t.sum()
  """,
  mk="""
  cases = [(torch.randn(6, 3), torch.randint(0, 3, (6,)), torch.tensor([1.0, 2.0, 0.5])),
           (torch.randn(2, 2), torch.tensor([0, 1]), torch.tensor([1.0, 1.0])),
           (torch.randn(4, 4), torch.tensor([3, 3, 0, 1]), torch.tensor([1.0, 1.0, 1.0, 4.0]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets", "w"],
  props=["assert torch.allclose(_got, torch.nn.functional.cross_entropy(_args[0], _args[1], weight=_args[2]), atol=1e-6)"],
  hints=["Index the weight vector with the target classes.",
         "`F.cross_entropy(..., weight=w)` matches this formula."])

q(topic="torch", diff="medium", tags=["loss", "perplexity"], title="Perplexity",
  ask="Given the mean cross-entropy `loss` (a scalar tensor), return `exp(loss)` — the "
      "perplexity.",
  sig="solve(loss)", sol="return torch.exp(loss)",
  mk="""
  cases = [(torch.tensor(0.0),), (torch.tensor(1.0),), (torch.tensor(2.5),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["loss"],
  hints=["Perplexity is the exponential of the average NLL.",
         "A loss of 0 means perplexity 1."])

q(topic="torch", diff="medium", tags=["loss", "reduction"], title="Sum reduction of MSE",
  ask="Return the **sum** of squared errors between `p` and `t` (no averaging).",
  sig="solve(p, t)", sol="return ((p - t) ** 2).sum()",
  mk="""
  cases = [(torch.randn(3, 4), torch.randn(3, 4)), (torch.zeros(2), torch.ones(2)),
           (torch.randn(5), torch.randn(5))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t"],
  props=["assert torch.allclose(_got, torch.nn.functional.mse_loss(_args[0], _args[1], reduction='sum'))"],
  hints=["`reduction='sum'` in `F.mse_loss` is the built-in equivalent.",
         "Note how this scales with the number of elements."])

q(topic="torch", diff="hard", tags=["loss", "contrastive"], title="InfoNCE loss",
  ask="`z1`, `z2` are (n, d) embeddings of matched pairs. L2-normalise each, compute the "
      "`(n, n)` similarity matrix scaled by `1/temperature`, and return the mean "
      "cross-entropy of the diagonal (the positive pair for row i is column i).",
  sig="solve(z1, z2, temperature)", sol="""
  a = F.normalize(z1, dim=1)
  b = F.normalize(z2, dim=1)
  sim = a @ b.t() / temperature
  labels = torch.arange(a.shape[0])
  return F.cross_entropy(sim, labels)
  """,
  mk="""
  cases = [(torch.randn(4, 8), torch.randn(4, 8), 0.5),
           (torch.randn(2, 3), torch.randn(2, 3), 0.1),
           (torch.randn(6, 4), torch.randn(6, 4), 1.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["z1", "z2", "temperature"], imports=NN,
  hints=["Normalise before the dot product so the similarity is a cosine.",
         "The labels are simply `arange(n)` — the diagonal is positive."])

# =========================================================================== #
#  nn.Module: Linear, parameters, containers
# =========================================================================== #
q(topic="torch", diff="easy", tags=["nn", "linear"], title="Linear layer forward",
  ask="Apply the `nn.Linear` layer `layer` to `x` and return the output.",
  sig="solve(layer, x)", sol="return layer(x)",
  mk="""
  layer = nn.Linear(4, 3)
  return (layer, torch.randn(5, 4))
  """, arg_names=["layer", "x"], imports=NN,
  props=["assert _got.shape == (5, 3)"],
  hints=["`layer(x)` computes `x @ W.T + b`.", "The input's last dimension must be 4."])

q(topic="torch", diff="medium", tags=["nn", "linear", "manual"], title="Linear layer from scratch",
  ask="Given `x` (n, in), `weight` (out, in) and `bias` (out,), compute the linear "
      "transformation manually: `x @ weight.T + bias`.",
  sig="solve(x, weight, bias)", sol="return x @ weight.t() + bias",
  mk="""
  cases = [(torch.randn(5, 4), torch.randn(3, 4), torch.randn(3)),
           (torch.randn(2, 2), torch.randn(2, 2), torch.randn(2)),
           (torch.randn(1, 6), torch.randn(4, 6), torch.randn(4))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "weight", "bias"],
  props=["""
  lin = nn.Linear(_args[1].shape[1], _args[1].shape[0])
  with torch.no_grad():
      lin.weight.copy_(_args[1]); lin.bias.copy_(_args[2])
  assert torch.allclose(_got, lin(_args[0]), atol=1e-6), "should match nn.Linear"
  """],
  hints=["`nn.Linear` stores weight as `(out_features, in_features)`.",
         "Transpose the weight before the matrix product."])

q(topic="torch", diff="easy", tags=["nn", "sequential"], title="Sequential forward",
  ask="Apply the `nn.Sequential` model `model` to `x`.",
  sig="solve(model, x)", sol="return model(x)",
  mk="""
  model = nn.Sequential(nn.Linear(6, 4), nn.ReLU(), nn.Linear(4, 2))
  return (model, torch.randn(3, 6))
  """, arg_names=["model", "x"], imports=NN,
  hints=["`nn.Sequential` chains modules in order.",
         "Calling the model runs the whole chain."])

q(topic="torch", diff="medium", tags=["nn", "parameter"], title="Register a parameter",
  ask="Complete the module so that `w` is a learnable `nn.Parameter` of shape `(3, 4)`: "
      "return `module.w` (it must appear in `module.parameters()`).",
  sig="solve(module)", sol="""
  assert isinstance(module.w, nn.Parameter)
  return module.w
  """,
  mk="""
  class M(nn.Module):
      def __init__(self):
          super().__init__()
          self.w = nn.Parameter(torch.randn(3, 4))
  return (M(),)
  """, arg_names=["module"], imports=NN,
  props=["assert dict(_args[0].named_parameters()).get('w') is _got"],
  hints=["`nn.Parameter` wraps a tensor and registers it automatically.",
         "A plain attribute would not show up in `.parameters()`."])

q(topic="torch", diff="medium", tags=["nn", "parameters"], title="Count trainable parameters",
  ask="Return the total number of scalar parameters in `model` (an int).",
  sig="solve(model)", sol="return sum(p.numel() for p in model.parameters())",
  mk="""
  cases = [(nn.Sequential(nn.Linear(4, 3), nn.Linear(3, 2)),),
           (nn.Linear(5, 1),),
           (nn.Sequential(nn.Conv2d(3, 8, 3), nn.Flatten(), nn.Linear(8 * 6 * 6, 10)),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["model"], imports=NN,
  props=["assert isinstance(_got, int)"],
  hints=["`p.numel()` counts the entries of each parameter tensor.",
         "Linear(4,3) has 4*3 + 3 = 15 parameters."])

q(topic="torch", diff="medium", tags=["nn", "freeze"], title="Freeze the features",
  ask="Set `requires_grad = False` on every parameter of `model`, then return the number "
      "of parameters that still require grad (an int).",
  sig="solve(model)", sol="""
  for p in model.parameters():
      p.requires_grad_(False)
  return sum(p.requires_grad for p in model.parameters())
  """,
  mk="""
  cases = [(nn.Linear(3, 2),), (nn.Sequential(nn.Linear(2, 2), nn.ReLU()),),
           (nn.Conv2d(1, 2, 3),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["model"], imports=NN, cmp="none",
  props=["assert _got == 0, 'all parameters should be frozen'",
         "assert all(not p.requires_grad for p in _args[0].parameters())"],
  hints=["`p.requires_grad_(False)` toggles a leaf parameter in place.",
         "Frozen parameters are skipped by optimizers and autograd."])

q(topic="torch", diff="medium", tags=["nn", "state_dict"], title="State dict keys",
  ask="Return the list of keys of `model.state_dict()` in order.",
  sig="solve(model)", sol="return list(model.state_dict().keys())",
  mk="""
  cases = [(nn.Linear(2, 3),), (nn.Sequential(nn.Linear(2, 4), nn.Linear(4, 1)),),
           (nn.Conv2d(1, 2, 3, bias=False),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["model"], imports=NN,
  hints=["Linear layers contribute `weight` and `bias`.",
         "`bias=False` removes the bias key."])

q(topic="torch", diff="hard", tags=["nn", "state_dict", "save"], title="Round-trip a state dict",
  ask="Save `model.state_dict()` into an in-memory `io.BytesIO` with `torch.save`, load "
      "it back with `torch.load(..., weights_only=True)` into a fresh model of the same "
      "architecture (`model.__class__`, same constructor arguments are not needed: copy "
      "the loaded dict into `model2` with `load_state_dict`), and return `model2.weight`.",
  sig="solve(model)", sol="""
  import io
  buf = io.BytesIO()
  torch.save(model.state_dict(), buf)
  buf.seek(0)
  sd = torch.load(buf, weights_only=True)
  model2 = nn.Linear(model.in_features, model.out_features)
  model2.load_state_dict(sd)
  return model2.weight
  """,
  mk="""
  cases = [(nn.Linear(3, 2),), (nn.Linear(5, 4),), (nn.Linear(1, 1),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["model"], imports=NN,
  hints=["`torch.save` writes to any file-like object.",
         "`load_state_dict` copies the values into the existing parameters."])

q(topic="torch", diff="easy", tags=["nn", "eval"], title="Switch to eval mode",
  ask="Put `model` in evaluation mode and return `model.training`.",
  sig="solve(model)", sol="""
  model.eval()
  return model.training
  """,
  mk="""
  model = nn.Sequential(nn.Linear(2, 2), nn.Dropout(0.5))
  model.train()
  return (model,)
  """, arg_names=["model"], imports=NN,
  hints=["`model.eval()` sets `training=False` for the whole subtree.",
         "Dropout and BatchNorm behave differently in eval mode."])

q(topic="torch", diff="medium", tags=["nn", "modulelist"], title="Sum over a ModuleList",
  ask="`layers` is an `nn.ModuleList` of linear layers that all map `(n, d)` to `(n, d)`. "
      "Apply them **in sequence** to `x` and return the result.",
  sig="solve(layers, x)", sol="""
  for layer in layers:
      x = layer(x)
  return x
  """,
  mk="""
  layers = nn.ModuleList([nn.Linear(4, 4), nn.Linear(4, 4), nn.Linear(4, 4)])
  return (layers, torch.randn(3, 4))
  """, arg_names=["layers", "x"], imports=NN,
  hints=["`ModuleList` is not callable itself — loop over it.",
         "Each layer transforms the current activation."])

q(topic="torch", diff="hard", tags=["nn", "module"], title="Custom module with a residual",
  ask="Complete a module whose forward computes `relu(linear(x)) + x`. `lin` maps d to d. "
      "Return the forward output.",
  sig="solve(module, x)", sol="return module(x)",
  mk="""
  class Res(nn.Module):
      def __init__(self, d):
          super().__init__()
          self.lin = nn.Linear(d, d)
      def forward(self, x):
          return torch.relu(self.lin(x)) + x
  return (Res(5), torch.randn(4, 5))
  """, arg_names=["module", "x"], imports=NN,
  hints=["Residual connections add the input back to the transformed activation.",
         "The shapes must match — hence the square linear layer."])

q(topic="torch", diff="medium", tags=["nn", "embedding"], title="Embedding lookup",
  ask="`emb` is an `nn.Embedding`. Return the embeddings of the token indices `idx` "
      "(shape (b, t)).",
  sig="solve(emb, idx)", sol="return emb(idx)",
  mk="""
  emb = nn.Embedding(10, 4)
  return (emb, torch.tensor([[1, 2, 3], [4, 4, 0]]))
  """, arg_names=["emb", "idx"], imports=NN,
  hints=["`nn.Embedding` is a lookup table of shape `(num_embeddings, dim)`.",
         "The input must be an int64 tensor."])

q(topic="torch", diff="medium", tags=["nn", "embedding", "manual"], title="Embedding from scratch",
  ask="`weight` is a (vocab, dim) matrix. Return the rows selected by `idx` (shape (b, t) "
      "-> (b, t, dim)) without using `nn.Embedding`.",
  sig="solve(weight, idx)", sol="return weight[idx]",
  mk="""
  cases = [(torch.randn(10, 4), torch.tensor([[0, 2], [5, 5]])),
           (torch.randn(3, 2), torch.tensor([[2, 1, 0]])),
           (torch.randn(6, 3), torch.tensor([[1]]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["weight", "idx"],
  hints=["Advanced indexing with an int tensor selects rows.",
         "The result gains a trailing `dim` axis."])

q(topic="torch", diff="medium", tags=["nn", "dropout"], title="Dropout in eval mode",
  ask="Apply `F.dropout(x, p=0.5, training=False)` — in evaluation mode dropout is the "
      "identity.",
  sig="solve(x)", sol="return F.dropout(x, p=0.5, training=False)",
  mk="""
  cases = [(torch.randn(4, 5),), (torch.ones(3),), (torch.zeros(2, 2),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  props=["assert torch.equal(_got, _args[0]), 'eval dropout must be the identity'"],
  hints=["`training=False` disables the dropping entirely.",
         "This is why `model.eval()` matters at inference time."])

q(topic="torch", diff="medium", tags=["nn", "dropout"], title="Dropout in train mode",
  ask="Apply `F.dropout(x, p=0.5, training=True)` using the global RNG (the harness "
      "seeds it identically for the reference and for you).",
  sig="solve(x)", sol="return F.dropout(x, p=0.5, training=True)",
  mk="""
  cases = [(torch.randn(4, 5),), (torch.ones(10),), (torch.randn(8, 2),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  props=["assert _got.shape == _args[0].shape"],
  hints=["Surviving activations are scaled by `1/(1-p)`.",
         "Values are either 0 or `x / 0.5`."])

q(topic="torch", diff="medium", tags=["nn", "init"], title="Zero the weights",
  ask="Initialise the weight of the `nn.Linear` layer `layer` to zeros (in place) and "
      "return the layer's output on `x` — every output equals the bias.",
  sig="solve(layer, x)", sol="""
  nn.init.zeros_(layer.weight)
  return layer(x)
  """,
  mk="""
  cases = [(nn.Linear(4, 3), torch.randn(2, 4)), (nn.Linear(2, 2), torch.randn(5, 2)),
           (nn.Linear(1, 1), torch.randn(3, 1))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["layer", "x"], imports=NN,
  hints=["`nn.init.zeros_` operates in place.",
         "With a zero weight the output is just the bias broadcast."])

q(topic="torch", diff="hard", tags=["nn", "init", "xavier"], title="Xavier uniform init",
  ask="Apply `nn.init.xavier_uniform_` to the weight of `layer` and return the weight's "
      "standard deviation (a 0-dim tensor). Property checks confirm the bound "
      "`sqrt(6 / (fan_in + fan_out))`.",
  sig="solve(layer)", sol="""
  nn.init.xavier_uniform_(layer.weight)
  return layer.weight.std()
  """,
  mk="""
  cases = [(nn.Linear(100, 50),), (nn.Linear(20, 20),), (nn.Linear(8, 4),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["layer"], imports=NN, cmp="none",
  props=["""
  fan_in, fan_out = _args[0].weight.shape[1], _args[0].weight.shape[0]
  bound = (6.0 / (fan_in + fan_out)) ** 0.5
  assert (_args[0].weight.abs() <= bound + 1e-6).all(), "weights must respect the Xavier bound"
  assert 0.0 < float(_got) < bound
  """],
  hints=["Xavier uniform samples from `U(-a, a)` with `a = sqrt(6/(fan_in+fan_out))`.",
         "Check the bound as well as the spread."])

q(topic="torch", diff="hard", tags=["nn", "init", "kaiming"], title="Kaiming normal init",
  ask="Apply `nn.init.kaiming_normal_(layer.weight, nonlinearity='relu')` and return the "
      "weight. Property checks verify the std is close to `sqrt(2/fan_in)`.",
  sig="solve(layer)", sol="""
  nn.init.kaiming_normal_(layer.weight, nonlinearity='relu')
  return layer.weight
  """,
  mk="""
  cases = [(nn.Linear(1000, 500),), (nn.Linear(500, 100),), (nn.Linear(2000, 2000),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["layer"], imports=NN, cmp="none",
  props=["""
  fan_in = _args[0].weight.shape[1]
  expected = (2.0 / fan_in) ** 0.5
  got = float(_got.std())
  assert abs(got - expected) < 0.25 * expected, f"std {got:.4f} far from sqrt(2/fan_in)={expected:.4f}"
  """],
  hints=["Kaiming normal uses `std = sqrt(2/fan_in)` for ReLU.",
         "`nonlinearity='relu'` selects the gain of 2."])

q(topic="torch", diff="medium", tags=["nn", "init"], title="Orthogonal init",
  ask="Apply `nn.init.orthogonal_` to the square weight of `layer` and return "
      "`weight @ weight.T` — property checks confirm it is close to the identity.",
  sig="solve(layer)", sol="""
  nn.init.orthogonal_(layer.weight)
  return layer.weight @ layer.weight.T
  """,
  mk="""
  cases = [(nn.Linear(5, 5, bias=False),), (nn.Linear(3, 3, bias=False),), (nn.Linear(8, 8, bias=False),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["layer"], imports=NN,
  props=["assert torch.allclose(_got, torch.eye(_got.shape[0]), atol=1e-5)"],
  hints=["Orthogonal rows keep the norm of activations.",
         "`W @ W.T` is the identity for an orthogonal square matrix."])

q(topic="torch", diff="medium", tags=["nn", "batchnorm"], title="BatchNorm in train mode",
  ask="`bn` is an `nn.BatchNorm1d` and `x` is `(n, c)`. Forward in **train** mode and "
      "return the normalised output. The running statistics of the module are updated "
      "as a side effect — the tests check that too.",
  sig="solve(bn, x)", sol="""
  bn.train()
  return bn(x)
  """,
  mk="""
  bn = nn.BatchNorm1d(4)
  return (bn, torch.randn(8, 4) * 3 + 1)
  """, arg_names=["bn", "x"], imports=NN, cmp="mut",
  hints=["In train mode BN uses the **batch** statistics.",
         "Running statistics are updated with momentum 0.1."])

q(topic="torch", diff="hard", tags=["nn", "batchnorm", "manual"], title="BatchNorm from scratch",
  ask="Implement batch normalisation in training mode: normalise each feature over the "
      "batch, then scale and shift with `gamma`, `beta`. Use `eps` for the variance. "
      "Return the output.",
  sig="solve(x, gamma, beta, eps)", sol="""
  mean = x.mean(dim=0, keepdim=True)
  var = x.var(dim=0, keepdim=True, unbiased=False)
  xhat = (x - mean) / torch.sqrt(var + eps)
  return gamma * xhat + beta
  """,
  mk="""
  cases = [(torch.randn(8, 4) * 2 + 1, torch.ones(4), torch.zeros(4), 1e-5),
           (torch.randn(16, 3), torch.rand(3) + 0.5, torch.randn(3), 1e-3),
           (torch.randn(4, 6), torch.ones(6), torch.zeros(6), 1e-5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "gamma", "beta", "eps"],
  props=["""
  x, gamma, beta, eps = _args
  bn = nn.BatchNorm1d(x.shape[1], eps=eps).train()
  with torch.no_grad():
      bn.weight.copy_(gamma); bn.bias.copy_(beta)
      ref = bn(x)
  assert torch.allclose(_got, ref, atol=1e-4), "should match nn.BatchNorm1d in train mode"
  """],
  hints=["Normalise over the **batch** dimension, per feature.",
         "Use the biased variance (`unbiased=False`) as BN does."])

q(topic="torch", diff="hard", tags=["nn", "batchnorm"], title="BatchNorm in eval mode",
  ask="`bn` has already been trained (its running stats are meaningful). Forward `x` in "
      "**eval** mode and return the output.",
  sig="solve(bn, x)", sol="""
  bn.eval()
  return bn(x)
  """,
  mk="""
  bn = nn.BatchNorm1d(3)
  bn.train()
  for _ in range(5):
      bn(torch.randn(16, 3) * 2 + 3)
  bn.eval()
  return (bn, torch.randn(4, 3))
  """, arg_names=["bn", "x"], imports=NN,
  hints=["Eval mode uses `running_mean` / `running_var` instead of batch stats.",
         "That makes inference independent of the batch composition."])

q(topic="torch", diff="hard", tags=["nn", "layernorm", "manual"], title="LayerNorm from scratch",
  ask="Implement layer normalisation over the last dimension: normalise each row to zero "
      "mean / unit variance (biased), then scale and shift with `gamma`, `beta`.",
  sig="solve(x, gamma, beta, eps)", sol="""
  mean = x.mean(dim=-1, keepdim=True)
  var = x.var(dim=-1, keepdim=True, unbiased=False)
  return gamma * (x - mean) / torch.sqrt(var + eps) + beta
  """,
  mk="""
  cases = [(torch.randn(4, 8), torch.ones(8), torch.zeros(8), 1e-5),
           (torch.randn(3, 5) * 4, torch.rand(5) + 0.5, torch.randn(5), 1e-6),
           (torch.randn(2, 3, 6), torch.ones(6), torch.zeros(6), 1e-5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "gamma", "beta", "eps"],
  props=["""
  x, gamma, beta, eps = _args
  ln = nn.LayerNorm(x.shape[-1], eps=eps)
  with torch.no_grad():
      ln.weight.copy_(gamma); ln.bias.copy_(beta)
      ref = ln(x)
  assert torch.allclose(_got, ref, atol=1e-5), "should match nn.LayerNorm"
  """],
  hints=["Normalise across the last dim, per example.",
         "`keepdim=True` keeps broadcasting aligned."])

q(topic="torch", diff="medium", tags=["nn", "conv", "shape"], title="Conv2d output shape",
  ask="Return the height and width of the output of a 1-channel conv2d with kernel "
      "`k`, stride `s` and padding `p` on an input of height `h` and width `w`, as a "
      "tuple `(h_out, w_out)`.",
  sig="solve(h, w, k, s, p)", sol="""
  h_out = (h - k + 2 * p) // s + 1
  w_out = (w - k + 2 * p) // s + 1
  return (h_out, w_out)
  """,
  mk="""
  cases = [(28, 28, 3, 1, 1), (32, 32, 5, 2, 0), (7, 7, 3, 1, 0), (64, 48, 3, 2, 1)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["h", "w", "k", "s", "p"],
  props=["""
  h, w, k, s, p = _args
  out = nn.Conv2d(1, 1, k, stride=s, padding=p)(torch.zeros(1, 1, h, w))
  assert tuple(_got) == tuple(out.shape[-2:]), "formula must match nn.Conv2d"
  """],
  hints=["`floor((H - K + 2P) / S) + 1`.",
         "Integer division is the floor here."])

q(topic="torch", diff="medium", tags=["nn", "conv"], title="Conv2d forward",
  ask="Apply the `nn.Conv2d` layer `conv` to the batch `x` (shape (b, c, h, w)).",
  sig="solve(conv, x)", sol="return conv(x)",
  mk="""
  conv = nn.Conv2d(3, 8, 3, padding=1)
  return (conv, torch.randn(2, 3, 8, 8))
  """, arg_names=["conv", "x"], imports=NN,
  props=["assert _got.shape == (2, 8, 8, 8)"],
  hints=["`padding=1` with a 3x3 kernel keeps the spatial size.",
         "Output channels come from `out_channels`."])

q(topic="torch", diff="hard", tags=["nn", "conv", "manual", "unfold"], title="Conv2d with unfold",
  ask="Implement 2-D convolution manually using `F.unfold`: extract 3x3 patches with "
      "`F.unfold(x, 3)`, multiply by the flattened weight and add the bias. Return the "
      "output of shape (b, out_channels, h-2, w-2).",
  sig="solve(x, weight, bias)", sol="""
  b = x.shape[0]
  cols = F.unfold(x, 3)                       # (b, c*9, L)
  out = weight.reshape(weight.shape[0], -1) @ cols   # (b, out, L)
  out = out + bias.reshape(1, -1, 1)
  h_out = x.shape[-2] - 2
  return out.reshape(b, weight.shape[0], h_out, h_out)
  """,
  mk="""
  conv = nn.Conv2d(3, 4, 3)
  x = torch.randn(2, 3, 6, 6)
  return (x, conv.weight, conv.bias)
  """, arg_names=["x", "weight", "bias"], imports=NN,
  props=["""
  x, w, b = _args
  ref = F.conv2d(x, w, b)
  assert torch.allclose(_got, ref, atol=1e-5), "manual conv must match F.conv2d"
  """],
  hints=["`unfold` turns sliding windows into columns: `(b, c*k*k, L)`.",
         "Flatten the weight to `(out_channels, c*k*k)` and matmul."])

q(topic="torch", diff="medium", tags=["nn", "conv"], title="Depthwise convolution",
  ask="`x` has `c` channels. Build a **depthwise** 3x3 convolution with `groups=c`, apply "
      "it and return the output shape (a torch.Size) — prove the channel mixing is "
      "disabled.",
  sig="solve(x)", sol="""
  c = x.shape[1]
  conv = nn.Conv2d(c, c, 3, padding=1, groups=c)
  return conv(x).shape
  """,
  mk="""
  cases = [(torch.randn(2, 4, 8, 8),), (torch.randn(1, 1, 5, 5),), (torch.randn(3, 6, 4, 4),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  hints=["`groups=c` makes each input channel convolve on its own.",
         "Depthwise convolutions are the first half of a separable conv."])

q(topic="torch", diff="medium", tags=["nn", "pooling"], title="Max pooling",
  ask="Apply 2x2 max pooling with stride 2 to `x` using `F.max_pool2d`.",
  sig="solve(x)", sol="return F.max_pool2d(x, kernel_size=2, stride=2)",
  mk="""
  cases = [(torch.randn(2, 3, 8, 8),), (torch.randn(1, 1, 4, 4),), (torch.randn(2, 2, 6, 6),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  hints=["Pooling halves the spatial dimensions here.",
         "It operates per channel, independently."])

q(topic="torch", diff="medium", tags=["nn", "pooling"], title="Average pooling",
  ask="Apply 2x2 average pooling (stride 2) with `F.avg_pool2d`.",
  sig="solve(x)", sol="return F.avg_pool2d(x, kernel_size=2, stride=2)",
  mk="""
  cases = [(torch.randn(2, 3, 8, 8),), (torch.randn(1, 2, 4, 4),), (torch.randn(2, 1, 6, 6),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  hints=["Average pooling smooths instead of taking the max.",
         "Same kernel/stride convention as max pooling."])

q(topic="torch", diff="medium", tags=["nn", "pooling"], title="Global average pooling",
  ask="Reduce `x` (b, c, h, w) to (b, c) by averaging over the spatial dimensions using "
      "`F.adaptive_avg_pool2d(x, 1)` and flattening.",
  sig="solve(x)", sol="return F.adaptive_avg_pool2d(x, 1).flatten(1)",
  mk="""
  cases = [(torch.randn(2, 5, 7, 7),), (torch.randn(1, 3, 4, 4),), (torch.randn(4, 2, 9, 5),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  hints=["`adaptive_avg_pool2d(x, 1)` gives a (b, c, 1, 1) tensor.",
         "Flatten from dim 1 to get (b, c)."])

q(topic="torch", diff="hard", tags=["nn", "conv", "transpose"], title="ConvTranspose output shape",
  ask="For `nn.ConvTranspose2d`, return the output `(h_out, w_out)` given input `h, w`, "
      "kernel `k`, stride `s`, padding `p` and output padding `op`.",
  sig="solve(h, w, k, s, p, op)", sol="""
  return ((h - 1) * s - 2 * p + k + op, (w - 1) * s - 2 * p + k + op)
  """,
  mk="""
  cases = [(8, 8, 2, 2, 0, 0), (4, 4, 3, 2, 1, 1), (5, 6, 4, 2, 1, 0), (1, 1, 3, 1, 1, 0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["h", "w", "k", "s", "p", "op"],
  props=["""
  h, w, k, s, p, op = _args
  layer = nn.ConvTranspose2d(1, 1, k, stride=s, padding=p, output_padding=op)
  out = layer(torch.zeros(1, 1, h, w))
  assert tuple(_got) == tuple(out.shape[-2:]), "formula must match nn.ConvTranspose2d"
  """],
  hints=["`(H-1)*S - 2P + K + output_padding`.",
         "Transposed convs usually double the spatial size with `k=2, s=2`."])

q(topic="torch", diff="hard", tags=["nn", "receptive-field"], title="Receptive field",
  ask="Three stacked 3x3 convolutions (stride 1, no padding). Return the receptive field "
      "size of one output neuron as an int, computed by the recurrence "
      "`rf = rf + (k - 1) * jump; jump *= s`.",
  sig="solve(n_layers, k, s)", sol="""
  rf, jump = 1, 1
  for _ in range(n_layers):
      rf += (k - 1) * jump
      jump *= s
  return rf
  """,
  mk="""
  cases = [(3, 3, 1), (2, 3, 2), (5, 3, 1), (1, 5, 1)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n_layers", "k", "s"],
  hints=["Start with `rf = 1`, `jump = 1`.",
         "Each layer grows the field by `(k-1) * jump`."])

q(topic="torch", diff="hard", tags=["nn", "conv", "manual", "pool"], title="Max pooling with unfold",
  ask="Implement 2x2/size-2 max pooling using `F.unfold(x, 2, stride=2)` and "
      "`amax(dim=1)`, reshaped to (b, c, h/2, w/2).",
  sig="solve(x)", sol="""
  b, c, h, w = x.shape
  cols = F.unfold(x, 2, stride=2)          # (b, c*4, L)
  cols = cols.reshape(b, c, 4, -1)
  out = cols.amax(dim=2)
  return out.reshape(b, c, h // 2, w // 2)
  """,
  mk="""
  cases = [(torch.randn(2, 3, 8, 8),), (torch.randn(1, 2, 4, 4),), (torch.randn(3, 1, 6, 6),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"], imports=NN,
  props=["assert torch.allclose(_got, F.max_pool2d(_args[0], 2, 2), atol=1e-6)"],
  hints=["`unfold` groups each 2x2 window into 4 entries per channel.",
         "Max over those 4 entries, then reshape back."])

# =========================================================================== #
#  Optimizers
# =========================================================================== #
q(topic="torch", diff="easy", tags=["optim", "sgd"], title="Manual SGD step",
  ask="Take one plain SGD step: `w = w - lr * w.grad`, in place under `torch.no_grad()`. "
      "Do **not** zero the gradient afterwards. Return `w`.",
  sig="solve(w, lr)", sol="""
  with torch.no_grad():
      w -= lr * w.grad
  return w
  """,
  mk="""
  w = torch.randn(3, requires_grad=True)
  (w.sum()).backward()
  return (w, [0.1, 1.0, 0.01][v])
  """, arg_names=["w", "lr"], cmp="mut",
  hints=["Parameter updates must not be recorded by autograd.",
         "Gradient here is all ones, so every element loses exactly `lr`."])

q(topic="torch", diff="medium", tags=["optim", "sgd"], title="Optimizer SGD step",
  ask="Create `torch.optim.SGD([w], lr=lr)` and take one `step()`. Return `w`.",
  sig="solve(w, lr)", sol="""
  opt = torch.optim.SGD([w], lr=lr)
  opt.step()
  return w
  """,
  mk="""
  w = torch.randn(4, requires_grad=True)
  (w.pow(2).sum()).backward()
  return (w, [0.1, 0.5, 0.01][v])
  """, arg_names=["w", "lr"], cmp="mut",
  hints=["`optimizer.step()` applies the update using `.grad`.",
         "The gradient is `2w` here, so `w` moves towards zero."])

q(topic="torch", diff="medium", tags=["optim", "momentum"], title="SGD with momentum, manual",
  ask="Implement one momentum step without an optimizer. Given the velocity buffer `buf`, "
      "do `buf = mu * buf + grad` and `w = w - lr * buf` (in place on both). Return `w`.",
  sig="solve(w, buf, lr, mu)", sol="""
  with torch.no_grad():
      buf.mul_(mu).add_(w.grad)
      w -= lr * buf
  return w
  """,
  mk="""
  w = torch.randn(3, requires_grad=True)
  (w.sum()).backward()
  return (w, torch.zeros(3), [0.1, 0.5, 0.01][v], 0.9)
  """, arg_names=["w", "buf", "lr", "mu"], cmp="mut",
  hints=["The velocity buffer accumulates past gradients.",
         "First step: `buf` becomes the gradient itself."])

q(topic="torch", diff="medium", tags=["optim", "momentum"], title="Momentum matches PyTorch",
  ask="Return the tuple `(new_w, new_buf)` after one SGD+momentum step, computed manually "
      "(do not mutate the inputs). Property checks compare against `torch.optim.SGD`.",
  sig="solve(w, buf, lr, mu)", sol="""
  g = w.grad
  new_buf = mu * buf + g
  return (w - lr * new_buf, new_buf)
  """,
  mk="""
  w = torch.randn(5, requires_grad=True)
  (w.pow(2).sum()).backward()
  return (w, torch.randn(5), [0.1, 0.2, 0.05][v], 0.9)
  """, arg_names=["w", "buf", "lr", "mu"],
  props=["""
  w, buf, lr, mu = _args
  p = w.detach().clone().requires_grad_(True)
  p.grad = w.grad.clone()
  opt = torch.optim.SGD([p], lr=lr, momentum=mu)
  opt.state[p]["momentum_buffer"] = buf.clone()
  opt.step()
  assert torch.allclose(_got[0], p.detach(), atol=1e-6), "weight update must match torch.optim.SGD"
  """],
  hints=["Return new tensors instead of mutating the arguments.",
         "PyTorch's buffer update is `buf = mu*buf + grad` (no dampening)."])

q(topic="torch", diff="hard", tags=["optim", "adam"], title="Adam step, manual",
  ask="Implement one Adam step manually. Inputs: parameter `w` (with `.grad`), moment "
      "estimates `m` and `v`, step number `t` (>= 1), and hyperparameters. "
      "`m' = b1*m + (1-b1)*g`, `v' = b2*v + (1-b2)*g^2`, bias-correct with "
      "`1-b^t`, then `w' = w - lr * m_hat / (sqrt(v_hat) + eps)`. "
      "Return `(new_w, m', v')` without mutating the inputs.",
  sig="solve(w, m, v, t, lr, b1, b2, eps)", sol="""
  g = w.grad
  m2 = b1 * m + (1 - b1) * g
  v2 = b2 * v + (1 - b2) * g * g
  m_hat = m2 / (1 - b1 ** t)
  v_hat = v2 / (1 - b2 ** t)
  return (w - lr * m_hat / (v_hat.sqrt() + eps), m2, v2)
  """,
  mk="""
  w = torch.randn(4, requires_grad=True)
  (w.pow(3).sum()).backward()
  return (w, torch.zeros(4), torch.zeros(4), [1, 5, 100][v], 0.01, 0.9, 0.999, 1e-8)
  """, arg_names=["w", "m", "v", "t", "lr", "b1", "b2", "eps"],
  props=["""
  w, m, v, t, lr, b1, b2, eps = _args
  p = w.detach().clone().requires_grad_(True)
  p.grad = w.grad.clone()
  opt = torch.optim.Adam([p], lr=lr, betas=(b1, b2), eps=eps)
  st = opt.state[p]
  st["step"] = torch.tensor(float(t - 1))
  st["exp_avg"] = m.clone()
  st["exp_avg_sq"] = v.clone()
  opt.step()
  assert torch.allclose(_got[0].detach(), p.detach(), atol=1e-5), "weight must match torch.optim.Adam"
  assert torch.allclose(_got[1], st["exp_avg"], atol=1e-5), "first moment must match"
  assert torch.allclose(_got[2], st["exp_avg_sq"], atol=1e-5), "second moment must match"
  """],
  hints=["Bias correction divides by `1 - beta**t`.",
         "`eps` is added **after** the square root in PyTorch's Adam."])

q(topic="torch", diff="hard", tags=["optim", "adamw"], title="AdamW decoupled weight decay",
  ask="Return `w - lr * (m_hat / (sqrt(v_hat) + eps) + wd * w)` for one step, i.e. Adam "
      "with **decoupled** weight decay (AdamW) applied to the current weights.",
  sig="solve(w, m, v, t, lr, b1, b2, eps, wd)", sol="""
  g = w.grad
  m2 = b1 * m + (1 - b1) * g
  v2 = b2 * v + (1 - b2) * g * g
  m_hat = m2 / (1 - b1 ** t)
  v_hat = v2 / (1 - b2 ** t)
  return w - lr * (m_hat / (v_hat.sqrt() + eps) + wd * w)
  """,
  mk="""
  w = torch.randn(3, requires_grad=True)
  (w.sum()).backward()
  return (w, torch.zeros(3), torch.zeros(3), 1, 0.1, 0.9, 0.999, 1e-8, [0.1, 0.01, 0.5][v])
  """, arg_names=["w", "m", "v", "t", "lr", "b1", "b2", "eps", "wd"],
  props=["""
  w, m, v, t, lr, b1, b2, eps, wd = _args
  p = w.detach().clone().requires_grad_(True)
  p.grad = w.grad.clone()
  opt = torch.optim.AdamW([p], lr=lr, betas=(b1, b2), eps=eps, weight_decay=wd)
  opt.step()
  assert torch.allclose(_got.detach(), p.detach(), atol=1e-5), "should match torch.optim.AdamW"
  """],
  hints=["AdamW decays the weight directly, not through the gradient.",
         "That is why it behaves differently from SGD-style L2."])

q(topic="torch", diff="medium", tags=["optim", "weight-decay"], title="L2 penalty",
  ask="Return the L2 penalty `0.5 * wd * sum(w ** 2)` for the parameters in `params`.",
  sig="solve(params, wd)", sol="""
  total = sum((p ** 2).sum() for p in params)
  return 0.5 * wd * total
  """,
  mk="""
  cases = [([torch.randn(3), torch.randn(2, 2)], 1e-4), ([torch.ones(4)], 0.1), ([torch.zeros(2)], 1.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["params", "wd"],
  hints=["Sum the squared norms of every parameter.",
         "0.5 factor makes the gradient exactly `wd * w`."])

q(topic="torch", diff="medium", tags=["optim", "clip"], title="Clip gradients by norm, manual",
  ask="Implement gradient clipping by global norm: if the total L2 norm of all grads "
      "exceeds `max_norm`, scale every grad by `max_norm / (total + 1e-6)`. Modify the "
      "parameter `.grad` tensors in place and return the original total norm (a 0-dim "
      "tensor).",
  sig="solve(params, max_norm)", sol="""
  total = torch.sqrt(sum((p.grad ** 2).sum() for p in params))
  if total > max_norm:
      scale = max_norm / (total + 1e-6)
      for p in params:
          p.grad.mul_(scale)
  return total
  """,
  mk="""
  ps = [torch.randn(4), torch.randn(3)]
  for p in ps:
      p.grad = torch.randn_like(p) * 10
  return (ps, [1.0, 5.0, 0.5][v])
  """, arg_names=["params", "max_norm"],
  props=["""
  params, max_norm = _args
  total = float(torch.sqrt(sum((p.grad ** 2).sum() for p in params)))
  assert total <= max_norm * 1.001, f"gradients must be clipped (norm {total:.3f} > {max_norm})"
  """],
  hints=["Compute the norm **across** all parameter gradients.",
         "Scaling is applied only when the norm exceeds the threshold."])

q(topic="torch", diff="medium", tags=["optim", "clip"], title="clip_grad_norm_ builtin",
  ask="Use `torch.nn.utils.clip_grad_norm_(params, max_norm)` and return its result (the "
      "total norm before clipping).",
  sig="solve(params, max_norm)", sol="return torch.nn.utils.clip_grad_norm_(params, max_norm)",
  mk="""
  ps = [torch.randn(4), torch.randn(2, 2)]
  for p in ps:
      p.grad = torch.randn_like(p) * 5
  return (ps, [1.0, 2.0, 0.2][v])
  """, arg_names=["params", "max_norm"],
  props=["""
  params, max_norm = _args
  total = float(torch.sqrt(sum((p.grad ** 2).sum() for p in params)))
  assert total <= max_norm * 1.001, f"gradients must be clipped (norm {total:.3f} > {max_norm})"
  """],
  hints=["`clip_grad_norm_` clips in place and returns the pre-clip norm.",
         "Return value is a 0-dim tensor."])

q(topic="torch", diff="easy", tags=["optim", "zero_grad"], title="Zero grads, set_to_none",
  ask="Create the optimizer `SGD([w], lr=0.1)` and call `zero_grad(set_to_none=True)`. "
      "Return `w.grad is None`.",
  sig="solve(w)", sol="""
  opt = torch.optim.SGD([w], lr=0.1)
  opt.zero_grad(set_to_none=True)
  return w.grad is None
  """,
  mk="""
  w = torch.randn(3, requires_grad=True)
  (w.sum()).backward()
  return (w,)
  """, arg_names=["w"], cmp="none",
  props=["assert _got is True"],
  hints=["`set_to_none=True` releases the buffer instead of zeroing it.",
         "That's the default in modern PyTorch."])

q(topic="torch", diff="hard", tags=["optim", "param-groups"], title="Param groups with different lr",
  ask="Build `SGD` with two param groups: `params_a` with `lr=lr_a` and `params_b` with "
      "`lr=lr_b`, then return `[g['lr'] for g in opt.param_groups]`.",
  sig="solve(params_a, params_b, lr_a, lr_b)", sol="""
  opt = torch.optim.SGD([
      {"params": params_a, "lr": lr_a},
      {"params": params_b, "lr": lr_b},
  ])
  return [g["lr"] for g in opt.param_groups]
  """,
  mk="""
  cases = [([torch.randn(2)], [torch.randn(3)], 0.1, 0.01),
           ([torch.randn(1)], [torch.randn(1)], 0.5, 0.5),
           ([torch.randn(2)], [torch.randn(2)], 0.001, 0.1)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["params_a", "params_b", "lr_a", "lr_b"],
  hints=["A param group is a dict with a `params` key plus per-group hyperparameters.",
         "This is how you fine-tune a backbone at a lower learning rate."])

q(topic="torch", diff="medium", tags=["optim", "adagrad"], title="Adagrad step, manual",
  ask="Implement one Adagrad step: accumulate squared gradients in `acc`, then "
      "`w = w - lr * g / (sqrt(acc) + eps)`. Return `(new_w, new_acc)`.",
  sig="solve(w, acc, lr, eps)", sol="""
  g = w.grad
  acc2 = acc + g * g
  return (w - lr * g / (acc2.sqrt() + eps), acc2)
  """,
  mk="""
  w = torch.randn(3, requires_grad=True)
  (w.pow(2).sum()).backward()
  return (w, torch.full((3,), 1e-10), [0.1, 0.01, 1.0][v], 1e-10)
  """, arg_names=["w", "acc", "lr", "eps"],
  props=["""
  w, acc, lr, eps = _args
  p = w.detach().clone().requires_grad_(True)
  p.grad = w.grad.clone()
  opt = torch.optim.Adagrad([p], lr=lr, eps=eps)
  opt.state[p]["sum"] = acc.clone()
  opt.step()
  assert torch.allclose(_got[0].detach(), p.detach(), atol=1e-6), "must match torch.optim.Adagrad"
  """],
  hints=["Adagrad scales each coordinate by the inverse root of its history.",
         "The accumulator only grows, so the effective lr decays."])

q(topic="torch", diff="medium", tags=["optim", "rmsprop"], title="RMSprop step, manual",
  ask="Implement one RMSprop step (no momentum): "
      "`sq = alpha*sq + (1-alpha)*g^2`, `w = w - lr * g / (sqrt(sq) + eps)`. "
      "Return `(new_w, new_sq)`.",
  sig="solve(w, sq, lr, alpha, eps)", sol="""
  g = w.grad
  sq2 = alpha * sq + (1 - alpha) * g * g
  return (w - lr * g / (sq2.sqrt() + eps), sq2)
  """,
  mk="""
  w = torch.randn(4, requires_grad=True)
  (w.pow(2).sum()).backward()
  return (w, torch.ones(4), [0.01, 0.1, 0.001][v], 0.99, 1e-8)
  """, arg_names=["w", "sq", "lr", "alpha", "eps"],
  hints=["RMSprop keeps an exponential moving average of squared gradients.",
         "There is no bias correction — that's Adam's addition."])

# =========================================================================== #
#  Learning-rate schedulers
# =========================================================================== #
q(topic="torch", diff="medium", tags=["scheduler", "step"], title="StepLR schedule",
  ask="`sched` is a `StepLR`. Advance it `steps` times and return the current learning "
      "rate as a float (`sched.get_last_lr()[0]`).",
  sig="solve(sched, steps)", sol="""
  for _ in range(steps):
      sched.step()
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=0.1)
  return (torch.optim.lr_scheduler.StepLR(opt, step_size=3, gamma=0.1), [0, 2, 3, 6, 7][v % 5])
  """, arg_names=["sched", "steps"],
  hints=["StepLR multiplies the lr by `gamma` every `step_size` epochs.",
         "Calling `get_last_lr()` does not advance anything."])

q(topic="torch", diff="medium", tags=["scheduler", "multistep"], title="MultiStepLR schedule",
  ask="Advance the `MultiStepLR` `sched` by `steps` and return the resulting lr.",
  sig="solve(sched, steps)", sol="""
  for _ in range(steps):
      sched.step()
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=1.0)
  return (torch.optim.lr_scheduler.MultiStepLR(opt, milestones=[2, 5], gamma=0.5), [1, 2, 5, 6][v % 4])
  """, arg_names=["sched", "steps"],
  hints=["Milestones are epoch numbers, not intervals.",
         "Each milestone multiplies the lr once."])

q(topic="torch", diff="medium", tags=["scheduler", "exponential"], title="ExponentialLR schedule",
  ask="Advance the `ExponentialLR` `sched` by `steps` and return the lr.",
  sig="solve(sched, steps)", sol="""
  for _ in range(steps):
      sched.step()
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=1.0)
  return (torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.9), [1, 3, 10][v])
  """, arg_names=["sched", "steps"],
  hints=["Each step multiplies the lr by `gamma`.",
         "After `n` steps the lr is `lr0 * gamma**n`."])

q(topic="torch", diff="hard", tags=["scheduler", "cosine"], title="Cosine annealing schedule",
  ask="Advance the `CosineAnnealingLR` `sched` by `steps` and return the lr. It should "
      "follow `eta_min + (lr0 - eta_min) * (1 + cos(pi * t / T_max)) / 2`.",
  sig="solve(sched, steps)", sol="""
  for _ in range(steps):
      sched.step()
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=1.0)
  return (torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=10, eta_min=0.0), [0, 5, 10][v])
  """, arg_names=["sched", "steps"],
  hints=["At `t = 0` the lr is the initial value; at `t = T_max` it is `eta_min`.",
         "The schedule follows a half cosine wave."])

q(topic="torch", diff="hard", tags=["scheduler", "warmup"], title="Linear warmup schedule",
  ask="`LinearLR` with `start_factor=0.01`, `total_iters=10`. Advance `steps` times and "
      "return the lr.",
  sig="solve(sched, steps)", sol="""
  for _ in range(steps):
      sched.step()
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=1.0)
  return (torch.optim.lr_scheduler.LinearLR(opt, start_factor=0.01, total_iters=10), [0, 5, 20][v])
  """, arg_names=["sched", "steps"],
  hints=["The multiplier grows linearly from `start_factor` to 1.",
         "After `total_iters` the base lr is used."])

q(topic="torch", diff="hard", tags=["scheduler", "plateau"], title="ReduceLROnPlateau",
  ask="`sched` is a `ReduceLROnPlateau(mode='min', factor=0.5, patience=0)`. Feed it the "
      "`metrics` one by one with `sched.step(metric)` and return the final lr.",
  sig="solve(sched, metrics)", sol="""
  for m in metrics:
      sched.step(m)
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=1.0)
  sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5, patience=0)
  return (sched, [[1.0, 2.0, 3.0], [1.0, 1.0, 1.0], [3.0, 2.0, 0.5]][v])
  """, arg_names=["sched", "metrics"],
  hints=["The lr drops when the metric stops improving.",
         "`patience=0` reacts immediately."])

q(topic="torch", diff="medium", tags=["scheduler", "lambda"], title="LambdaLR schedule",
  ask="`sched` is a `LambdaLR` with the function `lambda e: 1 / (e + 1)`. Advance `steps` "
      "times and return the lr.",
  sig="solve(sched, steps)", sol="""
  for _ in range(steps):
      sched.step()
  return sched.get_last_lr()[0]
  """,
  mk="""
  p = torch.nn.Parameter(torch.zeros(1))
  opt = torch.optim.SGD([p], lr=0.5)
  sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda e: 1.0 / (e + 1))
  return (sched, [0, 1, 4][v])
  """, arg_names=["sched", "steps"],
  hints=["The multiplier is recomputed from the epoch counter.",
         "After `n` steps the multiplier is `1/(n+1)`."])

# =========================================================================== #
#  Training loops
# =========================================================================== #
q(topic="torch", diff="hard", tags=["training", "regression"], title="Fit a linear regression",
  ask="`X` (n, d) and `y` (n,) follow `y ≈ X @ w_true + b_true`. Train a single "
      "`nn.Linear(d, 1)` with SGD for at least 200 steps to reach a small MSE, then "
      "return the final training MSE as a 0-dim tensor.",
  sig="solve(X, y)", sol="""
  model = nn.Linear(X.shape[1], 1)
  opt = torch.optim.SGD(model.parameters(), lr=0.1)
  loss_fn = nn.MSELoss()
  for _ in range(300):
      opt.zero_grad()
      loss = loss_fn(model(X).squeeze(-1), y)
      loss.backward()
      opt.step()
  return loss.detach()
  """,
  mk="""
  X = torch.randn(64, 3)
  w = torch.tensor([2.0, -1.0, 0.5])
  y = X @ w + 0.5
  return (X, y)
  """, arg_names=["X", "y"], imports=NN, cmp="none",
  props=["""
  assert _got.ndim == 0, "return the scalar loss"
  assert float(_got) < 0.05, f"final MSE {float(_got):.4f} is too high - train longer or raise the lr"
  """],
  hints=["Use `MSELoss` on `model(X).squeeze(-1)`.",
         "300 full-batch steps with lr=0.1 converge comfortably."])

q(topic="torch", diff="hard", tags=["training", "closed-form"], title="Least squares in closed form",
  ask="Solve ordinary least squares directly: return `(w, b)` for the model `y ≈ X w + b`. "
      "Use `torch.linalg.lstsq` on an augmented matrix, not gradient descent.",
  sig="solve(X, y)", sol="""
  A = torch.cat([X, torch.ones(X.shape[0], 1)], dim=1)
  sol = torch.linalg.lstsq(A, y).solution
  return (sol[:-1], sol[-1])
  """,
  mk="""
  X = torch.randn(50, 3)
  w = torch.tensor([1.0, -2.0, 0.25])
  y = X @ w + 1.5
  return (X, y)
  """, arg_names=["X", "y"], cmp="none",
  props=["""
  X, y = _args
  A = torch.cat([X, torch.ones(X.shape[0], 1)], 1)
  sol = torch.linalg.lstsq(A, y).solution
  assert torch.allclose(_got[0], sol[:-1], atol=1e-3), "weights should match least squares"
  assert torch.allclose(_got[1], sol[-1], atol=1e-3), "bias should match least squares"
  """],
  hints=["Append a column of ones to model the bias.",
         "`torch.linalg.lstsq(A, y).solution` is the exact minimiser."])

q(topic="torch", diff="hard", tags=["training", "logistic"], title="Train a logistic regression",
  ask="`X` (n, 2), `y` (n,) in {0,1}. Train `nn.Linear(2, 1)` with "
      "`F.binary_cross_entropy_with_logits` (SGD or Adam, ≥200 steps) and return the "
      "training accuracy as a float.",
  sig="solve(X, y)", sol="""
  model = nn.Linear(2, 1)
  opt = torch.optim.Adam(model.parameters(), lr=0.1)
  for _ in range(300):
      opt.zero_grad()
      loss = F.binary_cross_entropy_with_logits(model(X).squeeze(-1), y)
      loss.backward()
      opt.step()
  preds = (model(X).squeeze(-1) > 0).float()
  return float((preds == y).float().mean())
  """,
  mk="""
  n = 100
  X = torch.randn(n, 2) + 1.5
  y = torch.where(X[:, 0] + X[:, 1] > 3.0, 1.0, 0.0)
  return (X, y)
  """, arg_names=["X", "y"], imports=NN, cmp="none",
  props=["assert _got >= 0.9, f'accuracy {float(_got):.3f} is too low - train more steps'"],
  hints=["Compute logits, then `BCEWithLogitsLoss` (no sigmoid needed).",
         "Threshold the logits at 0 to get predictions."])

q(topic="torch", diff="hard", tags=["training", "xor"], title="Solve XOR with an MLP",
  ask="Train a small MLP on the four XOR examples until it fits them, then return the "
      "accuracy on those four points (a float).",
  sig="solve(X, y)", sol="""
  model = nn.Sequential(nn.Linear(2, 8), nn.ReLU(), nn.Linear(8, 1))
  opt = torch.optim.Adam(model.parameters(), lr=0.05)
  for _ in range(800):
      opt.zero_grad()
      loss = F.binary_cross_entropy_with_logits(model(X).squeeze(-1), y)
      loss.backward()
      opt.step()
  preds = (model(X).squeeze(-1) > 0).float()
  return float((preds == y).float().mean())
  """,
  mk="""
  X = torch.tensor([[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]])
  y = torch.tensor([0.0, 1.0, 1.0, 0.0])
  return (X, y)
  """, arg_names=["X", "y"], imports=NN, cmp="none",
  props=["assert _got >= 0.99, 'XOR needs a hidden layer - a single linear model cannot fit it'"],
  hints=["XOR is not linearly separable — you need a hidden layer.",
         "Adam with lr=0.05 for ~800 steps fits it reliably."])

q(topic="torch", diff="hard", tags=["training", "poly"], title="Fit a quadratic",
  ask="`x` (n,) and `y` follow `y ≈ 3x^2 - 2x + 1`. Fit a polynomial of degree 2 by "
      "building the feature matrix `[x^2, x, 1]` and running least squares; return the "
      "coefficient vector of length 3.",
  sig="solve(x, y)", sol="""
  A = torch.stack([x ** 2, x, torch.ones_like(x)], dim=1)
  return torch.linalg.lstsq(A, y).solution
  """,
  mk="""
  x = torch.linspace(-2, 2, 50)
  y = 3 * x ** 2 - 2 * x + 1
  return (x, y)
  """, arg_names=["x", "y"],
  props=["assert torch.allclose(_got, torch.tensor([3.0, -2.0, 1.0]), atol=1e-3)"],
  hints=["Stack the monomials as columns.",
         "`lstsq` recovers the coefficients exactly for noise-free data."])

q(topic="torch", diff="hard", tags=["training", "epochs"], title="Count the epochs to a target loss",
  ask="Train `nn.Linear(1, 1)` on the given data with SGD (lr=0.1) and return the number "
      "of steps needed for the MSE to fall below `target` (an int). Stop as soon as it "
      "does.",
  sig="solve(x, y, target)", sol="""
  model = nn.Linear(1, 1)
  opt = torch.optim.SGD(model.parameters(), lr=0.1)
  loss_fn = nn.MSELoss()
  steps = 0
  while steps < 5000:
      opt.zero_grad()
      loss = loss_fn(model(x).squeeze(-1), y)
      loss.backward()
      opt.step()
      steps += 1
      if loss.item() < target:
          break
  return steps
  """,
  mk="""
  x = torch.randn(32, 1)
  y = 2.0 * x + 0.3
  return (x, y.squeeze(-1), [0.1, 0.01, 0.5][v])
  """, arg_names=["x", "y", "target"], imports=NN, cmp="none",
  props=["assert isinstance(_got, int) and 0 < _got <= 5000, 'return the step count'"],
  hints=["Check the loss **after** each update.",
         "A smaller target needs more steps."])

q(topic="torch", diff="hard", tags=["training", "early-stopping"], title="Early stopping",
  ask="`X_train`/`y_train` and `X_val`/`y_val` are given. Train a linear model and return "
      "the **best validation MSE** seen, keeping the weights from the best epoch "
      "(patience `patience` epochs without improvement stops training).",
  sig="solve(X_train, y_train, X_val, y_val, patience)", sol="""
  model = nn.Linear(X_train.shape[1], 1)
  opt = torch.optim.SGD(model.parameters(), lr=0.05)
  loss_fn = nn.MSELoss()
  best, best_state, bad = float("inf"), None, 0
  for _ in range(500):
      opt.zero_grad()
      loss = loss_fn(model(X_train).squeeze(-1), y_train)
      loss.backward()
      opt.step()
      with torch.no_grad():
          val = float(loss_fn(model(X_val).squeeze(-1), y_val))
      if val < best - 1e-8:
          best, bad = val, 0
          best_state = {k: v.clone() for k, v in model.state_dict().items()}
      else:
          bad += 1
          if bad >= patience:
              break
  model.load_state_dict(best_state)
  return best
  """,
  mk="""
  X = torch.randn(64, 2)
  y = X @ torch.tensor([1.0, -1.0]) + 0.2
  return (X[:48], y[:48], X[48:], y[48:], [5, 2, 10][v])
  """, arg_names=["X_train", "y_train", "X_val", "y_val", "patience"], imports=NN, cmp="none",
  props=["assert float(_got) < 0.2, 'best validation loss should be small for this data'"],
  hints=["Track the best validation loss and a patience counter.",
         "Return the best value, not the last one."])

q(topic="torch", diff="hard", tags=["training", "minibatch"], title="Minibatch loop with DataLoader",
  ask="Wrap `X`/`y` in a `TensorDataset`, iterate `DataLoader(dataset, batch_size=bs, "
      "shuffle=False)` for one epoch, train `nn.Linear` for `epochs` epochs and return "
      "the final full-batch MSE.",
  sig="solve(X, y, bs, epochs)", sol="""
  ds = torch.utils.data.TensorDataset(X, y)
  model = nn.Linear(X.shape[1], 1)
  opt = torch.optim.SGD(model.parameters(), lr=0.05)
  loss_fn = nn.MSELoss()
  for _ in range(epochs):
      for xb, yb in torch.utils.data.DataLoader(ds, batch_size=bs, shuffle=False):
          opt.zero_grad()
          loss = loss_fn(model(xb).squeeze(-1), yb)
          loss.backward()
          opt.step()
  with torch.no_grad():
      return loss_fn(model(X).squeeze(-1), y)
  """,
  mk="""
  X = torch.randn(40, 2)
  y = X @ torch.tensor([1.5, -0.5])
  return (X, y, [8, 4, 16][v], 20)
  """, arg_names=["X", "y", "bs", "epochs"], imports=NN, cmp="none",
  props=["assert float(_got) < 0.05, 'train enough epochs to fit a linear target'"],
  hints=["`DataLoader` yields `(xb, yb)` batches.",
         "`shuffle=False` keeps the run reproducible."])

q(topic="torch", diff="hard", tags=["training", "grad-accum"], title="Gradient accumulation equals a big batch",
  ask="Compute the gradient of the sum of the two losses "
      "`MSE(W @ x1, y1) + MSE(W @ x2, y2)` by calling `backward()` twice (micro-batching) "
      "and return `W.grad`. Property checks compare it with a single backward on the "
      "combined loss.",
  sig="solve(W, x1, y1, x2, y2)", sol="""
  loss1 = F.mse_loss(W @ x1, y1, reduction="sum") / (x1.shape[0] + x2.shape[0])
  loss2 = F.mse_loss(W @ x2, y2, reduction="sum") / (x1.shape[0] + x2.shape[0])
  loss1.backward()
  loss2.backward()
  return W.grad
  """,
  mk="""
  W = torch.randn(3, 4, requires_grad=True)
  return (W, torch.randn(4, 5), torch.randn(3, 5), torch.randn(4, 7), torch.randn(3, 7))
  """, arg_names=["W", "x1", "y1", "x2", "y2"], imports=NN,
  props=["""
  W, x1, y1, x2, y2 = _args
  n = x1.shape[0] + x2.shape[0]
  loss = (F.mse_loss(W @ x1, y1, reduction="sum") + F.mse_loss(W @ x2, y2, reduction="sum")) / n
  g, = torch.autograd.grad(loss, W)
  assert torch.allclose(_got, g, atol=1e-5), "accumulated grad should equal the full-batch grad"
  """],
  hints=["Gradients accumulate across `backward()` calls automatically.",
         "Divide by the **total** batch size in both micro-losses."])

q(topic="torch", diff="hard", tags=["training", "autograd-off"], title="Evaluation without gradients",
  ask="Run the model `model` on `X` inside `torch.no_grad()` (or `inference_mode`) and "
      "return `(predictions, predictions.requires_grad)`.",
  sig="solve(model, X)", sol="""
  with torch.no_grad():
      preds = model(X)
  return (preds, preds.requires_grad)
  """,
  mk="""
  model = nn.Sequential(nn.Linear(4, 8), nn.ReLU(), nn.Linear(8, 2))
  return (model, torch.randn(6, 4))
  """, arg_names=["model", "X"], imports=NN,
  hints=["No graph is built inside `no_grad`, so memory stays flat.",
         "The returned flag must be `False`."])

q(topic="torch", diff="hard", tags=["training", "overfit"], title="Overfit one batch",
  ask="Train any model on the single batch `(X, y)` until the MSE drops below `target`, "
      "then return the final loss (0-dim tensor). This checks that your training loop "
      "actually learns.",
  sig="solve(X, y, target)", sol="""
  model = nn.Sequential(nn.Linear(X.shape[1], 16), nn.ReLU(), nn.Linear(16, 1))
  opt = torch.optim.Adam(model.parameters(), lr=0.05)
  loss_fn = nn.MSELoss()
  for _ in range(3000):
      opt.zero_grad()
      loss = loss_fn(model(X).squeeze(-1), y)
      loss.backward()
      opt.step()
      if loss.item() < target:
          break
  return loss.detach()
  """,
  mk="""
  X = torch.randn(8, 3)
  y = torch.randn(8)
  return (X, y, [0.05, 0.01, 0.02][v])
  """, arg_names=["X", "y", "target"], imports=NN, cmp="none",
  props=["assert float(_got) <= float(_args[2]) + 1e-4, 'loss should reach the target'"],
  hints=["A small network can memorise 8 points.",
         "Stop as soon as the target is reached."])

q(topic="torch", diff="hard", tags=["training", "weight-matching"], title="Train to a known weight",
  ask="Linear data generated by `y = X @ w_true`. Train `nn.Linear` with enough steps "
      "that its weight row matches `w_true` within 1e-2, and return the learned weight "
      "as a 1-D tensor.",
  sig="solve(X, y)", sol="""
  model = nn.Linear(X.shape[1], 1)
  opt = torch.optim.Adam(model.parameters(), lr=0.05)
  for _ in range(600):
      opt.zero_grad()
      F.mse_loss(model(X).squeeze(-1), y).backward()
      opt.step()
  return model.weight.detach().squeeze(0)
  """,
  mk="""
  X = torch.randn(200, 3)
  w = torch.tensor([1.0, 2.0, -0.5])
  y = X @ w
  return (X, y)
  """, arg_names=["X", "y"], imports=NN, cmp="none",
  props=["""
  X, y = _args
  w_true = torch.linalg.lstsq(X, y).solution
  assert torch.allclose(_got, w_true, atol=1e-2), "learned weight should match the data-generating weight"
  """],
  hints=["With 200 samples the least-squares solution is well determined.",
         "Return the weight as a 1-D tensor."])

# =========================================================================== #
#  Metrics
# =========================================================================== #
q(topic="torch", diff="easy", tags=["metrics", "accuracy"], title="Classification accuracy",
  ask="`logits` (n, c) and integer `labels` (n,). Return the accuracy as a float.",
  sig="solve(logits, labels)", sol="return float((logits.argmax(dim=1) == labels).float().mean())",
  mk="""
  cases = [(torch.randn(8, 3), torch.randint(0, 3, (8,))),
           (torch.eye(4), torch.tensor([0, 1, 2, 0])),
           (torch.randn(5, 2), torch.tensor([0, 0, 1, 1, 0]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "labels"],
  props=["assert 0.0 <= _got <= 1.0"],
  hints=["Take the argmax over the class dimension.",
         "Compare with the integer labels and take the mean."])

q(topic="torch", diff="medium", tags=["metrics", "topk"], title="Top-k accuracy",
  ask="Return the fraction of samples whose true label is inside the top-`k` predictions "
      "of `logits`.",
  sig="solve(logits, labels, k)", sol="""
  topk = logits.topk(k, dim=1).indices
  hit = (topk == labels.unsqueeze(1)).any(dim=1)
  return float(hit.float().mean())
  """,
  mk="""
  cases = [(torch.randn(10, 5), torch.randint(0, 5, (10,)), 3),
           (torch.randn(6, 3), torch.randint(0, 3, (6,)), 1),
           (torch.randn(4, 8), torch.randint(0, 8, (4,)), 5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "labels", "k"],
  hints=["`topk(k, dim=1).indices` gives the k best classes.",
         "Broadcast the labels and use `.any(dim=1)`."])

q(topic="torch", diff="medium", tags=["metrics", "confusion"], title="Confusion matrix",
  ask="Build the `(c, c)` confusion matrix for integer `preds` and `targets` (rows = true "
      "class, columns = predicted), as an int64 tensor.",
  sig="solve(preds, targets, c)", sol="""
  idx = targets * c + preds
  return torch.bincount(idx, minlength=c * c).reshape(c, c)
  """,
  mk="""
  cases = [(torch.tensor([0, 1, 2, 0]), torch.tensor([0, 1, 1, 0]), 3),
           (torch.tensor([1, 1, 0]), torch.tensor([1, 0, 0]), 2),
           (torch.tensor([2, 2]), torch.tensor([2, 2]), 3)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["preds", "targets", "c"],
  hints=["`bincount` on `target * c + pred` fills the matrix in one pass.",
         "`minlength=c*c` keeps zero classes in the matrix."])

q(topic="torch", diff="medium", tags=["metrics", "precision"], title="Precision, recall, F1",
  ask="Binary predictions `preds` and `targets` (0/1 tensors). Return "
      "`(precision, recall, f1)` as floats, guarding against division by zero with "
      "`eps=1e-8`.",
  sig="solve(preds, targets)", sol="""
  tp = float(((preds == 1) & (targets == 1)).sum())
  fp = float(((preds == 1) & (targets == 0)).sum())
  fn = float(((preds == 0) & (targets == 1)).sum())
  precision = tp / (tp + fp + 1e-8)
  recall = tp / (tp + fn + 1e-8)
  f1 = 2 * precision * recall / (precision + recall + 1e-8)
  return (precision, recall, f1)
  """,
  mk="""
  cases = [(torch.tensor([1, 1, 0, 0, 1]), torch.tensor([1, 0, 0, 1, 1])),
           (torch.ones(4), torch.ones(4)),
           (torch.zeros(3), torch.ones(3))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["preds", "targets"],
  hints=["Count true positives, false positives and false negatives.",
         "F1 is the harmonic mean of precision and recall."])

q(topic="torch", diff="hard", tags=["metrics", "f1"], title="Macro F1",
  ask="`logits` (n, c) and integer `targets` (n,). Return the **macro** F1: compute F1 "
      "per class, then average over all `c` classes (zero-division guarded with 1e-8).",
  sig="solve(logits, targets, c)", sol="""
  preds = logits.argmax(dim=1)
  f1s = []
  for k in range(c):
      tp = float(((preds == k) & (targets == k)).sum())
      fp = float(((preds == k) & (targets != k)).sum())
      fn = float(((preds != k) & (targets == k)).sum())
      p = tp / (tp + fp + 1e-8)
      r = tp / (tp + fn + 1e-8)
      f1s.append(2 * p * r / (p + r + 1e-8))
  return sum(f1s) / c
  """,
  mk="""
  cases = [(torch.randn(20, 3), torch.randint(0, 3, (20,)), 3),
           (torch.randn(10, 2), torch.randint(0, 2, (10,)), 2),
           (torch.eye(4), torch.tensor([0, 1, 2, 3]), 4)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets", "c"],
  hints=["Macro averaging weights every class equally, even rare ones.",
         "A perfect prediction on `torch.eye` gives 1.0."])

q(topic="torch", diff="medium", tags=["metrics", "iou"], title="IoU for binary masks",
  ask="`pred` and `target` are binary float tensors. Return the intersection-over-union "
      "as a float (`0` if the union is empty).",
  sig="solve(pred, target)", sol="""
  inter = float(((pred > 0) & (target > 0)).sum())
  union = float(((pred > 0) | (target > 0)).sum())
  return 0.0 if union == 0 else inter / union
  """,
  mk="""
  cases = [(torch.tensor([1.0, 1.0, 0.0, 0.0]), torch.tensor([1.0, 0.0, 0.0, 0.0])),
           (torch.ones(3), torch.zeros(3)),
           (torch.ones(3), torch.ones(3))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["pred", "target"],
  hints=["Union = |pred ∪ target|, intersection = |pred ∩ target|.",
         "Guard the empty-union edge case."])

q(topic="torch", diff="medium", tags=["metrics", "mse"], title="RMSE",
  ask="Return the root mean squared error between `p` and `t` as a 0-dim tensor.",
  sig="solve(p, t)", sol="return torch.sqrt(((p - t) ** 2).mean())",
  mk="""
  cases = [(torch.randn(4, 3), torch.randn(4, 3)), (torch.zeros(3), torch.ones(3)), (torch.randn(5), torch.randn(5))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t"],
  props=["assert torch.allclose(_got, torch.sqrt(torch.nn.functional.mse_loss(_args[0], _args[1])))"],
  hints=["RMSE is the square root of MSE.",
         "Same units as the target variable."])

q(topic="torch", diff="medium", tags=["metrics", "r2"], title="R² score",
  ask="Return the coefficient of determination `1 - SS_res / SS_tot` for predictions `p` "
      "and targets `t`, as a float. If `SS_tot` is zero (constant targets), return `1.0` "
      "when the predictions are exact and `0.0` otherwise.",
  sig="solve(p, t)", sol="""
  ss_res = float(((t - p) ** 2).sum())
  ss_tot = float(((t - t.mean()) ** 2).sum())
  if ss_tot == 0.0:
      return 1.0 if ss_res == 0.0 else 0.0
  return 1.0 - ss_res / ss_tot
  """,
  mk="""
  cases = [(torch.randn(10), torch.randn(10)), (torch.ones(5), torch.ones(5)), (torch.zeros(4), torch.ones(4))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p", "t"],
  hints=["SS_tot uses the mean of the targets.",
         "Perfect predictions give R² = 1."])

q(topic="torch", diff="medium", tags=["metrics", "cosine"], title="Cosine similarity matrix",
  ask="Return the `(n, m)` matrix of cosine similarities between the rows of `a` and `b`.",
  sig="solve(a, b)", sol="""
  a_n = F.normalize(a, dim=1)
  b_n = F.normalize(b, dim=1)
  return a_n @ b_n.t()
  """,
  mk="""
  cases = [(torch.randn(3, 5), torch.randn(4, 5)), (torch.ones(2, 3), torch.ones(2, 3)),
           (torch.randn(1, 2), torch.randn(3, 2))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"], imports=NN,
  props=["assert _got.shape == (_args[0].shape[0], _args[1].shape[0])"],
  hints=["Normalise both matrices, then take the outer product of unit vectors.",
         "The diagonal of `cos(a, a)` is all ones."])

q(topic="torch", diff="medium", tags=["metrics", "perplexity"], title="Perplexity from logits",
  ask="`logits` (n, c) and integer `targets` (n,). Return the perplexity "
      "`exp(cross_entropy)` as a float.",
  sig="solve(logits, targets)", sol="""
  return float(torch.exp(F.cross_entropy(logits, targets)))
  """,
  mk="""
  cases = [(torch.randn(6, 4), torch.randint(0, 4, (6,))),
           (torch.zeros(5, 3), torch.randint(0, 3, (5,))),
           (torch.randn(2, 10) * 3, torch.tensor([1, 8]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "targets"], imports=NN,
  props=["assert _got >= 1.0 - 1e-6, 'perplexity is at least 1'"],
  hints=["Uniform logits over c classes give perplexity c.",
         "Perplexity is a monotone transform of the loss."])

# =========================================================================== #
#  Attention & transformer building blocks
# =========================================================================== #
q(topic="torch", diff="medium", tags=["attention"], title="Scaled dot-product attention",
  ask="Implement single-head attention: `softmax(Q @ K.T / sqrt(d_k)) @ V` along the last "
      "dimension of the scores. `Q` is (n, d_k), `K` is (m, d_k), `V` is (m, d_v).",
  sig="solve(Q, K, V)", sol="""
  d_k = Q.shape[-1]
  scores = Q @ K.transpose(-2, -1) / (d_k ** 0.5)
  weights = torch.softmax(scores, dim=-1)
  return weights @ V
  """,
  mk="""
  cases = [(torch.randn(4, 8), torch.randn(6, 8), torch.randn(6, 5)),
           (torch.randn(1, 2), torch.randn(1, 2), torch.randn(1, 3)),
           (torch.randn(5, 4), torch.randn(5, 4), torch.randn(5, 4))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["Q", "K", "V"],
  props=["""
  Q, K, V = _args
  ref = F.scaled_dot_product_attention(Q, K, V)
  assert torch.allclose(_got, ref, atol=1e-5), "should match F.scaled_dot_product_attention"
  """],
  hints=["Scale by `1/sqrt(d_k)` before the softmax to keep logits small.",
         "`@ V` mixes the values with the attention weights."])

q(topic="torch", diff="hard", tags=["attention", "causal"], title="Causal attention",
  ask="Add a causal mask to scaled dot-product attention: position `i` may only attend "
      "to `j <= i`. Implement the scores with `-inf` above the diagonal, then softmax "
      "and multiply by `V`. `Q`, `K`, `V` are all (t, d).",
  sig="solve(Q, K, V)", sol="""
  t = Q.shape[0]
  scores = Q @ K.transpose(-2, -1) / (Q.shape[-1] ** 0.5)
  mask = torch.triu(torch.full((t, t), float("-inf")), diagonal=1)
  weights = torch.softmax(scores + mask, dim=-1)
  return weights @ V
  """,
  mk="""
  cases = [(torch.randn(4, 8), torch.randn(4, 8), torch.randn(4, 6)),
           (torch.randn(1, 3), torch.randn(1, 3), torch.randn(1, 3)),
           (torch.randn(6, 4), torch.randn(6, 4), torch.randn(6, 2))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["Q", "K", "V"],
  props=["""
  Q = _args[0]
  t = Q.shape[0]
  # first output position can only see position 0 -> equals V[0]
  assert torch.allclose(_got[0], _args[2][0], atol=1e-5), "row 0 must only attend to token 0"
  """],
  hints=["`torch.triu(..., diagonal=1)` produces the forbidden region.",
         "Adding `-inf` makes those softmax weights exactly zero."])

q(topic="torch", diff="hard", tags=["attention", "padding"], title="Attention with a padding mask",
  ask="`mask` is a boolean tensor of shape `(m,)` where `True` marks **valid** keys. "
      "Implement attention where padded keys get `-inf` scores (so they receive zero "
      "weight). Return the attended output (n, d_v).",
  sig="solve(Q, K, V, mask)", sol="""
  scores = Q @ K.transpose(-2, -1) / (Q.shape[-1] ** 0.5)
  scores = scores.masked_fill(~mask.unsqueeze(0), float("-inf"))
  weights = torch.softmax(scores, dim=-1)
  return weights @ V
  """,
  mk="""
  cases = [(torch.randn(3, 4), torch.randn(5, 4), torch.randn(5, 6),
            torch.tensor([True, True, False, False, True])),
           (torch.randn(2, 6), torch.randn(4, 6), torch.randn(4, 2),
            torch.tensor([True, False, True, True])),
           (torch.randn(1, 3), torch.randn(3, 3), torch.randn(3, 3),
            torch.ones(3, dtype=torch.bool))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["Q", "K", "V", "mask"],
  props=["""
  Q, K, V, m = _args
  scores = (Q @ K.transpose(-2, -1) / (Q.shape[-1] ** 0.5)).masked_fill(~m.unsqueeze(0), float("-inf"))
  alt = torch.softmax(scores, dim=-1) @ V
  assert torch.allclose(_got, alt, atol=1e-5), "padding mask must be applied to the scores"
  if (~m).any():
      V2 = V.clone(); V2[~m] = 1e6
      alt2 = torch.softmax(scores, dim=-1) @ V2
      assert torch.allclose(_got, alt2, atol=1e-3), "padded keys must be ignored"
  """],
  hints=["`masked_fill` with the *negated* mask hides padded positions.",
         "Broadcast the mask over the query dimension."])

q(topic="torch", diff="hard", tags=["attention", "multihead"], title="Split into attention heads",
  ask="`x` is (batch, seq, dim). Split it into `heads` heads and return the tensor of "
      "shape (batch, heads, seq, dim // heads) using `view`/`transpose`.",
  sig="solve(x, heads)", sol="""
  b, t, d = x.shape
  h = heads
  return x.view(b, t, h, d // h).transpose(1, 2)
  """,
  mk="""
  cases = [(torch.randn(2, 5, 8), 4), (torch.randn(1, 3, 6), 3), (torch.randn(4, 7, 12), 2)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "heads"],
  props=["""
  b, t, d = _args[0].shape
  h = _args[1]
  assert _got.shape == (b, h, t, d // h)
  back = _got.transpose(1, 2).reshape(b, t, d)
  assert torch.allclose(back, _args[0]), "split must be reversible"
  """],
  hints=["Split the feature dim into `(heads, head_dim)` with `view`.",
         "`transpose(1, 2)` moves the head axis next to the batch axis."])

q(topic="torch", diff="hard", tags=["attention", "multihead"], title="Merge attention heads",
  ask="`x` is (batch, heads, seq, head_dim). Merge the heads back into "
      "`(batch, seq, heads * head_dim)` with `transpose` + `reshape` (contiguity may "
      "matter!).",
  sig="solve(x)", sol="""
  b, h, t, d = x.shape
  return x.transpose(1, 2).reshape(b, t, h * d)
  """,
  mk="""
  cases = [(torch.randn(2, 4, 5, 2),), (torch.randn(1, 3, 4, 8),), (torch.randn(3, 2, 2, 1),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`reshape` silently copies when the tensor is not contiguous.",
         "Inverse of the split operation."])

q(topic="torch", diff="hard", tags=["attention", "multihead"], title="Multi-head attention",
  ask="Full multi-head attention: project `x` (b, t, d) with `wq`, `wk`, `wv` "
      "(shape (d, d)), split into `heads`, run scaled dot-product attention per head, "
      "merge back and project with `wo` (d, d). Return the output (b, t, d).",
  sig="solve(x, wq, wk, wv, wo, heads)", sol="""
  b, t, d = x.shape
  h = heads
  q = (x @ wq).view(b, t, h, d // h).transpose(1, 2)
  k = (x @ wk).view(b, t, h, d // h).transpose(1, 2)
  v = (x @ wv).view(b, t, h, d // h).transpose(1, 2)
  scores = q @ k.transpose(-2, -1) / ((d // h) ** 0.5)
  att = torch.softmax(scores, dim=-1) @ v
  att = att.transpose(1, 2).reshape(b, t, d)
  return att @ wo
  """,
  mk="""
  d = [8, 6, 12][v]
  return (torch.randn(2, 5, d), torch.randn(d, d), torch.randn(d, d), torch.randn(d, d),
          torch.randn(d, d), [2, 3, 4][v])
  """, arg_names=["x", "wq", "wk", "wv", "wo", "heads"],
  hints=["Project first, then split into heads — order matters for shapes.",
         "Scale by `sqrt(head_dim)`, not `sqrt(d)`."])

q(topic="torch", diff="hard", tags=["transformer", "positional"], title="Sinusoidal positional encoding",
  ask="Build the classic Transformer positional encoding of shape `(seq, dim)` "
      "(even indices use sin, odd use cos) with "
      "`div_term = exp(arange(0, dim, 2) * -(log(10000) / dim))`.",
  sig="solve(seq, dim)", imports="import torch\nimport math\n", sol="""
  position = torch.arange(seq).unsqueeze(1).float()
  div_term = torch.exp(torch.arange(0, dim, 2).float() * (-math.log(10000.0) / dim))
  pe = torch.zeros(seq, dim)
  pe[:, 0::2] = torch.sin(position * div_term)
  pe[:, 1::2] = torch.cos(position * div_term)
  return pe
  """,
  mk="""
  cases = [(4, 8), (1, 2), (10, 6), (3, 4)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["seq", "dim"],
  props=["""
  seq, dim = _args
  assert _got.shape == (seq, dim)
  assert torch.allclose(_got[0, 0::2], torch.zeros(dim // 2), atol=1e-6), "position 0 has sin(0)=0"
  assert torch.allclose(_got[0, 1::2], torch.ones(dim // 2), atol=1e-6), "position 0 has cos(0)=1"
  assert (_got.abs() <= 1.0 + 1e-6).all(), "sines and cosines stay in [-1, 1]"
  """],
  hints=["`position` is a column vector, `div_term` a row vector.",
         "Fill even columns with sin and odd columns with cos."])

q(topic="torch", diff="medium", tags=["transformer", "rmsnorm"], title="RMSNorm",
  ask="Implement RMSNorm: `x / sqrt(mean(x^2, dim=-1, keepdim=True) + eps) * gamma`.",
  sig="solve(x, gamma, eps)", sol="""
  rms = x.pow(2).mean(dim=-1, keepdim=True).add(eps).sqrt()
  return x / rms * gamma
  """,
  mk="""
  cases = [(torch.randn(4, 8), torch.randn(8), 1e-6),
           (torch.randn(2, 3, 6), torch.ones(6), 1e-5),
           (torch.randn(5, 4) * 3, torch.rand(4) + 0.5, 1e-8)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "gamma", "eps"],
  props=["""
  x, gamma, eps = _args
  rms = x.pow(2).mean(dim=-1, keepdim=True).add(eps).sqrt()
  assert torch.allclose(_got, x / rms * gamma, atol=1e-6)
  assert (_got * (_args[1] / _args[1])).shape == x.shape
  """],
  hints=["RMSNorm skips mean-centering and only divides by the root mean square.",
         "`gamma` scales each feature."])

q(topic="torch", diff="hard", tags=["transformer", "ffn"], title="Position-wise FFN",
  ask="Apply the transformer feed-forward block to `x` (b, t, d): "
      "`linear2(gelu(linear1(x)))` with `w1` (4d, d), `b1` (4d,), `w2` (d, 4d), `b2` (d,).",
  sig="solve(x, w1, b1, w2, b2)", sol="""
  h = F.gelu(x @ w1.t() + b1)
  return h @ w2.t() + b2
  """,
  mk="""
  d = [8, 4, 6][v]
  return (torch.randn(2, 3, d), torch.randn(4 * d, d), torch.randn(4 * d),
          torch.randn(d, 4 * d), torch.randn(d))
  """, arg_names=["x", "w1", "b1", "w2", "b2"], imports=NN,
  hints=["The hidden dimension is 4x the model dimension.",
         "GELU goes between the two projections."])

q(topic="torch", diff="hard", tags=["transformer", "block"], title="Pre-LN transformer block",
  ask="Implement a pre-LN transformer block with single-head attention: "
      "`h = x + attn(ln1(x))`, `out = h + ffn(ln2(h))`. "
      "`ln1`/`ln2` are `nn.LayerNorm` instances, `attn` is the given 4-tuple "
      "`(wq, wk, wv, wo)` and `w1, b1, w2, b2` parametrise the FFN. Return the block output.",
  sig="solve(x, ln1, ln2, attn, w1, b1, w2, b2)", sol="""
  wq, wk, wv, wo = attn
  h0 = ln1(x)
  q, k, v = h0 @ wq, h0 @ wk, h0 @ wv
  scores = q @ k.transpose(-2, -1) / (q.shape[-1] ** 0.5)
  a = torch.softmax(scores, dim=-1) @ v
  h = x + a @ wo
  h2 = ln2(h)
  h = h + F.gelu(h2 @ w1.t() + b1) @ w2.t() + b2
  return h
  """,
  mk="""
  d = 8
  ln1, ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
  attn = (torch.randn(d, d) * 0.1, torch.randn(d, d) * 0.1, torch.randn(d, d) * 0.1, torch.randn(d, d) * 0.1)
  return (torch.randn(2, 4, d), ln1, ln2, attn,
          torch.randn(4 * d, d), torch.randn(4 * d), torch.randn(d, 4 * d), torch.randn(d))
  """, arg_names=["x", "ln1", "ln2", "attn", "w1", "b1", "w2", "b2"], imports=NN,
  hints=["Pre-LN means normalising **before** each sub-layer.",
         "Both sub-layers add their output back to the residual stream."])

q(topic="torch", diff="hard", tags=["transformer", "lm-loss"], title="Causal language-model loss",
  ask="`logits` is (b, t, vocab) and `ids` is (b, t) int64. Compute the next-token "
      "cross-entropy: predict `ids[:, 1:]` from `logits[:, :-1]`. Return the mean loss.",
  sig="solve(logits, ids)", sol="""
  shift_logits = logits[:, :-1, :].reshape(-1, logits.shape[-1])
  shift_targets = ids[:, 1:].reshape(-1)
  return F.cross_entropy(shift_logits, shift_targets)
  """,
  mk="""
  cases = [(torch.randn(2, 6, 10), torch.randint(0, 10, (2, 6))),
           (torch.randn(1, 3, 4), torch.randint(0, 4, (1, 3))),
           (torch.randn(3, 5, 8), torch.randint(0, 8, (3, 5)))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "ids"], imports=NN,
  props=["""
  logits, ids = _args
  ref = F.cross_entropy(logits[:, :-1, :].reshape(-1, logits.shape[-1]), ids[:, 1:].reshape(-1))
  assert torch.allclose(_got, ref, atol=1e-6)
  """],
  hints=["Shift the targets one token to the left.",
         "Flatten the batch and time axes before `cross_entropy`."])

q(topic="torch", diff="medium", tags=["sampling", "temperature"], title="Temperature softmax",
  ask="Return `softmax(logits / temperature, dim=-1)`.",
  sig="solve(logits, temperature)", sol="return torch.softmax(logits / temperature, dim=-1)",
  mk="""
  cases = [(torch.randn(3, 5), 0.5), (torch.randn(2, 4), 1.0), (torch.randn(1, 6), 2.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "temperature"],
  props=["assert torch.allclose(_got.sum(dim=-1), torch.ones(_got.shape[0]), atol=1e-5)",
         "assert (_got >= 0).all()"],
  hints=["Low temperature sharpens the distribution.",
         "`temperature=1` keeps the plain softmax."])

q(topic="torch", diff="medium", tags=["sampling", "topk"], title="Top-k filtering",
  ask="Keep only the `k` largest logits per row, setting everything else to `-inf`. "
      "Return the filtered logits (n, vocab).",
  sig="solve(logits, k)", sol="""
  kth = logits.topk(k, dim=-1).values[:, -1:]
  return logits.masked_fill(logits < kth, float("-inf"))
  """,
  mk="""
  cases = [(torch.randn(3, 10), 3), (torch.randn(2, 5), 1), (torch.randn(4, 6), 6)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["logits", "k"],
  props=["""
  logits, k = _args
  finite = torch.isfinite(_got)
  assert (finite.sum(dim=-1) >= k).all(), "at least k entries must survive"
  assert torch.isneginf(_got[~finite]).all()
  """],
  hints=["Find the k-th largest value per row.",
         "`masked_fill` with a comparison hides the rest."])

q(topic="torch", diff="hard", tags=["attention", "einsum"], title="Attention with einsum",
  ask="Write single-head attention using `torch.einsum` for both products: "
      "`scores = einsum('id,jd->ij', Q, K) / sqrt(d)`, then "
      "`out = einsum('ij,jv->iv', weights, V)`.",
  sig="solve(Q, K, V)", sol="""
  d = Q.shape[-1]
  scores = torch.einsum("id,jd->ij", Q, K) / (d ** 0.5)
  weights = torch.softmax(scores, dim=-1)
  return torch.einsum("ij,jv->iv", weights, V)
  """,
  mk="""
  cases = [(torch.randn(4, 6), torch.randn(5, 6), torch.randn(5, 3)),
           (torch.randn(2, 2), torch.randn(2, 2), torch.randn(2, 2)),
           (torch.randn(3, 8), torch.randn(3, 8), torch.randn(3, 4))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["Q", "K", "V"],
  props=["""
  Q, K, V = _args
  scores = Q @ K.transpose(-2, -1) / (Q.shape[-1] ** 0.5)
  assert torch.allclose(_got, torch.softmax(scores, -1) @ V, atol=1e-5)
  """],
  hints=["`einsum` labels each axis explicitly, which documents the maths.",
         "`ij,jv->iv` is exactly the weighted sum over the value matrix."])

# =========================================================================== #
#  Data utilities
# =========================================================================== #
q(topic="torch", diff="easy", tags=["data", "dataloader"], title="Number of batches",
  ask="Wrap `X`/`y` in a `TensorDataset` and return `len(DataLoader(...))` for the given "
      "batch size (an int).",
  sig="solve(X, y, batch_size)", sol="""
  ds = torch.utils.data.TensorDataset(X, y)
  return len(torch.utils.data.DataLoader(ds, batch_size=batch_size))
  """,
  mk="""
  cases = [(torch.randn(10, 2), torch.randn(10), 3), (torch.randn(8, 1), torch.randn(8), 4),
           (torch.randn(1, 5), torch.randn(1), 8)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["X", "y", "batch_size"],
  props=["assert isinstance(_got, int)"],
  hints=["The last batch is smaller but still counted.",
         "`ceil(n / batch_size)`."])

q(topic="torch", diff="medium", tags=["data", "dataset"], title="A custom Dataset",
  ask="Define a `Dataset` class over `X`/`y` that supports `len()` and indexing `[i] -> "
      "(X[i], y[i])`, then return the mean of `y` computed by iterating over it.",
  sig="solve(X, y)", sol="""
  class D(torch.utils.data.Dataset):
      def __init__(self, X, y):
          self.X, self.y = X, y
      def __len__(self):
          return len(self.X)
      def __getitem__(self, i):
          return self.X[i], self.y[i]
  ds = D(X, y)
  total = sum(float(ds[i][1]) for i in range(len(ds)))
  return total / len(ds)
  """,
  mk="""
  cases = [(torch.randn(6, 2), torch.randn(6)), (torch.randn(3, 1), torch.arange(3).float()),
           (torch.randn(4, 3), torch.ones(4))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["X", "y"],
  props=["assert abs(_got - float(_args[1].mean())) < 1e-6"],
  hints=["`__len__` and `__getitem__` are the only required methods.",
         "Returning a tuple of (features, target) is the convention."])

q(topic="torch", diff="medium", tags=["data", "split"], title="Train/validation split",
  ask="Shuffle the indices `randperm(n, generator=torch.Generator().manual_seed(seed))` "
      "and split them into `(train_idx, val_idx)` where validation takes "
      "`int(n * val_frac)` samples from the end. Return both index tensors.",
  sig="solve(n, val_frac, seed)", sol="""
  g = torch.Generator().manual_seed(seed)
  perm = torch.randperm(n, generator=g)
  n_val = int(n * val_frac)
  return (perm[: n - n_val], perm[n - n_val:])
  """,
  mk="""
  cases = [(10, 0.2, 0), (7, 0.5, 42), (5, 0.0, 7)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n", "val_frac", "seed"],
  props=["""
  n, val_frac, seed = _args
  train_idx, val_idx = _got
  assert len(train_idx) + len(val_idx) == n
  assert len(set(train_idx.tolist()) & set(val_idx.tolist())) == 0, "the splits must not overlap"
  """],
  hints=["Use a local generator so the split is reproducible.",
         "Take the validation part from the tail of the permutation."])

q(topic="torch", diff="medium", tags=["data", "padding"], title="Pad a list of sequences",
  ask="`seqs` is a list of 1-D int64 tensors of different lengths. Return a single "
      "(batch, max_len) tensor, right-padded with zeros.",
  sig="solve(seqs)", sol="""
  max_len = max(len(s) for s in seqs)
  out = torch.zeros(len(seqs), max_len, dtype=seqs[0].dtype)
  for i, s in enumerate(seqs):
      out[i, :len(s)] = s
  return out
  """,
  mk="""
  cases = [([torch.tensor([1, 2]), torch.tensor([3])],),
           ([torch.tensor([5, 6, 7, 8]), torch.tensor([1, 2, 3, 4])],),
           ([torch.tensor([9])],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["seqs"],
  props=["""
  seqs = _args[0]
  assert _got.shape == (len(seqs), max(len(s) for s in seqs))
  for i, s in enumerate(seqs):
      assert torch.equal(_got[i, :len(s)], s)
      assert (_got[i, len(s):] == 0).all()
  """],
  hints=["Compute the maximum length first.",
         "Copy each sequence into the left part of its row."])

q(topic="torch", diff="medium", tags=["data", "normalize"], title="Normalise an image batch",
  ask="`x` is (b, c, h, w) and `mean`/`std` are per-channel `(c,)` tensors. Return "
      "`(x - mean) / std` using broadcasting (remember to reshape them to (1, c, 1, 1)).",
  sig="solve(x, mean, std)", sol="""
  return (x - mean.view(1, -1, 1, 1)) / std.view(1, -1, 1, 1)
  """,
  mk="""
  cases = [(torch.rand(2, 3, 8, 8), torch.tensor([0.5, 0.5, 0.5]), torch.tensor([0.5, 0.5, 0.5])),
           (torch.randn(1, 1, 4, 4), torch.tensor([0.0]), torch.tensor([1.0])),
           (torch.rand(3, 2, 5, 5), torch.tensor([0.1, 0.2]), torch.tensor([0.3, 0.4]))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "mean", "std"],
  hints=["The channel axis is axis 1 — reshape the statistics accordingly.",
         "Broadcasting aligns trailing dimensions."])

q(topic="torch", diff="easy", tags=["data", "encode"], title="Label encoding",
  ask="`labels` is a list of strings. Map them to integer ids by their **sorted** unique "
      "order and return a list of ints.",
  sig="solve(labels)", sol="""
  vocab = {w: i for i, w in enumerate(sorted(set(labels)))}
  return [vocab[w] for w in labels]
  """,
  mk="""
  cases = [(["cat", "dog", "cat", "bird"],), (["b", "a"],), (["x", "x", "x"],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["labels"],
  props=["""
  labels = _args[0]
  uniq = sorted(set(labels))
  assert len(set(_got)) <= len(uniq)
  assert _got == [sorted(set(labels)).index(w) for w in labels]
  """],
  hints=["`sorted(set(labels))` defines the vocabulary.",
         "A dict from word to position encodes everything in one pass."])

q(topic="torch", diff="medium", tags=["data", "shuffle"], title="Seeded shuffling",
  ask="Return `torch.randperm(n, generator=torch.Generator().manual_seed(seed))`.",
  sig="solve(n, seed)", sol="""
  g = torch.Generator().manual_seed(seed)
  return torch.randperm(n, generator=g)
  """,
  mk="""
  cases = [(10, 0), (5, 123), (1, 7)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n", "seed"],
  props=["assert sorted(_got.tolist()) == list(range(_args[0]))"],
  hints=["A local generator makes shuffling reproducible.",
         "`randperm` returns a permutation of 0..n-1."])

q(topic="torch", diff="medium", tags=["data", "collate"], title="Collate variable-length batches",
  ask="`batch` is a list of `(x, y)` pairs where `x` is a 1-D float tensor of varying "
      "length. Return the tuple `(padded_x, stacked_y)` with `padded_x` zero-padded to "
      "the longest sequence in the batch and `y` stacked into a tensor.",
  sig="solve(batch)", sol="""
  max_len = max(len(x) for x, _ in batch)
  padded = torch.zeros(len(batch), max_len)
  for i, (x, _) in enumerate(batch):
      padded[i, :len(x)] = x
  ys = torch.stack([y for _, y in batch])
  return (padded, ys)
  """,
  mk="""
  cases = [([(torch.randn(3), torch.tensor(1.0)), (torch.randn(5), torch.tensor(2.0))],),
           ([(torch.randn(2), torch.tensor(0.0))],),
           ([(torch.randn(4), torch.tensor(1.0)), (torch.randn(1), torch.tensor(1.0)),
             (torch.randn(2), torch.tensor(0.0))],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["batch"],
  hints=["Find the max length across the batch.",
         "Targets all have the same shape, so they can simply be stacked."])

# =========================================================================== #
#  Tensor internals & misc
# =========================================================================== #
auto(topic="torch", diff="medium", tags=["contiguous"], title="Contiguity check",
     ask="Return whether `x` is contiguous in memory (`x.is_contiguous()`).",
     args=["x = torch.randn(3, 4)", "x = torch.randn(3, 4).t()", "x = torch.randn(2, 3, 4).permute(2, 0, 1)"],
     op=["x.is_contiguous()", "x.is_contiguous()", "x.is_contiguous()"])

auto(topic="torch", diff="medium", tags=["stride"], title="Tensor strides",
     ask="Return the stride tuple of `x` (`x.stride()`).",
     args=["x = torch.randn(3, 4)", "x = torch.randn(3, 4).t()", "x = torch.randn(2, 2, 2)"],
     op=["x.stride()", "x.stride()", "x.stride()"])

q(topic="torch", diff="medium", tags=["memory", "detach"], title="Clone does not share memory",
  ask="Return a tensor with the same values as `x` that does **not** share storage: use "
      "`x.clone()`. Property checks compare the data pointers.",
  sig="solve(x)", sol="return x.clone()",
  mk="""
  x = torch.randn(3, 4)
  return (x,)
  """, arg_names=["x"], cmp="none",
  props=["""
  x = _args[0]
  assert torch.equal(_got, x), "values must match"
  assert _got.data_ptr() != x.data_ptr(), "clone must not share storage"
  assert _got.requires_grad == x.requires_grad
  """],
  hints=["`clone()` copies the data (and keeps the graph link).",
         "`detach()` shares storage instead."])

q(topic="torch", diff="medium", tags=["memory", "view"], title="Views share memory",
  ask="Return `x.view(-1)` — a **view** that shares storage with `x` (no copy). Property "
      "checks confirm the shared data pointer.",
  sig="solve(x)", sol="return x.view(-1)",
  mk="""
  x = torch.randn(3, 4)
  return (x,)
  """, arg_names=["x"], cmp="none",
  props=["""
  x = _args[0]
  assert _got.data_ptr() == x.data_ptr(), "a view must share storage with the source"
  assert _got.numel() == x.numel()
  """],
  hints=["`view` reinterprets the same buffer.",
         "That is why mutating the view changes the original."])

q(topic="torch", diff="medium", tags=["dtype", "promotion"], title="Dtype promotion",
  ask="Return the dtype that results from adding an `int64` tensor and a `float32` "
      "tensor.",
  sig="solve()", sol="""
  a = torch.tensor([1, 2], dtype=torch.int64)
  b = torch.tensor([1.0, 2.0], dtype=torch.float32)
  return (a + b).dtype
  """,
  mk="return ()", arg_names=[],
  props=["assert _got == torch.float32"],
  hints=["PyTorch promotes toward the 'wider' floating type.",
         "Integer tensors mix with floats to give floats."])

q(topic="torch", diff="medium", tags=["dtype", "half"], title="Half precision",
  ask="Return `x` converted to `torch.float16`.",
  sig="solve(x)", sol="return x.half()",
  mk="""
  cases = [(torch.randn(3, 4),), (torch.arange(5).float(),), (torch.ones(2, 2, dtype=torch.float64),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`.half()` is shorthand for `.to(torch.float16)`.",
         "Half precision halves the memory footprint."])

q(topic="torch", diff="medium", tags=["memory", "bytes"], title="Bytes used by a tensor",
  ask="Return the number of bytes of a tensor's storage: `x.numel() * x.element_size()`.",
  sig="solve(x)", sol="return x.numel() * x.element_size()",
  mk="""
  cases = [(torch.randn(3, 4),), (torch.zeros(10, dtype=torch.int64),), (torch.ones(2, 2, dtype=torch.float64),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["`element_size()` reports bytes per element.",
         "float32 uses 4 bytes, float64 uses 8."])

q(topic="torch", diff="medium", tags=["save", "load"], title="Round-trip through bytes",
  ask="Serialise `x` with `torch.save` into an in-memory `io.BytesIO`, read it back with "
      "`torch.load(..., weights_only=True)` and return the loaded tensor.",
  sig="solve(x)", sol="""
  import io
  buf = io.BytesIO()
  torch.save(x, buf)
  buf.seek(0)
  return torch.load(buf, weights_only=True)
  """,
  mk="""
  cases = [(torch.randn(3, 4),), (torch.tensor([1, 2, 3]),), (torch.zeros(1, dtype=torch.float64),)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x"],
  hints=["A `BytesIO` object behaves like a file for `torch.save`.",
         "Seek back to 0 before loading."])

q(topic="torch", diff="medium", tags=["no_grad", "context"], title="Grad mode context",
  ask="`x` requires grad. Inside `torch.set_grad_enabled(False)` compute `y = x * 2` and "
      "return `y.requires_grad` — the result shows whether the context was really "
      "disabled.",
  sig="solve(x)", sol="""
  with torch.set_grad_enabled(False):
      y = x * 2
  return y.requires_grad
  """,
  mk="""
  x = torch.randn(3, requires_grad=True)
  return (x,)
  """, arg_names=["x"],
  props=["assert _got is False, 'no graph should be recorded inside the context'"],
  hints=["`torch.set_grad_enabled(False)` is the context-manager form of `no_grad`.",
         "The flag wins over `requires_grad=True`."])

q(topic="torch", diff="hard", tags=["unfold", "sliding-window"], title="Sliding windows with unfold",
  ask="Return all windows of length `w` from the 1-D tensor `x`, stacked as "
      "`(num_windows, w)` using `x.unfold(0, w, stride)`.",
  sig="solve(x, w, stride)", sol="""
  return x.unfold(0, w, stride)
  """,
  mk="""
  cases = [(torch.arange(10).float(), 3, 1), (torch.arange(6).float(), 2, 2), (torch.arange(5).float(), 5, 1)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["x", "w", "stride"],
  props=["""
  x, w, stride = _args
  assert _got.shape[1] == w
  assert torch.equal(_got[0], x[:w])
  """],
  hints=["`unfold(dimension, size, step)` returns a view (no copy).",
         "The number of windows is `(len - w) // stride + 1`."])
