"""Matplotlib question bank — plotting drills checked by inspecting artists."""
import numpy as np

from dsl import q


def pq(title, ask, sol, props, tags, diff="easy", variants=3, hints=(), mk="return ()",
       sig="solve()", names=(), ncases=0):
    q(topic="matplotlib", diff=diff, tags=tags, title=title, ask=ask, sig=sig, sol=sol,
      mk=mk, arg_names=list(names), cmp="none", props=props, hints=list(hints),
      variants=variants, ncases=ncases, no_example=True)


LINEDATA = """
x = np.arange(5 + v)
return (x, x ** 2.0)
"""

# =========================================================================== #
#  Line plots & basic styling
# =========================================================================== #
pq("Plot a line",
   "Plot `y` against `x` on a new figure, then **return the Axes object**.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   return ax
   """,
   ["""ax = _got
   assert len(ax.lines) == 1, "exactly one line expected"
   assert np.allclose(ax.lines[0].get_xdata(), _args[0])
   assert np.allclose(ax.lines[0].get_ydata(), _args[1])"""],
   ["line", "plot"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`fig, ax = plt.subplots()` gives you both objects.",
          "`ax.plot(x, y)` draws the data on those axes."])

pq("Plot two lines",
   "Plot `y1` and `y2` against `x` on the same axes and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y1)
   ax.plot(x, y2)
   return ax
   """,
   ["""ax = _got
   assert len(ax.lines) == 2, "both series must be plotted"
   assert np.allclose(ax.lines[1].get_ydata(), _args[2])"""],
   ["line"], mk="""
   x = np.arange(5 + v)
   return (x, x, x ** 2.0)
   """, sig="solve(x, y1, y2)", names=["x", "y1", "y2"],
   hints=["Call `ax.plot` once per series.",
          "The second call reuses the same axes."])

pq("Line colour",
   "Plot `y` against `x` with a red line and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, color='red')
   return ax
   """,
   ["""ax = _got
   assert len(ax.lines) == 1
   from matplotlib.colors import to_rgba
   assert to_rgba(ax.lines[0].get_color()) == to_rgba('red'), "the line must be red"
   """],
   ["line", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`color=` (or `c=`) sets the line colour.",
          "`'r'` is a shorthand for red."])

pq("Dashed line",
   "Plot `y` against `x` with a dashed linestyle and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, linestyle='--')
   return ax
   """,
   ["""ax = _got
   assert ax.lines[0].get_linestyle() in ('--', 'dashed')"""],
   ["line", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`linestyle='--'` is the dashed shorthand.",
          "`ls` is the short alias."])

pq("Markers",
   "Plot `y` against `x` using circle markers (`marker='o'`) and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, marker='o')
   return ax
   """,
   ["""ax = _got
   assert ax.lines[0].get_marker() == 'o'"""],
   ["line", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`marker='o'` draws circles at each data point.",
          "Markers and linestyles combine."])

pq("Title",
   "Plot `y` against `x` and set the axes title to `'Squares'`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_title('Squares')
   return ax
   """,
   ["assert _got.get_title() == 'Squares'"],
   ["labels"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.set_title('...')`.",
          "Don't confuse it with the figure-level `suptitle`."])

pq("Axis labels",
   "Plot `y` against `x`, label the x-axis `'time'` and the y-axis `'value'`, and "
   "return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_xlabel('time')
   ax.set_ylabel('value')
   return ax
   """,
   ["""assert _got.get_xlabel() == 'time'
   assert _got.get_ylabel() == 'value'"""],
   ["labels"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.set_xlabel` / `ax.set_ylabel`.",
          "Unit strings are common: `'value [m/s]'`."])

pq("Axis limits",
   "Plot `y` against `x` and set the x-limits to `[0, 10]` and the y-limits to `[0, 30]`. "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_xlim(0, 10)
   ax.set_ylim(0, 30)
   return ax
   """,
   ["""assert tuple(_got.get_xlim()) == (0.0, 10.0)
   assert tuple(_got.get_ylim()) == (0.0, 30.0)"""],
   ["limits"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.set_xlim(lo, hi)`.",
          "Limits are applied even if the data does not reach them."])

pq("Grid on",
   "Plot `y` against `x` and turn the grid on. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.grid(True)
   return ax
   """,
   ["""ax = _got
   assert ax.get_xgridlines()[0].get_visible(), "x grid should be visible"
   assert ax.get_ygridlines()[0].get_visible(), "y grid should be visible"
   """],
   ["grid"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.grid(True)` toggles the major grid.",
          "`grid(True, which='both')` includes minor ticks."])

pq("Legend",
   "Plot `y` against `x` with the label `'data'` and show the legend. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, label='data')
   ax.legend()
   return ax
   """,
   ["""ax = _got
   leg = ax.get_legend()
   assert leg is not None, "call ax.legend()"
   assert leg.get_texts()[0].get_text() == 'data'"""],
   ["legend"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["Give the line a `label`, then call `ax.legend()`.",
          "Without a label the legend entry would be empty."])

pq("Legend location",
   "Plot the two series `y1`, `y2` with labels `'a'` and `'b'` and place the legend in "
   "the lower right corner. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y1, label='a')
   ax.plot(x, y2, label='b')
   ax.legend(loc='lower right')
   return ax
   """,
   ["""leg = _got.get_legend()
   assert leg is not None
   assert [t.get_text() for t in leg.get_texts()] == ['a', 'b']
   assert leg._loc in (4, 'lower right'), f"legend should be lower right, got {leg._loc}"
   """],
   ["legend"], mk="""
   x = np.arange(5 + v)
   return (x, x, -x)
   """, sig="solve(x, y1, y2)", names=["x", "y1", "y2"],
   hints=["`ax.legend(loc='lower right')`.",
          "Location can also be an integer code (4 = lower right)."])

pq("Log y axis",
   "Plot `y` against `x` and use a logarithmic scale on the y-axis. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_yscale('log')
   return ax
   """,
   ["assert _got.get_yscale() == 'log'"],
   ["scale"], mk="""
   x = np.arange(1, 5 + v)
   return (x, 10.0 ** x)
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.set_yscale('log')`.",
          "Log scales are useful when values span orders of magnitude."])

pq("Invert the y axis",
   "Plot `y` against `x` and invert the y-axis direction. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.invert_yaxis()
   return ax
   """,
   ["assert _got.yaxis_inverted()"],
   ["limits"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.invert_yaxis()` flips the direction.",
          "Image coordinates often need this."])

pq("Custom tick positions",
   "Plot `y` against `x` and set the x-ticks exactly to `[0, 2, 4]`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_xticks([0, 2, 4])
   return ax
   """,
   ["np.allclose(_got.get_xticks(), [0, 2, 4])"],
   ["ticks"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.set_xticks([...])` replaces the locator.",
          "`set_yticks` does the same for the other axis."])

pq("Custom tick labels",
   "Plot `y` against `x`, put ticks at `[0, 2, 4]` and label them `['zero', 'two', "
   "'four']`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_xticks([0, 2, 4])
   ax.set_xticklabels(['zero', 'two', 'four'])
   return ax
   """,
   ["""labels = [t.get_text() for t in _got.get_xticklabels() if t.get_text()]
   assert labels == ['zero', 'two', 'four'], f"got {labels}" """],
   ["ticks"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["Call `set_xticks` first, then `set_xticklabels`.",
          "The order of the labels matches the tick order."])

pq("Rotate tick labels",
   "Plot `y` against `x` and rotate the x tick labels by 45 degrees. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   plt.setp(ax.get_xticklabels(), rotation=45)
   return ax
   """,
   ["""rot = [t.get_rotation() for t in _got.get_xticklabels()]
   assert any(abs(r - 45) < 1e-6 for r in rot), "labels should be rotated 45 degrees"
   """],
   ["ticks"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`plt.setp(labels, rotation=45)` works on all labels at once.",
          "Horizontal labels overlap when they are long."])

pq("Hide the top and right spines",
   "Plot `y` against `x` and make the top and right spines invisible. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.spines['top'].set_visible(False)
   ax.spines['right'].set_visible(False)
   return ax
   """,
   ["""assert not _got.spines['top'].get_visible()
   assert not _got.spines['right'].get_visible()
   assert _got.spines['left'].get_visible()"""],
   ["spines"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["Spines are the frame lines around the axes.",
          "`ax.spines[name].set_visible(False)` hides one."])

pq("Figure size",
   "Create a figure with size 8x4 inches, plot `y` against `x`, and return the "
   "**Figure** object.",
   """
   fig, ax = plt.subplots(figsize=(8, 4))
   ax.plot(x, y)
   return fig
   """,
   ["""fig = _got
   assert tuple(np.round(fig.get_size_inches(), 6)) == (8.0, 4.0)
   assert len(fig.axes) == 1"""],
   ["figure"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`plt.subplots(figsize=(w, h))`.",
          "Return the Figure when the ask says so."])

pq("Figure suptitle",
   "Plot `y` against `x` and set the figure-level title to `'Overview'`. Return the "
   "Figure.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   fig.suptitle('Overview')
   return fig
   """,
   ["assert _got._suptitle.get_text() == 'Overview'"],
   ["labels"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`fig.suptitle` sits above all subplots.",
          "`ax.set_title` is per-axes."])

pq("Horizontal reference line",
   "Plot `y` against `x` and draw a horizontal reference line at `y=5` with `axhline`. "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.axhline(5)
   return ax
   """,
   ["""ax = _got
   assert len(ax.lines) == 2, "the data line plus the reference line"
   assert np.allclose(ax.lines[1].get_ydata(), [5, 5])"""],
   ["reference"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.axhline(y)` spans the whole axes width.",
          "`ax.axvline(x)` does the same vertically."])

pq("Shaded region",
   "Plot `y` against `x` and shade the region between 2 and 4 on the x-axis with "
   "`axvspan`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.axvspan(2, 4, alpha=0.3)
   return ax
   """,
   ["assert len(_got.patches) == 1, 'axvspan adds exactly one patch'"],
   ["reference"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`axvspan(x0, x1)` highlights a vertical band.",
          "`alpha` makes it translucent."])

pq("Fill between",
   "Plot `y1` and `y2` against `x` and fill the area between them with "
   "`ax.fill_between`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y1, color='C0')
   ax.plot(x, y2, color='C1')
   ax.fill_between(x, y1, y2, alpha=0.3)
   return ax
   """,
   ["assert len(_got.collections) == 1, 'fill_between creates one collection'"],
   ["fill"], mk="""
   x = np.arange(5 + v)
   return (x, x, x + 1.0)
   """, sig="solve(x, y1, y2)", names=["x", "y1", "y2"],
   hints=["`ax.fill_between(x, y1, y2)` shades between the curves.",
          "Great for confidence bands."])

pq("Text annotation",
   "Plot `y` against `x` and write the text `'peak'` at `(2, 4)`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.text(2, 4, 'peak')
   return ax
   """,
   ["""texts = _got.texts
   assert len(texts) == 1, "exactly one text artist"
   assert texts[0].get_text() == 'peak'
   assert tuple(np.round(texts[0].get_position(), 6)) == (2.0, 4.0)"""],
   ["text"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.text(x, y, s)` places text in data coordinates.",
          "`ax.annotate` adds arrows as well."])

pq("Annotate with an arrow",
   "Plot `y` against `x` and annotate the point `(3, 9)` with the text `'here'` and an "
   "arrow pointing at it (`ax.annotate`). Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.annotate('here', xy=(3, 9), xytext=(1, 15),
               arrowprops=dict(arrowstyle='->'))
   return ax
   """,
   ["""texts = _got.texts
   assert len(texts) == 1
   assert texts[0].get_text() == 'here'
   assert _got.texts[0].get_window_extent is not None"""],
   ["text", "annotate"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`xy` is the point being annotated, `xytext` the text position.",
          "`arrowprops=dict(arrowstyle='->')` draws the arrow."])

# =========================================================================== #
#  Other chart types
# =========================================================================== #
pq("Scatter plot",
   "Draw a scatter plot of `y` against `x` and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.scatter(x, y)
   return ax
   """,
   ["""ax = _got
   assert len(ax.collections) == 1, "scatter creates one PathCollection"
   offsets = ax.collections[0].get_offsets()
   assert np.allclose(np.asarray(offsets)[:, 0], _args[0])
   assert np.allclose(np.asarray(offsets)[:, 1], _args[1])"""],
   ["scatter"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.scatter(x, y)` stores the points in a PathCollection.",
          "Scatter accepts per-point sizes and colours."])

pq("Scatter with colour and size",
   "Scatter `y` against `x` with point size `s=100` and colour `'green'`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.scatter(x, y, s=100, color='green')
   return ax
   """,
   ["""ax = _got
   coll = ax.collections[0]
   assert np.allclose(coll.get_sizes(), 100), f"sizes were {coll.get_sizes()}"
   from matplotlib.colors import to_rgba
   assert to_rgba(coll.get_facecolor()[0]) == to_rgba('green')"""],
   ["scatter", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`s=` controls the marker area in points squared.",
          "`color=` sets the face colour."])

pq("Bar chart",
   "Draw a vertical bar chart with categories `labels` and values `values`. Return the "
   "Axes.",
   """
   fig, ax = plt.subplots()
   ax.bar(labels, values)
   return ax
   """,
   ["""ax = _got
   heights = [p.get_height() for p in ax.patches]
   assert np.allclose(heights, _args[1]), f"heights were {heights}"
   assert len(ax.patches) == len(_args[0])"""],
   ["bar"], mk="""
   labels = ['a', 'b', 'c', 'd'][: 3 + v % 2]
   values = np.arange(1.0, len(labels) + 1) * (v + 1)
   return (labels, values)
   """, sig="solve(labels, values)", names=["labels", "values"],
   hints=["`ax.bar` accepts categories directly.",
          "Each bar is a Rectangle patch."])

pq("Horizontal bar chart",
   "Draw a horizontal bar chart with `ax.barh` for the categories `labels` and values "
   "`values`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.barh(labels, values)
   return ax
   """,
   ["""ax = _got
   widths = [p.get_width() for p in ax.patches]
   assert np.allclose(widths, _args[1])"""],
   ["bar"], mk="""
   labels = ['x', 'y', 'z'][: 2 + v % 2]
   return (labels, np.arange(1.0, len(labels) + 1))
   """, sig="solve(labels, values)", names=["labels", "values"],
   hints=["`barh` uses widths instead of heights.",
          "Useful for long category names."])

pq("Histogram",
   "Plot a histogram of `data` with `bins` bins. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.hist(data, bins=bins)
   return ax
   """,
   ["""ax = _got
   expected, _ = np.histogram(_args[0], bins=_args[1])
   heights = [p.get_height() for p in ax.patches]
   assert len(heights) == _args[1], f"expected {_args[1]} bars, got {len(heights)}"
   assert np.allclose(heights, expected)"""],
   ["hist"], mk="""
   data = np.random.randn(50 + 10 * v)
   return (data, 5)
   """, sig="solve(data, bins)", names=["data", "bins"],
   hints=["`ax.hist` bins the data itself.",
          "Each bin is a Rectangle; the heights are the counts."])

pq("Histogram with edge colour",
   "Plot a histogram of `data` with 10 bins and black edges (`edgecolor='black'`). "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.hist(data, bins=10, edgecolor='black')
   return ax
   """,
   ["""
   from matplotlib.colors import to_rgba
   ax = _got
   assert len(ax.patches) == 10
   assert to_rgba(ax.patches[0].get_edgecolor()) == to_rgba('black')
   """],
   ["hist", "style"], mk="""
   return (np.random.randn(40 + 5 * v),)
   """, sig="solve(data)", names=["data"],
   hints=["`edgecolor` outlines each bar.",
          "It makes adjacent bins distinguishable."])

pq("Heatmap with imshow",
   "Display the 2-D array `img` with `imshow` and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.imshow(img)
   return ax
   """,
   ["""ax = _got
   assert len(ax.images) == 1, "imshow adds exactly one AxesImage"
   assert ax.images[0].get_array().shape == _args[0].shape"""],
   ["image"], mk="""
   return (np.random.rand(4 + v, 5),)
   """, sig="solve(img)", names=["img"],
   hints=["`imshow` renders a 2-D array as a raster.",
          "Set `cmap` to control the colormap."])

pq("Grayscale image",
   "Display `img` using the `'gray'` colormap and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.imshow(img, cmap='gray')
   return ax
   """,
   ["assert _got.images[0].get_cmap().name == 'gray'"],
   ["image"], mk="""
   return (np.random.rand(6, 6),)
   """, sig="solve(img)", names=["img"],
   hints=["`cmap='gray'` maps low values to black.",
          "Use `vmin`/`vmax` to fix the contrast."])

pq("Image with a colourbar",
   "Display `img` with `imshow` and add a colourbar. Return the Axes.",
   """
   fig, ax = plt.subplots()
   im = ax.imshow(img)
   fig.colorbar(im, ax=ax)
   return ax
   """,
   ["assert _got.figure.axes.index(_got) == 0 and len(_got.figure.axes) >= 2, 'colourbar adds an axes'"],
   ["image", "colorbar"], mk="""
   return (np.random.rand(5, 5),)
   """, sig="solve(img)", names=["img"],
   hints=["`fig.colorbar(im, ax=ax)` appends a dedicated axes.",
          "The colourbar documents the value scale."])

pq("Two subplots side by side",
   "Create a figure with two side-by-side subplots, plot `y` on the first and `y2` on the "
   "second, then return the **Figure**.",
   """
   fig, axes = plt.subplots(1, 2)
   axes[0].plot(x, y)
   axes[1].plot(x, y2)
   return fig
   """,
   ["""fig = _got
   assert len(fig.axes) == 2
   assert len(fig.axes[0].lines) == 1 and len(fig.axes[1].lines) == 1"""],
   ["subplots"], mk="""
   x = np.arange(5 + v)
   return (x, x, x ** 2.0)
   """, sig="solve(x, y, y2)", names=["x", "y", "y2"],
   hints=["`plt.subplots(1, 2)` returns a figure and an array of axes.",
          "Index the axes array: `axes[0]`, `axes[1]`."])

pq("Grid of subplots",
   "Create a 2x2 grid of subplots and plot `y` on each one. Return the Figure.",
   """
   fig, axes = plt.subplots(2, 2)
   for ax in axes.flat:
       ax.plot(x, y)
   return fig
   """,
   ["""fig = _got
   assert len(fig.axes) == 4
   assert all(len(a.lines) == 1 for a in fig.axes)"""],
   ["subplots"], mk="""
   x = np.arange(4 + v)
   return (x, x ** 2.0)
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`axes` is a 2-D array of Axes objects.",
          "`axes.flat` iterates over all of them."])

pq("Subplot titles",
   "Create two subplots sharing the x-axis. Give the first the title `'A'` and the second "
   "`'B'`. Return the Figure.",
   """
   fig, axes = plt.subplots(1, 2, sharex=True)
   axes[0].set_title('A')
   axes[1].set_title('B')
   return fig
   """,
   ["""assert [a.get_title() for a in _got.axes] == ['A', 'B']
   assert _got.axes[0].get_shared_x_axes().joined(_got.axes[0], _got.axes[1])"""],
   ["subplots"], mk="return ()",
   hints=["`sharex=True` links the x axes.",
          "Panning one subplot moves the other."])

pq("Twin axes",
   "Plot `y1` on the primary axes and `y2` on a twin y-axis (`ax.twinx()`). Return the "
   "primary Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y1)
   ax2 = ax.twinx()
   ax2.plot(x, y2)
   return ax
   """,
   ["assert len(_got.figure.axes) == 2, 'twinx creates a second Axes'"],
   ["subplots"], mk="""
   x = np.arange(5 + v)
   return (x, x, 100.0 * x)
   """, sig="solve(x, y1, y2)", names=["x", "y1", "y2"],
   hints=["`twinx()` returns a new Axes sharing the x-axis.",
          "Great for mixing units on one plot."])

pq("Pie chart",
   "Draw a pie chart of `sizes` with the labels `labels`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.pie(sizes, labels=labels)
   return ax
   """,
   ["""ax = _got
   assert len(ax.patches) == len(_args[0]), "one wedge per value"
   assert abs(sum(p.theta2 - p.theta1 for p in ax.patches) - 360) < 1.0"""],
   ["pie"], mk="""
   labels = ['a', 'b', 'c'][: 2 + v % 2]
   return (labels, np.arange(1.0, len(labels) + 1))
   """, sig="solve(labels, sizes)", names=["labels", "sizes"],
   hints=["`ax.pie` normalises the values so the wedges sum to 360 degrees.",
          "`autopct='%1.0f%%'` prints the percentages."])

pq("Box plot",
   "Draw a box plot of `data` with `ax.boxplot` and return the **dict** it returns.",
   """
   fig, ax = plt.subplots()
   return ax.boxplot(data)
   """,
   ["""assert 'medians' in _got, "boxplot returns a dict of artists"
   med = _got['medians'][0].get_ydata()[0]
   assert np.isclose(med, np.median(_args[0]))"""],
   ["boxplot"], mk="""
   return (np.random.randn(50 + 10 * v),)
   """, sig="solve(data)", names=["data"],
   hints=["`ax.boxplot` returns a dict with keys like `medians`, `boxes`, `whiskers`.",
          "The median line sits inside the box."])

pq("Step plot",
   "Plot `y` against `x` as a step plot (`ax.step`). Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.step(x, y)
   return ax
   """,
   ["""ax = _got
   assert len(ax.lines) == 1
   assert ax.lines[0].get_drawstyle().startswith('steps')"""],
   ["line"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["Step plots keep the value constant between samples.",
          "Useful for digital signals and histograms."])

pq("Stem plot",
   "Draw a stem plot of `y` against `x` and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.stem(x, y)
   return ax
   """,
   ["assert len(_got.collections) >= 1, 'stem adds a LineCollection'"],
   ["line"], mk="""
   x = np.arange(4 + v)
   return (x, np.array([1.0, 0.0, 2.0, 0.5, 3.0, 1.5, 2.5])[:len(x)])
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["Stem plots show discrete samples as vertical lines.",
          "The markers are a separate Line2D."])

pq("Error bars",
   "Plot `y` against `x` with vertical error bars `err` using `ax.errorbar`. Return the "
   "Axes.",
   """
   fig, ax = plt.subplots()
   ax.errorbar(x, y, yerr=err, fmt='o')
   return ax
   """,
   ["assert len(_got.containers) == 1, 'errorbar adds one container'"],
   ["errorbar"], mk="""
   x = np.arange(4 + v)
   return (x, x ** 2.0, 0.2 + 0.1 * x)
   """, sig="solve(x, y, err)", names=["x", "y", "err"],
   hints=["`yerr=` sets symmetric error bars.",
          "`fmt='o'` draws markers without a connecting line."])

pq("Contour plot",
   "Draw a contour plot of `z` over the grid (`x`, `y`) with 5 levels. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.contour(x, y, z, levels=5)
   return ax
   """,
   ["assert len(_got.collections) >= 1, 'contour creates collections'"],
   ["contour"], mk="""
   x = np.linspace(-2, 2, 10)
   y = np.linspace(-2, 2, 10)
   X, Y = np.meshgrid(x, y)
   return (x, y, X ** 2 + Y ** 2)
   """, sig="solve(x, y, z)", names=["x", "y", "z"],
   hints=["`contour` draws iso-lines of a 2-D field.",
          "`contourf` fills the regions instead."])

pq("Quiver plot",
   "Draw a quiver plot of the vector field `(u, v)` on the grid `(X, Y)`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.quiver(X, Y, u, v)
   return ax
   """,
   ["assert len(_got.collections) == 1, 'quiver adds one collection'"],
   ["quiver"], mk="""
   X, Y = np.meshgrid(np.arange(3), np.arange(3))
   return (X, Y, np.ones_like(X), np.zeros_like(Y))
   """, sig="solve(X, Y, u, v)", names=["X", "Y", "u", "v"],
   hints=["Each arrow starts at `(X, Y)` with direction `(u, v)`.",
          "Arrow length is scaled automatically."])

pq("3-D line plot",
   "Create a 3-D axes and plot the parametric curve `(x, y, z)`. Return the 3-D Axes.",
   """
   fig = plt.figure()
   ax = fig.add_subplot(111, projection='3d')
   ax.plot(x, y, z)
   return ax
   """,
   ["""ax = _got
   assert ax.name == '3d', "the axes must be 3-D"
   assert len(ax.lines) == 1"""],
   ["3d"], mk="""
   t = np.linspace(0, 6, 20 + v)
   return (t, np.cos(t), np.sin(t))
   """, sig="solve(x, y, z)", names=["x", "y", "z"],
   hints=["`fig.add_subplot(projection='3d')` creates 3-D axes.",
          "`ax.plot(x, y, z)` draws the curve."])

pq("Save a figure to disk",
   "Plot `y` against `x` and save the figure as `path` with `fig.savefig`. Return the "
   "path.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   fig.savefig(path)
   plt.close(fig)
   return path
   """,
   ["""
   import os
   assert os.path.exists(_got), "the file must exist"
   assert os.path.getsize(_got) > 500, "the PNG looks empty"
   """],
   ["savefig"], mk="""
   import os, tempfile
   path = os.path.join(tempfile.mkdtemp(), 'fig.png')
   x = np.arange(5 + v)
   return (x, x ** 2.0, path)
   """, sig="solve(x, y, path)", names=["x", "y", "path"],
   hints=["`fig.savefig(path)` writes the rendered image.",
          "Call it **before** closing the figure."])

pq("Subplot spacing",
   "Create a 1x2 subplot grid and call `fig.tight_layout()` so the labels don't overlap. "
   "Return the Figure.",
   """
   fig, axes = plt.subplots(1, 2)
   for ax in axes:
       ax.plot(x, y)
       ax.set_xlabel('time')
   fig.tight_layout()
   return fig
   """,
   ["assert len(_got.axes) == 2, 'both subplots must survive tight_layout'"],
   ["layout"], mk="""
   x = np.arange(4 + v)
   return (x, x ** 2.0)
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`tight_layout` adjusts the padding between axes.",
          "Call it after adding all labels."])

# =========================================================================== #
#  More chart types & styling
# =========================================================================== #
pq("Line width",
   "Plot `y` against `x` with a line width of 3. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, linewidth=3)
   return ax
   """,
   ["assert abs(_got.lines[0].get_linewidth() - 3) < 1e-6"],
   ["style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`linewidth` (or `lw`) is measured in points.",
          "Thicker lines read better in slides."])

pq("Dotted grid",
   "Plot `y` against `x` and enable a dotted grid (`linestyle=':'`). Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.grid(True, linestyle=':')
   return ax
   """,
   ["""ax = _got
   assert ax.get_xgridlines()[0].get_visible()
   assert ax.get_xgridlines()[0].get_linestyle() in (':', 'dotted')"""],
   ["grid", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`grid` forwards keyword arguments to the grid lines.",
          "Dotted grids are less visually dominant."])

pq("Legend without frame",
   "Plot `y` against `x` with label `'v'` and show a legend without a frame. Return the "
   "Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, label='v')
   ax.legend(frameon=False)
   return ax
   """,
   ["assert _got.get_legend().get_frame_on() is False"],
   ["legend", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`frameon=False` removes the legend box.",
          "Cleaner for minimal designs."])

pq("Tick label size",
   "Plot `y` against `x` and set the tick label font size to 14. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.tick_params(labelsize=14)
   return ax
   """,
   ["assert abs(_got.get_xticklabels()[0].get_fontsize() - 14) < 1e-6"],
   ["ticks", "style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.tick_params` styles both axes at once.",
          "`labelsize` is in points."])

pq("Minor ticks",
   "Plot `y` against `x` and turn the minor ticks on. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.minorticks_on()
   return ax
   """,
   ["assert len(_got.xaxis.get_minorticklocs()) > 0, 'no minor ticks found'"],
   ["ticks"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.minorticks_on()` enables the minor locators.",
          "`grid(which='minor')` shows grid lines for them too."])

pq("Hide the axes",
   "Plot `y` against `x` and hide the whole axes frame and ticks with `set_axis_off`. "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_axis_off()
   return ax
   """,
   ["assert _got.axison is False"],
   ["style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.set_axis_off()` hides spines, ticks and labels.",
          "Useful for image grids."])

pq("Equal aspect ratio",
   "Plot a circle-ish curve (`cos(t)`, `sin(t)`) and force an equal aspect ratio. Return "
   "the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(np.cos(t), np.sin(t))
   ax.set_aspect('equal')
   return ax
   """,
   ["assert abs(float(_got.get_aspect()) - 1.0) < 1e-6"],
   ["style"], mk="""
   t = np.linspace(0, 2 * np.pi, 40 + v)
   return (t,)
   """, sig="solve(t)", names=["t"],
   hints=["`set_aspect('equal')` makes one unit match on both axes.",
          "Circles only look round with an equal aspect."])

pq("Log-log plot",
   "Plot `y` against `x` on log-log axes using `ax.loglog`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.loglog(x, y)
   return ax
   """,
   ["""ax = _got
   assert ax.get_xscale() == 'log' and ax.get_yscale() == 'log'"""],
   ["scale"], mk="""
   x = np.logspace(0, 3, 10 + v)
   return (x, x ** 2)
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`loglog` sets both axes to log scale.",
          "Power laws appear as straight lines."])

pq("Semilog-x plot",
   "Plot `y` against `x` with a logarithmic x-axis only (`ax.semilogx`). Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.semilogx(x, y)
   return ax
   """,
   ["""ax = _got
   assert ax.get_xscale() == 'log'
   assert ax.get_yscale() == 'linear'"""],
   ["scale"], mk="""
   x = np.logspace(0, 2, 6 + v)
   return (x, np.log(x))
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`semilogx` only changes the x-axis.",
          "Useful for frequency responses."])

pq("Cumulative histogram",
   "Plot a **cumulative** histogram of `data` with 8 bins. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.hist(data, bins=8, cumulative=True, density=True)
   return ax
   """,
   ["""ax = _got
   heights = [p.get_height() for p in ax.patches]
   assert len(heights) == 8
   assert heights[-1] > 0.99, "a cumulative density ends at 1"
   assert all(h2 >= h1 - 1e-9 for h1, h2 in zip(heights, heights[1:])), "must be non-decreasing"
   """],
   ["hist"], mk="""
   return (np.random.randn(60 + 10 * v),)
   """, sig="solve(data)", names=["data"],
   hints=["`cumulative=True` accumulates the counts.",
          "`density=True` normalises so the last bar is 1."])

pq("Coloured scatter with a colormap",
   "Scatter `y` against `x` colouring each point by the values `c` with `cmap='viridis'`. "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   sc = ax.scatter(x, y, c=c, cmap='viridis')
   return ax
   """,
   ["""coll = _got.collections[0]
   assert coll.get_cmap().name == 'viridis'
   assert coll.get_array() is not None and np.allclose(coll.get_array(), _args[2])"""],
   ["scatter"], mk="""
   x = np.arange(8 + v)
   return (x, x ** 2.0, x * 0.5)
   """, sig="solve(x, y, c)", names=["x", "y", "c"],
   hints=["`c=` maps values through the colormap.",
          "Add `fig.colorbar(sc)` to explain the scale."])

pq("Hexbin density",
   "Draw a hexagonal-bin density plot of `x`/`y` with `ax.hexbin`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.hexbin(x, y, gridsize=10)
   return ax
   """,
   ["assert len(_got.collections) == 1, 'hexbin adds one PolyCollection'"],
   ["scatter"], mk="""
   x = np.random.randn(100 + 10 * v)
   return (x, np.random.randn(len(x)))
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["Hexbin aggregates dense scatter data into hexagons.",
          "Good alternative to a 2-D histogram."])

pq("Violin plot",
   "Draw a violin plot of `data` with `ax.violinplot` and return the dict it produces.",
   """
   fig, ax = plt.subplots()
   return ax.violinplot(data)
   """,
   ["assert 'bodies' in _got, 'violinplot returns a dict with bodies'",
    "assert len(_got['bodies']) == 1"],
   ["boxplot"], mk="""
   return (np.random.randn(50 + 10 * v),)
   """, sig="solve(data)", names=["data"],
   hints=["A violin shows the full distribution shape.",
          "`showmedians=True` adds median lines."])

pq("Stacked area chart",
   "Draw a stackplot of the two series `y1` and `y2` against `x` and return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.stackplot(x, y1, y2)
   return ax
   """,
   ["assert len(_got.collections) == 2, 'one filled area per series'"],
   ["fill"], mk="""
   x = np.arange(5 + v)
   return (x, x + 1.0, x * 0.5 + 1.0)
   """, sig="solve(x, y1, y2)", names=["x", "y1", "y2"],
   hints=["`stackplot` fills and stacks the areas.",
          "Useful for parts-of-a-whole over time."])

pq("Arrow annotation",
   "Plot `y` against `x` and draw an arrow from `(1, 1)` to `(3, 9)` with `ax.arrow`. "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.arrow(1, 1, 2, 8, head_width=0.3)
   return ax
   """,
   ["assert len(_got.patches) == 1, 'ax.arrow adds one FancyArrow patch'"],
   ["annotate"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`ax.arrow(x, y, dx, dy)` takes a *delta*, not an end point.",
          "`annotate` is more flexible for labelling data."])

pq("Horizontal span",
   "Plot `y` against `x` and highlight the y-range 2 to 4 with `axhspan`. Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.axhspan(2, 4, alpha=0.2)
   return ax
   """,
   ["assert len(_got.patches) == 1"],
   ["reference"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`axhspan(y0, y1)` shades a horizontal band.",
          "Pair it with `axhline` for a target range."])

pq("Figure-level legend",
   "Plot `y` against `x` with label `'series'` and add a **figure-level** legend "
   "(`fig.legend()`). Return the Figure.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y, label='series')
   fig.legend()
   return fig
   """,
   ["legs = _got.legends", "assert len(legs) == 1, 'fig.legend stores the legend on the figure'",
    "assert legs[0].get_texts()[0].get_text() == 'series'"],
   ["legend"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`fig.legend()` lives on the Figure, outside the axes.",
          "Handy when several subplots share one legend."])

pq("Move the bottom spine",
   "Plot `y` against `x` and move the bottom spine to the data position 0 "
   "(`set_position('zero')`). Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.spines['bottom'].set_position('zero')
   return ax
   """,
   ["assert _got.spines['bottom'].get_position() == 'zero'"],
   ["spines"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["Spines can sit at data coordinates.",
          "This mimics textbook axes crossing at the origin."])

pq("Custom tick formatter",
   "Plot `y` against `x` and format the y tick labels with one decimal place using "
   "`StrMethodFormatter('{x:.1f}')`. Return the Axes.",
   """
   from matplotlib.ticker import StrMethodFormatter
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.yaxis.set_major_formatter(StrMethodFormatter('{x:.1f}'))
   return ax
   """,
   ["""labels = [t.get_text() for t in _got.get_yticklabels() if t.get_text()]
   assert len(labels) > 0
   assert all(len(l.split('.')[-1]) == 1 for l in labels), f"labels were {labels}"
   """],
   ["ticks"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`StrMethodFormatter` uses the `str.format` mini-language.",
          "`FuncFormatter` accepts a plain callable instead."])

pq("Share the y axis",
   "Create two stacked subplots sharing the y-axis, plot `y` in both, and return the "
   "Figure.",
   """
   fig, axes = plt.subplots(2, 1, sharey=True)
   axes[0].plot(x, y)
   axes[1].plot(x, y)
   return fig
   """,
   ["""fig = _got
   assert len(fig.axes) == 2
   assert fig.axes[0].get_shared_y_axes().joined(fig.axes[0], fig.axes[1])"""],
   ["subplots"], mk="""
   x = np.arange(4 + v)
   return (x, x ** 2.0)
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`sharey=True` links the y limits of the stack.",
          "Great for comparing signals on the same scale."])

pq("Constrained layout",
   "Create a 1x3 subplot grid with `layout='constrained'` and plot `y` in each. Return "
   "the Figure.",
   """
   fig, axes = plt.subplots(1, 3, layout='constrained')
   for ax in axes:
       ax.plot(x, y)
   return fig
   """,
   ["assert len(_got.axes) == 3, 'three subplots expected'"],
   ["layout"], mk="""
   x = np.arange(4 + v)
   return (x, x ** 2.0)
   """, sig="solve(x, y)", names=["x", "y"],
   hints=["`layout='constrained'` keeps labels from overlapping.",
          "It replaces the older `tight_layout` call."])

pq("Set the axes face colour",
   "Plot `y` against `x` and set the axes background to light grey (`'#eeeeee'`). "
   "Return the Axes.",
   """
   fig, ax = plt.subplots()
   ax.plot(x, y)
   ax.set_facecolor('#eeeeee')
   return ax
   """,
   ["""
   from matplotlib.colors import to_hex
   assert to_hex(_got.get_facecolor()) == '#eeeeee'
   """],
   ["style"], mk=LINEDATA, sig="solve(x, y)", names=["x", "y"],
   hints=["`set_facecolor` colours the plotting area.",
          "Hex colours and names both work."])
