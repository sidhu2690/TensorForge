#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Build dist/TensorForge.exe on a Linux box, without a Windows machine.
#
# PyInstaller cannot cross-compile, so this runs *Windows* CPython + PyInstaller
# under Wine and produces a genuine PE32+ executable.
#
# Requirements (Debian/Ubuntu):
#   sudo apt-get install wine wine64 xvfb cabextract
#   ~3 GB of disk in $HOME/.cache/winebuild
#
# Usage:
#   tools/build_windows_on_linux.sh
# ---------------------------------------------------------------------------
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CACHE="${WINEBUILD_CACHE:-$HOME/.cache/winebuild}"
export WINEPREFIX="$CACHE/prefix"
export WINEDEBUG=-all
export KMP_AFFINITY=disabled          # torch/oneDNN cannot read NUMA topology under Wine

PY_VER="3.12.10"
PY_DIR="$WINEPREFIX/drive_c/PyFull/tools"
WORK="$WINEPREFIX/drive_c/build/tf"

mkdir -p "$CACHE"

step() { printf "\n\033[1;36m==> %s\033[0m\n" "$*"; }

# --- 1. Wine prefix -------------------------------------------------------
if [ ! -d "$WINEPREFIX" ]; then
    step "Creating a 64-bit Wine prefix"
    xvfb-run -a wineboot -i >/dev/null 2>&1 || true
fi
[ -d "$WINEPREFIX" ] || { echo "wineboot failed"; exit 1; }

# --- 2. Windows CPython ---------------------------------------------------
if [ ! -x "$PY_DIR/python.exe" ]; then
    step "Fetching Windows CPython $PY_VER (nuget build, includes tkinter/ensurepip)"
    curl -sSL -o "$CACHE/python-nuget.zip" \
        "https://api.nuget.org/v3-flatcontainer/python/$PY_VER/python.$PY_VER.nupkg"
    rm -rf "$WINEPREFIX/drive_c/PyFull"
    mkdir -p "$WINEPREFIX/drive_c/PyFull"
    ( cd "$WINEPREFIX/drive_c/PyFull" && unzip -qo "$CACHE/python-nuget.zip" )
fi

# --- 3. MSVC runtime ------------------------------------------------------
# torch's DLLs link against the VC++ runtime. Wheel-provided copies are enough
# for both the build interpreter and the frozen app.
if [ ! -f "$PY_DIR/msvcp140.dll" ]; then
    step "Fetching the MSVC runtime (msvc-runtime wheel)"
    ( cd "$PY_DIR" && wine python.exe -m pip install -q --no-warn-script-location msvc-runtime )
fi

# --- 4. Python dependencies ----------------------------------------------
if [ ! -d "$PY_DIR/Lib/site-packages/torch" ]; then
    step "Installing Flask, NumPy, Matplotlib, PyInstaller"
    ( cd "$PY_DIR" && wine python.exe -m pip install -q --no-warn-script-location \
        "flask>=3.0" "numpy>=2.0" "matplotlib>=3.8" "pillow>=10.0" "pyinstaller>=6.6" )

    step "Installing torch (CPU wheel, ~200 MB)"
    ( cd "$PY_DIR" && wine python.exe -m pip install -q --no-warn-script-location \
        torch --index-url https://download.pytorch.org/whl/cpu )
fi

# --- 5. Wine fix-up for PyInstaller's isolated subprocesses -----------------
# Wine does not implement STARTUPINFOEX handle_list inheritance, which
# PyInstaller uses to hand pipe handles to its scratch processes. Falling back
# to inheritable handles works fine.
PARENT_PY="$PY_DIR/Lib/site-packages/PyInstaller/isolated/_parent.py"
if ! grep -q "Wine does not implement STARTUPINFOEX" "$PARENT_PY"; then
    step "Patching PyInstaller's isolated._parent for Wine"
    python3 - "$PARENT_PY" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
s = s.replace('''        extra_kwargs = {
            "env": _subprocess_env(),
            "close_fds": True,
            "startupinfo": subprocess.STARTUPINFO(lpAttributeList={"handle_list": [read_from_parent, write_to_parent]})
        }''', '''        # Wine does not implement STARTUPINFOEX handle_list inheritance; plain
        # close_fds=False works because the pipe handles are inheritable.
        extra_kwargs = {
            "env": _subprocess_env(),
            "close_fds": False,
        }''')
open(p, "w").write(s)
PY
fi

# --- 6. Build -------------------------------------------------------------
step "Copying the project into the Wine prefix"
rm -rf "$WORK"
mkdir -p "$WORK"
cp -r "$ROOT"/{app.py,runner.py,tensorforge.spec,hooks,bank,templates,build_assets,static_favicon.png} "$WORK"/

step "Running PyInstaller (5-10 minutes)"
( cd "$WORK" && xvfb-run -a wine C:/PyFull/tools/python.exe -m PyInstaller \
    tensorforge.spec --noconfirm --clean --log-level WARN )

step "Copying the result"
mkdir -p "$ROOT/dist"
cp "$WORK/dist/TensorForge.exe" "$ROOT/dist/TensorForge.exe"
ls -lh "$ROOT/dist/TensorForge.exe"
echo
echo "Done. Run it on Windows by double-clicking; it opens http://127.0.0.1:8765"
