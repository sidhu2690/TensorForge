"""
TensorForge question-bank DSL.

Every problem is authored as a *spec*.  From a spec we generate:

  * a prompt (markdown, with an auto-generated worked example)
  * starter code
  * a reference solution (used for "reveal" + as the oracle in tests)
  * one or more executable checks:
        - "cases"  : N randomized / tabulated cases compared to the reference
        - "script" : bespoke assertion blocks (properties, API usage, plots ...)
  * a stable id, concept grouping, difficulty, tags, hints

The generated JSON is consumed by the Flask app (`app.py`), which executes the
user's code against the same checks inside an isolated worker subprocess.
"""
from __future__ import annotations

import json
import random
import re
import textwrap

# --------------------------------------------------------------------------- #
#  Library registry
# --------------------------------------------------------------------------- #
LIB_IMPORTS = {
    "np": "import numpy as np",
    "F": "import torch.nn.functional as F",
    "nn": "import torch.nn as nn",
    "torch": "import torch",
    "plt": (
        "import matplotlib\n"
        "matplotlib.use('Agg')\n"
        "import matplotlib.pyplot as plt\n"
        "plt.show = lambda *a, **k: None\n"
    ),
}
TOPIC_IMPORTS = {
    "python": "",
    "numpy": "import numpy as np\n",
    "torch": "import torch\n",
    "matplotlib": (
        "import numpy as np\n"
        "import matplotlib\n"
        "matplotlib.use('Agg')\n"
        "import matplotlib.pyplot as plt\n"
        "plt.show = lambda *a, **k: None\n"
    ),
}
TOPIC_LIBS = {"python": [], "numpy": ["np"], "torch": ["torch", "np"], "matplotlib": ["plt", "np"]}
PREFIX = {"python": "py", "numpy": "np", "torch": "pt", "matplotlib": "mpl"}
DEFAULT_FOCUS = ["core cases", "edge cases", "larger / varied inputs", "stress & corner cases",
                 "mixed shapes", "final mix"]

BANK: list[dict] = []
_COUNTERS: dict[str, int] = {}


# --------------------------------------------------------------------------- #
#  Helpers
# --------------------------------------------------------------------------- #
def slug(s: str, maxlen: int = 44) -> str:
    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s[:maxlen].rstrip("-")


def _needs(source: str, token: str) -> bool:
    return re.search(r"\b" + token + r"\b", source or "") is not None


_TOPLEVEL = re.compile(r"^\s*(def|class|import|from|@)")


def _norm(code: str) -> str:
    """Normalise a code snippet: uniform dedent, tolerant of an inline first line."""
    code = code.replace("\r\n", "\n")
    lines = code.split("\n")
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    if not lines:
        return ""
    ind = [len(l) - len(l.lstrip()) for l in lines if l.strip()]
    m = min(ind)
    if m == 0 and len(lines) > 1 and not _TOPLEVEL.match(lines[0]):
        # style: `cases = [...]` on the first line, continuation lines indented
        rest = [len(l) - len(l.lstrip()) for l in lines[1:] if l.strip()]
        m = min(rest) if rest else 0
        out = [lines[0]] + [l[m:] if l.strip() else "" for l in lines[1:]]
        return "\n".join(out)
    return "\n".join(l[m:] if l.strip() else "" for l in lines)


def _indent(code: str, spaces: int = 4) -> str:
    return textwrap.indent(code, " " * spaces)


def _solution_source(sig: str, sol: str, imports: str = "") -> str:
    """`sol` may be a body (indented under the given signature) or a full source."""
    head = imports or ""
    if re.search(r"^\s*(def|class)\s+solve\b", sol, re.M):
        return head + _norm(sol)
    return head + f"def {sig}:\n{_indent(_norm(sol), 4)}"


def _starter_source(sig: str, starter: str | None, imports: str) -> str:
    if starter is None:
        body = f"def {sig}:\n    # TODO: write your implementation\n    pass\n"
    else:
        body = _norm(starter) + "\n"
    head = imports or ""
    return head + body


# --------------------------------------------------------------------------- #
#  Test-harness generator
# --------------------------------------------------------------------------- #
PROLOG = r'''
# ======================= auto-generated test harness =======================
import copy, math, random, warnings
import numpy as np
import numpy as _np
warnings.filterwarnings("ignore")
{libs}
np.seterr(all="ignore")

_SEED   = {seed}
_V      = {variant}
_N      = {ncases}
_STRICT = {strict}
_MUT    = {mut}
_RETLESS = {retless}

import types as _types, sys as _sys
_SOLUTION_SRC = {sol_src!r}
_ref_mod = _types.ModuleType("_tf_ref_mod")
_sys.modules["_tf_ref_mod"] = _ref_mod
_ref_mod.__dict__.update({{k: v for k, v in globals().items() if k not in ("solve", "__builtins__", "__name__")}})
exec(_SOLUTION_SRC, _ref_mod.__dict__)
_ref = _ref_mod.__dict__.get("solve")

def _mk(v, i):
    s = int((_SEED + 7919 * v + 104729 * i + 17) % (2 ** 31 - 1))
    np.random.seed(s)
    random.seed(s)
    try:
        torch.manual_seed(s)
    except Exception:
        pass
{mk}

def _state(o):
    try:
        import torch as _t
        if isinstance(o, _t.Tensor):
            return ("T", str(o.dtype), tuple(o.shape), o.detach().clone())
        if isinstance(o, _t.nn.Module):
            return ("M", tuple((k, _state(v)) for k, v in sorted(o.state_dict().items())))
    except Exception:
        pass
    if isinstance(o, np.ndarray):
        return ("A", str(o.dtype), tuple(o.shape), o.copy())
    if isinstance(o, (list, tuple)):
        return (type(o).__name__, tuple(_state(x) for x in o))
    if isinstance(o, dict):
        return ("D", tuple((str(k), _state(x)) for k, x in sorted(o.items(), key=lambda kv: str(kv[0]))))
    return ("V", o)

def _cmp_states(sa, sb, path="return value", tol=1e-5):
    ka = sa[0]
    if ka != sb[0]:
        return False, "%s: expected %s, got %s" % (path, ka, sb[0])
    if ka == "T":
        da, sha, ta = sa[1], sa[2], sa[3]
        db, shb, tb = sb[1], sb[2], sb[3]
        if tuple(sha) != tuple(shb):
            return False, "%s: expected tensor of shape %s, got shape %s" % (path, tuple(sha), tuple(shb))
        if _STRICT and da != db:
            return False, "%s: expected dtype %s, got %s" % (path, da, db)
        import torch as _t
        if ta.shape != tb.shape:
            return False, "%s: shape mismatch %s vs %s" % (path, tuple(ta.shape), tuple(tb.shape))
        if ta.is_floating_point() or ta.is_complex():
            if not _t.allclose(ta.to(tb.dtype) if ta.dtype != tb.dtype else ta, tb, rtol=1e-4, atol=1e-5, equal_nan=True):
                d = (ta.float() - tb.float()).abs().max().item() if ta.numel() else 0.0
                return False, "%s: values differ (max abs diff %.3g)" % (path, d)
        else:
            if not _t.equal(ta, tb):
                return False, "%s: values differ" % path
        return True, ""
    if ka == "A":
        da, sha, aa = sa[1], sa[2], sa[3]
        db, shb, ab = sb[1], sb[2], sb[3]
        if tuple(sha) != tuple(shb):
            return False, "%s: expected array of shape %s, got shape %s" % (path, tuple(sha), tuple(shb))
        if _STRICT and da != db:
            return False, "%s: expected dtype %s, got %s" % (path, da, db)
        if aa.shape != ab.shape:
            return False, "%s: shape mismatch" % path
        if aa.dtype.kind in "fc" or ab.dtype.kind in "fc":
            if not np.allclose(aa, ab, rtol=1e-4, atol=1e-6, equal_nan=True):
                d = np.nanmax(np.abs(aa.astype(float) - ab.astype(float))) if aa.size else 0.0
                return False, "%s: values differ (max abs diff %.3g)" % (path, d)
        else:
            if not np.array_equal(aa, ab):
                return False, "%s: values differ" % path
        return True, ""
    if ka == "M":
        da, db = dict(sa[1]), dict(sb[1])
        if set(da) != set(db):
            return False, "%s: state_dict keys differ" % path
        for k in da:
            ok, m = _cmp_states(da[k], db[k], path + "." + k, tol)
            if not ok:
                return False, m
        return True, ""
    if ka in ("list", "tuple"):
        a, b = sa[1], sb[1]
        if len(a) != len(b):
            return False, "%s: expected %d items, got %d" % (path, len(a), len(b))
        for j, (x, y) in enumerate(zip(a, b)):
            ok, m = _cmp_states(x, y, "%s[%d]" % (path, j), tol)
            if not ok:
                return False, m
        return True, ""
    if ka == "D":
        da, db = dict(sa[1]), dict(sb[1])
        if set(da) != set(db):
            return False, "%s: expected keys %s, got %s" % (path, sorted(da), sorted(db))
        for k in da:
            ok, m = _cmp_states(da[k], db[k], "%s[%r]" % (path, k), tol)
            if not ok:
                return False, m
        return True, ""
    va, vb = sa[1], sb[1]
    if va is None or vb is None:
        if va is vb:
            return True, ""
        return False, "%s: expected %r, got %r" % (path, _short(va), _short(vb))
    _dtype_like = (_np.dtype, type)
    if isinstance(va, _dtype_like) and isinstance(vb, _dtype_like):
        try:
            if _np.dtype(va) == _np.dtype(vb):
                return True, ""
        except Exception:
            pass
        return False, "%s: expected dtype %r, got %r" % (path, va, vb)
    if type(va) is not type(vb):
        return False, "%s: expected %s, got %s" % (path, type(va).__name__, type(vb).__name__)
    if isinstance(va, float) or isinstance(vb, float):
        try:
            if math.isnan(va) and math.isnan(vb):
                return True, ""
            if math.isclose(float(va), float(vb), rel_tol=1e-6, abs_tol=1e-8):
                return True, ""
        except Exception:
            pass
        return False, "%s: expected %r, got %r" % (path, va, vb)
    if isinstance(va, np.floating) or isinstance(vb, np.floating):
        if np.isclose(va, vb, rtol=1e-6, atol=1e-8):
            return True, ""
        return False, "%s: expected %r, got %r" % (path, va, vb)
    if va == vb:
        return True, ""
    return False, "%s: expected %r, got %r" % (path, _short(va), _short(vb))

def _short(x, n=120):
    try:
        r = repr(x)
    except Exception:
        r = "<object>"
    return r if len(r) <= n else r[:n] + "..."

def _case(i):
    ra = _mk(_V, i)
    if not isinstance(ra, tuple):
        raise AssertionError("internal: _mk must return a tuple of arguments")
    exp = _ref(*ra)
    sref = _state(ra) if _MUT else None
    ua = _mk(_V, i)
    got = solve(*ua)
    susr = _state(ua) if _MUT else None
    if not _RETLESS:
        ok, msg = _cmp_states(_state(exp), _state(got))
        if not ok:
            raise AssertionError("case %d: %s" % (i + 1, msg))
    if _MUT:
        ok, msg = _cmp_states(sref, susr, path="state after your call")
        if not ok:
            raise AssertionError("case %d: %s" % (i + 1, msg))
'''


def _libs_block(libs: list[str]) -> str:
    seen, out = set(), []
    for name in libs:
        if name in seen:
            continue
        seen.add(name)
        out.append(LIB_IMPORTS[name])
    return "\n".join(out)


def _detect_libs(item: dict) -> list[str]:
    libs = list(TOPIC_LIBS[item["topic"]])
    text = " ".join([item["solution"], item["mk"], " ".join(item.get("props", []))])
    if _needs(text, "torch") and "torch" not in libs:
        libs.append("torch")
    if re.search(r"\bF\.", text) and "F" not in libs:
        libs.append("F")
    if re.search(r"\bnn\.", text) and "nn" not in libs:
        libs.append("nn")
    if (_needs(text, "plt") or "matplotlib" in text) and "plt" not in libs:
        libs.append("plt")
    if _needs(text, "np") and "np" not in libs:
        libs.append("np")
    return libs


def build_checks(item: dict) -> list[dict]:
    libs = _detect_libs(item)
    sol_src = item["solution"]
    prolog = PROLOG.format(
        libs=_libs_block(libs),
        seed=item["seed"],
        variant=item["inst"],
        ncases=item["ncases"],
        strict="True" if item.get("strict", True) else "False",
        mut="True" if item["cmp"] == "mut" else "False",
        retless="True" if item["cmp"] in ("mut", "none") else "False",
        sol_src=sol_src,
        mk=_indent(item["mk"], 4),
    )
    checks = []
    if item["cmp"] != "none":
        checks.append({
            "name": "Test cases",
            "kind": "cases",
            "n": item["ncases"],
            "source": prolog,
        })
    else:
        checks.append({
            "name": "Smoke run",
            "kind": "cases",
            "n": 0,
            "source": prolog + (
                "\n\nfor _i in range(3):\n"
                "    _args = _mk(_V, _i)\n"
                "    solve(*_args)\n"
            ),
        })
    if item.get("props"):
        prop_body = "\n".join(item["props"])
        # Indented one level so we can wrap it in a function and use locals.
        prop_src = prolog + (
            "\n\ndef _props():\n"
            "    _args = _mk(_V, 0)\n"
            "    _got = solve(*_args)\n"
            + _indent(prop_body, 4)
            + "\n\n_props()\n"
        )
        checks.append({
            "name": "Property / quality checks",
            "kind": "script",
            "n": 1,
            "source": prop_src,
        })
    return checks


# --------------------------------------------------------------------------- #
#  Example generator (runs the reference once at build time)
# --------------------------------------------------------------------------- #
_SHOW_LIMIT = 240


def _fmt(obj, depth=0) -> str:
    try:
        import numpy as _np
        try:
            import torch as _t
        except Exception:
            _t = None
        if _t is not None and isinstance(obj, _t.Tensor):
            body = _np.array2string(obj.detach().cpu().numpy(), precision=3, threshold=24,
                                    edgeitems=3, max_line_width=100, separator=", ")
            return f"tensor({body}, dtype={obj.dtype})" if obj.dim() else f"tensor({obj.item():.4g})"
        if isinstance(obj, _np.ndarray):
            body = _np.array2string(obj, precision=3, threshold=24, edgeitems=3,
                                    max_line_width=100, separator=", ")
            return f"array({body})"
        if isinstance(obj, float):
            return f"{obj:.6g}"
        if isinstance(obj, (int, bool, str)) or obj is None:
            return repr(obj)
        if isinstance(obj, (list, tuple)) and depth < 2:
            inner = ", ".join(_fmt(x, depth + 1) for x in obj[:6])
            more = ", ..." if len(obj) > 6 else ""
            return f"[{inner}{more}]" if isinstance(obj, list) else f"({inner}{more})"
        if isinstance(obj, dict) and depth < 2:
            inner = ", ".join(f"{k!r}: {_fmt(v, depth + 1)}" for k, v in list(obj.items())[:5])
            return "{" + inner + "}"
        r = repr(obj)
        return r if len(r) <= _SHOW_LIMIT else r[:_SHOW_LIMIT] + " ..."
    except Exception:
        return "<value>"


def make_example(item: dict, checks: list[dict]) -> str | None:
    if item["cmp"] in ("mut", "none") or item.get("no_example"):
        return None
    try:
        ns: dict = {"__name__": "_ex"}
        exec(checks[0]["source"], ns)
        ns["np"].random.seed(item["seed"] + 5)
        args = ns["_mk"](0, 0)
        res = ns["_ref"](*args)
        names = item.get("arg_names") or []
        parts = []
        for j, a in enumerate(args):
            label = names[j] if j < len(names) else f"arg{j + 1}"
            parts.append(f"{label} = {_fmt(a)}")
        inp = "\n".join(parts) if parts else "(no arguments)"
        out = _fmt(res)
        if len(inp) > 700 or len(out) > 500:
            return None
        return f"**Input**\n```python\n{inp}\n```\n**Expected output**\n```python\n{out}\n```"
    except Exception:
        return None
    finally:
        try:
            import matplotlib.pyplot as _plt
            _plt.close("all")
        except Exception:
            pass


# --------------------------------------------------------------------------- #
#  Public authoring API
# --------------------------------------------------------------------------- #
def q(*, topic, diff, tags, title, ask, sig, sol, mk, ncases=4, props=(), hints=(),
      strict=True, cmp="auto", variants=3, starter=None, imports=None,
      arg_names=(), focus=None, no_example=False, notes="", seed=None):
    """Register a problem concept (+ its instances/variants) into the bank."""
    assert topic in PREFIX, topic
    assert diff in ("easy", "medium", "hard"), diff
    seed = seed if seed is not None else (abs(hash(slug(title) + topic)) % 90000 + 1000)
    imports = TOPIC_IMPORTS[topic] if imports is None else imports
    concept = f"{PREFIX[topic]}-{slug(title)}"
    base_title = title
    for v in range(max(1, variants)):
        # unique id: concept slug + instance number
        _COUNTERS[concept] = _COUNTERS.get(concept, 0) + 1
        item_id = f"{concept}-{_COUNTERS[concept]}"
        item = {
            "id": item_id,
            "concept": concept,
            "inst": v,
            "topic": topic,
            "difficulty": diff,
            "tags": list(tags),
            "title": base_title,
            "ask": textwrap.dedent(ask).strip(),  # markdown, keep as authored
            "sig": sig,
            "mk": _norm(mk),
            "props": [_norm(p) for p in props],
            "hints": list(hints) or [
                "Read the function signature and the expected output shape carefully.",
                "Try the simplest working version first, then call Run tests.",
            ],
            "strict": strict,
            "cmp": cmp,
            "ncases": ncases,
            "seed": seed + v * 13,
            "arg_names": list(arg_names),
            "focus": (focus[v] if focus else DEFAULT_FOCUS[v % len(DEFAULT_FOCUS)]) if variants > 1 else "core cases",
            "notes": notes,
            "weak": cmp == "none",
            "solution": _solution_source(sig, sol, imports),
            "starter": _starter_source(sig, starter, imports),
        }
        BANK.append(item)


def finalize() -> dict:
    """Build checks / examples and return the manifest."""
    out: dict[str, list] = {}
    errors = []
    for item in BANK:
        try:
            checks = build_checks(item)
            item["checks"] = checks
            item["libs"] = _detect_libs(item)
            item["example"] = make_example(item, checks)
        except Exception as exc:  # pragma: no cover
            errors.append((item["id"], repr(exc)))
            continue
        out.setdefault(item["topic"], []).append(item)
    if errors:
        raise SystemExit("Failed to build checks for: %s" % errors[:5])
    return out


def auto(*, topic, diff, title, ask, args, op, tags=(), variants=3, props=(), hints=(),
         strict=True, cmp="auto", starter=None, imports=None, arg_names=(), ncases=4,
         no_example=False, notes=""):
    """Authoring shortcut for "apply this operation" problems.

    args : one or more lines of `name = expression` (one string, or a list with
           one string per variant).  The argument tuple is derived automatically.
    op   : the operation, either a single expression (`x + 1`) or a body with an
           explicit `return`.
    """
    n = max(1, variants)
    args_list = list(args) if isinstance(args, (list, tuple)) else [args] * n
    op_list = list(op) if isinstance(op, (list, tuple)) else [op] * n
    assert len(args_list) == n and len(op_list) == n, "args/op need one entry per variant"
    focus = ["core cases", "edge cases", "larger / varied inputs",
             "alternative inputs", "stress & corner cases", "final mix"]
    for v in range(n):
        a = _norm(args_list[v])
        names = re.findall(r"^([A-Za-z_]\w*)\s*=", a, re.M)
        assert names, "auto(): args must contain assignments"
        mk = a + "\nreturn (" + ", ".join(names) + ("," if len(names) == 1 else "") + ")"
        o = _norm(op_list[v])
        if re.search(r"^\s*return\b", o, re.M):
            sol = o
        else:
            assert "\n" not in o, "auto(): multi-statement op needs an explicit return"
            sol = "return " + o
        q(topic=topic, diff=diff, tags=tags, title=title, ask=ask,
          sig="solve(" + ", ".join(arg_names or names) + ")", sol=sol, mk=mk,
          variants=1, props=props, hints=hints, strict=strict, cmp=cmp,
          starter=starter, imports=imports, arg_names=arg_names or names,
          ncases=ncases, focus=[focus[v % len(focus)]], no_example=no_example,
          notes=notes)
