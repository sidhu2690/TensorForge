"""Python question bank — fundamentals, idioms and classic interview algorithms."""
from dsl import q, auto

# =========================================================================== #
#  Strings
# =========================================================================== #
q(topic="python", diff="easy", tags=["strings", "slicing"], title="Reverse a string",
  ask="Return `s` reversed. Use slicing — no loops needed.",
  sig="solve(s)", sol="return s[::-1]",
  mk="""
  cases = [("tensor",), ("",), ("a",), ("PyTorch",), ("ab cd",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["A slice is `s[start:stop:step]`.", "A step of `-1` walks the string backwards."])

q(topic="python", diff="easy", tags=["strings", "two-pointers"], title="Palindrome check",
  ask="Return `True` if `s` reads the same forwards and backwards (case-sensitive), else `False`.",
  sig="solve(s)", sol="return s == s[::-1]",
  mk="""
  cases = [("racecar",), ("tensor",), ("",), ("abba",), ("ab",), ("a",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Comparing the string with its reverse is the shortest solution.",
         "`abba` and the empty string are both palindromes."])

q(topic="python", diff="easy", tags=["strings", "loops"], title="Count vowels",
  ask="Return how many characters of `s` are vowels (`a e i o u`, both cases).",
  sig="solve(s)", sol="return sum(ch.lower() in 'aeiou' for ch in s)",
  mk="""
  cases = [("TensorForge",), ("",), ("AEIOU",), ("rhythm",), ("python roCks",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`sum()` over a generator of booleans counts the `True`s.",
         "Lower-case each character before comparing."])

q(topic="python", diff="easy", tags=["strings", "methods"], title="Title-case a sentence",
  ask="Capitalise the first letter of every word in `s` and lower-case the rest "
      "(hint: `str.title()` is *not* what we want for `don't` — use `split`/`join`).",
  sig="solve(s)", sol="return ' '.join(w[:1].upper() + w[1:].lower() for w in s.split(' '))",
  mk="""
  cases = [("hello world",), ("",), ("tensor forge rocks",), ("a b c",), ("PYTHON is FUN",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Split on `' '`, transform each word, join back with `' '`.",
         "`w[:1].upper() + w[1:].lower()` keeps the rest lower-case."])

q(topic="python", diff="easy", tags=["strings"], title="Count character frequencies",
  ask="Return a `dict` mapping each character of `s` to how many times it appears. "
      "Only characters that appear at least once should be keys.",
  sig="solve(s)", sol="""
  counts = {}
  for ch in s:
      counts[ch] = counts.get(ch, 0) + 1
  return counts
  """,
  mk="""
  cases = [("tensor",), ("",), ("aabbbc",), ("PyTorch",), ("  ",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`dict.get(key, 0)` gives a default when the key is missing.",
         "`collections.Counter(s)` returns exactly this dict."])

q(topic="python", diff="easy", tags=["strings"], title="Remove duplicate characters",
  ask="Return `s` with duplicate characters removed, keeping the **first** occurrence order.",
  sig="solve(s)", sol="""
  seen, out = set(), []
  for ch in s:
      if ch not in seen:
          seen.add(ch)
          out.append(ch)
  return "".join(out)
  """,
  mk="""
  cases = [("banana",), ("",), ("abcabc",), ("mississippi",), ("a",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Track seen characters in a `set`.", "Append to a list, then `''.join(...)`."])

q(topic="python", diff="easy", tags=["strings", "sorting"], title="Anagram check",
  ask="Return `True` if `a` and `b` are anagrams (same characters with the same counts).",
  sig="solve(a, b)", sol="return sorted(a) == sorted(b)",
  mk="""
  cases = [("listen", "silent"), ("abc", "abd"), ("", ""), ("aab", "aba"), ("a", "aa")]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["Sorting both strings normalises them.",
         "Comparing `Counter(a) == Counter(b)` also works and is O(n)."])

q(topic="python", diff="medium", tags=["strings", "encoding"], title="Run-length encode",
  ask="Compress `s` into `(char, count)` pairs only when a run is **longer than 1**; "
      "single characters are emitted as just the character. Return a string. "
      "Example: `'aabccc'` -> `'a2bc3'`.",
  sig="solve(s)", sol="""
  out, i, n = [], 0, len(s)
  while i < n:
      j = i
      while j < n and s[j] == s[i]:
          j += 1
      run = j - i
      out.append(s[i] + (str(run) if run > 1 else ""))
      i = j
  return "".join(out)
  """,
  mk="""
  cases = [("aabccc",), ("abc",), ("",), ("aaaa",), ("aabbbccccd",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Walk with two pointers: start of run and end of run.",
         "Only append the count when the run length is greater than one."])

q(topic="python", diff="medium", tags=["strings", "cipher"], title="Caesar cipher",
  ask="Shift every ASCII letter in `s` forward by `k` positions, wrapping around the "
      "alphabet and preserving case. Non-letters stay unchanged.",
  sig="solve(s, k)", sol="""
  out = []
  for ch in s:
      if ch.isalpha():
          base = ord("A") if ch.isupper() else ord("a")
          out.append(chr((ord(ch) - base + k) % 26 + base))
      else:
          out.append(ch)
  return "".join(out)
  """,
  mk="""
  cases = [("abc", 1), ("xyz", 3), ("Hello, World!", 5), ("", 4), ("Python", 0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s", "k"],
  hints=["Work relative to `ord('a')` or `ord('A')` and take `% 26`.",
         "`ch.isalpha()` protects spaces and punctuation."])

q(topic="python", diff="easy", tags=["strings"], title="Longest word",
  ask="Return the longest word in `s` (split on whitespace). If several words tie, "
      "return the one that appears first.",
  sig="solve(s)", sol="return max(s.split(), key=len)",
  mk="""
  cases = [("the quick brown fox",), ("a bb ccc",), ("one",), ("aa bbb ccc",), ("x y z",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`max` accepts a `key` function; ties keep the first maximum.",
         "`s.split()` splits on any whitespace."])

q(topic="python", diff="easy", tags=["strings"], title="Reverse word order",
  ask="Return the words of `s` in reverse order, separated by a single space.",
  sig="solve(s)", sol="return ' '.join(s.split()[::-1])",
  mk="""
  cases = [("i love pytorch",), ("one",), ("a b c",), ("  many   spaces  here ",), ("x y",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`split()` with no argument collapses repeated whitespace.",
         "Reverse the list, then join with a space."])

q(topic="python", diff="medium", tags=["strings", "regex"], title="Keep only alphanumerics",
  ask="Return `s` with every character removed except ASCII letters and digits "
      "(no regex required, but allowed).",
  sig="solve(s)", sol="return ''.join(ch for ch in s if ch.isalnum())",
  mk="""
  cases = [("a-b_c!",), ("Hello, World 123",), ("",), ("!!!",), ("x1 y2",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`str.isalnum()` is `True` for letters and digits.",
         "Filter with a generator, then `''.join`."])

q(topic="python", diff="medium", tags=["strings", "parsing"], title="Digits only: sum them",
  ask="Return the sum of every digit character inside `s` (as integers). "
      "Example: `'a1b2c3'` -> `6`.",
  sig="solve(s)", sol="return sum(int(ch) for ch in s if ch.isdigit())",
  mk="""
  cases = [("a1b2c3",), ("no digits",), ("999",), ("",), ("x0y",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`str.isdigit()` tells digit characters apart.",
         "Wrap each digit in `int(...)` before summing."])

q(topic="python", diff="medium", tags=["strings", "convert"], title="Snake case to camel case",
  ask="Convert `snake_case` to `camelCase`: split on `_` and upper-case the first "
      "letter of every part except the first.",
  sig="solve(s)", sol="""
  parts = s.split("_")
  return parts[0] + "".join(p[:1].upper() + p[1:] for p in parts[1:])
  """,
  mk="""
  cases = [("my_var_name",), ("x",), ("",), ("a_b_c",), ("tensor_forge_app",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["`s.split('_')` gives the parts.",
         "Leave the first part untouched."])

q(topic="python", diff="easy", tags=["strings", "formatting"], title="Format a price",
  ask="Format the float `amount` as a string with a `$`, two decimals and thousands "
      "separators, e.g. `1234.5` -> `'$1,234.50'`.",
  sig="solve(amount)", sol="return f'${amount:,.2f}'",
  mk="""
  cases = [(1234.5,), (0.0,), (1000000.0,), (7.125,), (99.9,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["amount"],
  hints=["Format spec `,.2f` adds commas and two decimals.",
         "`f'${value:,.2f}'` keeps the `$` literal."])

q(topic="python", diff="medium", tags=["strings", "binary"], title="Binary string to int",
  ask="`b` is a string of `'0'`/`'1'` characters. Return its integer value "
      "without using `int(b, 2)`.",
  sig="solve(b)", sol="""
  total = 0
  for ch in b:
      total = total * 2 + (1 if ch == "1" else 0)
  return total
  """,
  mk="""
  cases = [("101",), ("0",), ("1111",), ("100000",), ("1",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["b"],
  hints=["Horner's method: `total = total * 2 + bit`.",
         "`int(b, 2)` would be the one-liner answer."])

q(topic="python", diff="easy", tags=["strings", "convert"], title="Int to binary string",
  ask="Return the binary representation of the non-negative integer `n` as a string "
      "of `'0'`/`'1'` characters, without using `bin()`.",
  sig="solve(n)", sol="""
  if n == 0:
      return "0"
  bits = []
  while n:
      bits.append("1" if n & 1 else "0")
      n >>= 1
  return "".join(reversed(bits))
  """,
  mk="""
  cases = [(0,), (1,), (10,), (255,), (37,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Repeatedly take `n & 1` and shift `n >>= 1`.",
         "Collect the bits then reverse them; special-case zero."])

# =========================================================================== #
#  Lists
# =========================================================================== #
q(topic="python", diff="easy", tags=["lists", "loops"], title="Sum and average",
  ask="Return the tuple `(sum, mean)` of the numbers in `xs`. For an empty list return `(0, 0.0)`.",
  sig="solve(xs)", sol="""
  if not xs:
      return (0, 0.0)
  total = sum(xs)
  return (total, total / len(xs))
  """,
  mk="""
  cases = [([1, 2, 3],), ([],), ([-1.5, 0.5],), ([10],), ([2, 4, 6, 8],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Guard the empty list before dividing.",
         "Make sure the mean is a float (`/` already is)."])

q(topic="python", diff="easy", tags=["lists", "comprehension"], title="Squares of evens",
  ask="Return a list with the square of every even number in `xs`, in order.",
  sig="solve(xs)", sol="return [x * x for x in xs if x % 2 == 0]",
  mk="""
  cases = [([1, 2, 3, 4],), ([],), ([0, -2, 5],), ([2, 4, 6],), ([7],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["A list comprehension with an `if` filter is enough.",
         "`x % 2 == 0` works for negative numbers too."])

q(topic="python", diff="easy", tags=["lists"], title="Find the maximum manually",
  ask="Return the largest value in the non-empty list `xs` without using `max()`.",
  sig="solve(xs)", sol="""
  best = xs[0]
  for x in xs[1:]:
      if x > best:
          best = x
  return best
  """,
  mk="""
  cases = [([1, 5, 3],), ([-3, -7, -1],), ([2],), ([4, 4, 1],), ([0, -1, 9],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Seed the best value with the first element.",
         "Compare the rest against it in a loop."])

q(topic="python", diff="easy", tags=["lists"], title="Second largest",
  ask="Return the second largest **distinct** value in `xs`, or `None` if it doesn't exist.",
  sig="solve(xs)", sol="""
  uniq = sorted(set(xs), reverse=True)
  return uniq[1] if len(uniq) >= 2 else None
  """,
  mk="""
  cases = [([3, 1, 4, 4, 2],), ([5, 2],), ([1, 1, 1, 7],), ([-1, -2],), ([9, 8, 7],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Deduplicate with a `set` so repeated maxima are ignored.",
         "Sort descending and take index 1 if it exists."])

q(topic="python", diff="medium", tags=["lists", "arrays"], title="Move zeroes to the end",
  ask="Return a list with the same elements as `xs` but every `0` pushed to the end, "
      "keeping the relative order of the non-zero values.",
  sig="solve(xs)", sol="return [x for x in xs if x != 0] + [0] * xs.count(0)",
  mk="""
  cases = [([0, 1, 0, 3, 12],), ([0],), ([1, 2],), ([0, 0],), ([4, 0, -1, 0, 2],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Count the zeroes first.",
         "Concatenate the non-zero values with that many zeroes."])

q(topic="python", diff="medium", tags=["lists", "slicing"], title="Rotate a list",
  ask="Rotate `xs` right by `k` positions and return the new list. `k` can be larger "
      "than the length of the list.",
  sig="solve(xs, k)", sol="""
  if not xs:
      return []
  k %= len(xs)
  return xs[-k:] + xs[:-k] if k else list(xs)
  """,
  mk="""
  cases = [([1, 2, 3, 4, 5], 2), ([1, 2], 0), ([], 3), ([7], 10), ([1, 2, 3], 4)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "k"],
  hints=["Reduce `k` modulo the length.",
         "The last `k` elements come first."])

q(topic="python", diff="medium", tags=["lists", "sorting"], title="Merge two sorted lists",
  ask="`a` and `b` are sorted ascending. Return one sorted list containing all elements "
      "without calling `sorted()`.",
  sig="solve(a, b)", sol="""
  out, i, j = [], 0, 0
  while i < len(a) and j < len(b):
      if a[i] <= b[j]:
          out.append(a[i]); i += 1
      else:
          out.append(b[j]); j += 1
  out.extend(a[i:])
  out.extend(b[j:])
  return out
  """,
  mk="""
  cases = [([1, 3, 5], [2, 4, 6]), ([], [1]), ([1, 2], []), ([1, 1], [1]), ([-5, 0], [-2, 9])]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["Two indices, one per list.",
         "After the loop, extend with whatever remains."])

q(topic="python", diff="medium", tags=["lists", "search"], title="Binary search",
  ask="`xs` is sorted ascending. Return the index of `target`, or `-1` if it is missing. "
      "Use binary search (O(log n)), not `list.index`.",
  sig="solve(xs, target)", sol="""
  lo, hi = 0, len(xs) - 1
  while lo <= hi:
      mid = (lo + hi) // 2
      if xs[mid] == target:
          return mid
      if xs[mid] < target:
          lo = mid + 1
      else:
          hi = mid - 1
  return -1
  """,
  mk="""
  cases = [([1, 3, 5, 7], 5), ([1], 1), ([], 2), ([2, 4, 6], 5), ([0, 1, 2, 3], 3)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "target"],
  hints=["Maintain an inclusive `lo`/`hi` window.",
         "Shrink the window by comparing the middle element."])

q(topic="python", diff="medium", tags=["lists", "recursion"], title="Flatten a nested list",
  ask="Return a flat list of all values inside the arbitrarily nested list `xs`.",
  sig="solve(xs)", sol="""
  out = []
  for x in xs:
      if isinstance(x, list):
          out.extend(solve(x))
      else:
          out.append(x)
  return out
  """,
  mk="""
  cases = [([1, [2, [3, 4]], 5],), ([],), ([[], [1]],), ([1, 2],), ([[[7]]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Recursion mirrors the nesting.",
         "`isinstance(x, list)` decides whether to recurse."])

q(topic="python", diff="easy", tags=["lists", "slicing"], title="Chunk a list",
  ask="Split `xs` into consecutive chunks of size `n` (the last chunk may be shorter). "
      "Return a list of lists.",
  sig="solve(xs, n)", sol="return [xs[i:i + n] for i in range(0, len(xs), n)]",
  mk="""
  cases = [([1, 2, 3, 4, 5], 2), ([], 3), ([1], 1), ([1, 2, 3], 5), (list(range(7)), 3)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "n"],
  hints=["`range(0, len(xs), n)` yields the start of each chunk.",
         "Slice with `xs[i:i + n]`."])

q(topic="python", diff="medium", tags=["lists", "matrix"], title="Transpose a matrix",
  ask="`m` is a list of equal-length row lists. Return its transpose (list of lists) "
      "without importing numpy.",
  sig="solve(m)", sol="return [list(col) for col in zip(*m)]",
  mk="""
  cases = [([[1, 2, 3], [4, 5, 6]],), ([[1]],), ([[1, 2], [3, 4]],), ([[1, 2, 3]],), ([[1], [2], [3]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["m"],
  hints=["`zip(*m)` turns rows into columns.",
         "Wrap each column tuple in `list(...)`."])

q(topic="python", diff="medium", tags=["lists", "matrix"], title="Matrix multiplication",
  ask="Multiply matrices `a` (m x k) and `b` (k x n) using pure Python and return the "
      "result as a list of lists.",
  sig="solve(a, b)", sol="""
  n, k, p = len(a), len(b), len(b[0])
  out = []
  for i in range(n):
      row = []
      for j in range(p):
          row.append(sum(a[i][t] * b[t][j] for t in range(k)))
      out.append(row)
  return out
  """,
  mk="""
  cases = [([[1, 2], [3, 4]], [[5, 6], [7, 8]]), ([[1, 2, 3]], [[1], [2], [3]]),
           ([[2]], [[3]]), ([[1, 0], [0, 1]], [[9, 8], [7, 6]]), ([[1, 2]], [[3, 4], [5, 6]])]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["Triple loop: output row, output column, shared index.",
         "`sum(a[i][t] * b[t][j] for t in range(k))` is the dot product."])

q(topic="python", diff="medium", tags=["lists", "math"], title="Pascal's triangle row",
  ask="Return row `n` (0-indexed) of Pascal's triangle as a list.",
  sig="solve(n)", sol="""
  row = [1]
  for _ in range(n):
      row = [1] + [row[i] + row[i + 1] for i in range(len(row) - 1)] + [1]
  return row
  """,
  mk="""
  cases = [(0,), (1,), (4,), (6,), (2,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Each new row starts and ends with 1.",
         "Interior values are the sum of two neighbours from the previous row."])

q(topic="python", diff="medium", tags=["lists", "two-pointers"], title="Pair with a given sum",
  ask="Return `True` if two **different** positions in the sorted list `xs` hold values "
      "adding up to `target`.",
  sig="solve(xs, target)", sol="""
  i, j = 0, len(xs) - 1
  while i < j:
      s = xs[i] + xs[j]
      if s == target:
          return True
      if s < target:
          i += 1
      else:
          j -= 1
  return False
  """,
  mk="""
  cases = [([1, 2, 4, 7], 6), ([1, 2], 3), ([1, 2], 4), ([0, 0, 1], 0), ([1, 5, 9], 14)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "target"],
  hints=["Two pointers from both ends of the sorted list.",
         "Move the left pointer up if the sum is too small, else the right pointer down."])

q(topic="python", diff="medium", tags=["lists"], title="Compress consecutive duplicates",
  ask="Return `xs` with consecutive duplicates collapsed to one occurrence "
      "(non-consecutive repeats stay).",
  sig="solve(xs)", sol="""
  out = []
  for x in xs:
      if not out or out[-1] != x:
          out.append(x)
  return out
  """,
  mk="""
  cases = [([1, 1, 2, 2, 2, 3],), ([],), ([1, 2, 1],), ([5],), (["a", "a", "b"],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Compare each element with the last element you kept.",
         "`itertools.groupby` also does this."])

q(topic="python", diff="hard", tags=["lists", "matrix"], title="Spiral order of a matrix",
  ask="Return all elements of `m` in clockwise spiral order starting from the "
      "top-left corner.",
  sig="solve(m)", sol="""
  out = []
  top, bottom, left, right = 0, len(m) - 1, 0, len(m[0]) - 1
  while top <= bottom and left <= right:
      for j in range(left, right + 1):
          out.append(m[top][j])
      top += 1
      for i in range(top, bottom + 1):
          out.append(m[i][right])
      right -= 1
      if top <= bottom:
          for j in range(right, left - 1, -1):
              out.append(m[bottom][j])
          bottom -= 1
      if left <= right:
          for i in range(bottom, top - 1, -1):
              out.append(m[i][left])
          left += 1
  return out
  """,
  mk="""
  cases = [([[1, 2, 3], [4, 5, 6], [7, 8, 9]],), ([[1, 2], [3, 4]],),
           ([[1, 2, 3]],), ([[1], [2], [3]],), ([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["m"],
  hints=["Track four shrinking boundaries: top, bottom, left, right.",
         "Guard the bottom and left passes so a single row/column isn't visited twice."])

q(topic="python", diff="medium", tags=["lists"], title="Rotate a matrix 90 degrees",
  ask="Rotate the square matrix `m` by 90° clockwise and return the new matrix.",
  sig="solve(m)", sol="return [list(row) for row in zip(*m[::-1])]",
  mk="""
  cases = [([[1, 2], [3, 4]],), ([[1]],), ([[1, 2, 3], [4, 5, 6], [7, 8, 9]],),
           ([[0, 1], [2, 3]],), ([[5, 6], [7, 8]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["m"],
  hints=["Reverse the row order first.",
         "Then transpose: `zip(*m[::-1])`."])

# =========================================================================== #
#  Dicts, sets and sorting
# =========================================================================== #
q(topic="python", diff="easy", tags=["dict"], title="Word frequencies",
  ask="Return a dict mapping each whitespace-separated word in `text` to its count.",
  sig="solve(text)", sol="""
  counts = {}
  for w in text.split():
      counts[w] = counts.get(w, 0) + 1
  return counts
  """,
  mk="""
  cases = [("a b a",), ("",), ("the cat the dog the",), ("x",), ("a a a",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["text"],
  hints=["`text.split()` gives the words.", "`counts.get(w, 0) + 1` avoids KeyError."])

q(topic="python", diff="easy", tags=["dict"], title="Invert a dictionary",
  ask="Return a new dict mapping each value of `d` to its key. If several keys share a "
      "value, keep the **smallest** key (by normal comparison of its string form).",
  sig="solve(d)", sol="""
  out = {}
  for k, val in d.items():
      if val not in out or str(k) < str(out[val]):
          out[val] = k
  return out
  """,
  mk="""
  cases = [({"a": 1, "b": 2},), ({"a": 1, "b": 1},), ({},), ({"x": 0},), ({"p": 3, "q": 3, "r": 4},)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["d"],
  hints=["Iterate over `.items()`.", "Decide the tie-break with a comparison of string forms."])

q(topic="python", diff="medium", tags=["dict"], title="Merge dictionaries, summing values",
  ask="Return a dict with the union of keys of `a` and `b`; shared keys hold the sum "
      "of both values.",
  sig="solve(a, b)", sol="""
  out = dict(a)
  for k, val in b.items():
      out[k] = out.get(k, 0) + val
  return out
  """,
  mk="""
  cases = [({"x": 1}, {"x": 2, "y": 3}), ({}, {"a": 1}), ({"a": 5}, {}), ({"k": 1, "j": 2}, {"j": 3}), ({"z": 0}, {"z": 0})]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["Start from a copy of `a`.", "Add `b`'s values on top with `.get(k, 0)`."])

q(topic="python", diff="medium", tags=["dict", "sorting"], title="Sort a dict by value",
  ask="Return the dict's `(key, value)` pairs as a list of tuples sorted by value "
      "ascending, breaking ties by key ascending.",
  sig="solve(d)", sol="return sorted(d.items(), key=lambda kv: (kv[1], kv[0]))",
  mk="""
  cases = [({"a": 3, "b": 1, "c": 2},), ({},), ({"x": 1, "y": 1},), ({"q": 0},), ({"m": 2, "n": -1, "o": 2},)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["d"],
  hints=["`sorted` accepts a tuple key.", "`(value, key)` expresses the tie-break."])

q(topic="python", diff="medium", tags=["dict", "sorting"], title="Top-k frequent elements",
  ask="Return the `k` most frequent values in `xs`, ordered by descending frequency "
      "(ties broken by smaller value first).",
  sig="solve(xs, k)", sol="""
  counts = {}
  for x in xs:
      counts[x] = counts.get(x, 0) + 1
  return sorted(counts, key=lambda x: (-counts[x], x))[:k]
  """,
  mk="""
  cases = [([1, 1, 1, 2, 2, 3], 2), ([1], 1), ([4, 4, 5, 5, 6], 3), ([], 2), ([9, 9, 1, 1, 2], 2)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "k"],
  hints=["Count first, then sort the unique keys by `(-count, value)`.",
         "Slicing `[:k]` keeps the top k."])

q(topic="python", diff="medium", tags=["dict", "strings"], title="Group anagrams",
  ask="Group the words of `words` that are anagrams of each other. Return a list of "
      "groups; groups are ordered by their smallest word, and words inside a group "
      "are sorted alphabetically.",
  sig="solve(words)", sol="""
  groups = {}
  for w in words:
      groups.setdefault("".join(sorted(w)), []).append(w)
  return sorted((sorted(g) for g in groups.values()), key=lambda g: g[0])
  """,
  mk="""
  cases = [(["eat", "tea", "tan", "ate", "nat", "bat"],), ([],), (["a"],),
           (["abc", "cba", "xyz"],), (["listen", "silent", "enlist", "google"],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["words"],
  hints=["Sorting the letters of a word produces a canonical key.",
         "`dict.setdefault(key, []).append(...)` groups in one pass."])

q(topic="python", diff="easy", tags=["dict", "zip"], title="Build a dict from lists",
  ask="`keys` and `values` have the same length. Return a dict pairing them. "
      "When a key repeats, the **last** value wins.",
  sig="solve(keys, values)", sol="return dict(zip(keys, values))",
  mk="""
  cases = [(["a", "b"], [1, 2]), ([], []), (["x", "x"], [1, 2]), (["k"], [0]), (["a", "b", "a"], [1, 2, 3])]
  return cases[(v + i) % len(cases)]
  """, arg_names=["keys", "values"],
  hints=["`zip` pairs the two lists up.", "`dict(...)` keeps the last duplicate."])

q(topic="python", diff="easy", tags=["set"], title="Set operations",
  ask="Return the tuple `(intersection, union, difference)` of the sets `a` and `b`, "
      "where difference is `a - b`. Each element should be a sorted list.",
  sig="solve(a, b)", sol="""
  return (sorted(a & b), sorted(a | b), sorted(a - b))
  """,
  mk="""
  cases = [({1, 2, 3}, {2, 3, 4}), (set(), {1}), ({5}, {5}), ({1, 2}, {3}), ({0, -1}, {0, 2})]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["`&`, `|`, `-` are the set operators.", "`sorted()` normalises the order."])

q(topic="python", diff="medium", tags=["sorting", "key"], title="Sort by absolute value",
  ask="Return `xs` sorted by absolute value ascending; ties keep their original order.",
  sig="solve(xs)", sol="return sorted(xs, key=abs)",
  mk="""
  cases = [([-3, 1, -2, 4],), ([],), ([5, -5, 5],), ([0, -1],), ([-9, 2, -7, 0],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`key=abs` is enough.", "Python's sort is stable, so ties keep input order."])

q(topic="python", diff="medium", tags=["sorting", "key"], title="Sort pairs smartly",
  ask="Return the list of `(a, b)` tuples sorted by `b` descending and, for equal `b`, "
      "by `a` ascending.",
  sig="solve(pairs)", sol="return sorted(pairs, key=lambda p: (-p[1], p[0]))",
  mk="""
  cases = [([(1, 2), (2, 2), (3, 1)],), ([],), ([(0, 5)],), ([(4, 0), (1, 0)],), ([(2, 3), (1, 3)],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["pairs"],
  hints=["A lambda returning a tuple describes the ordering.",
         "Negate the value you want descending."])

auto(topic="python", diff="medium", tags=["sorting", "key"], title="Sort strings by length",
     ask="Return the list sorted by string length ascending; equal lengths stay in "
         "alphabetical order.",
     args="words = ['pear', 'fig', 'apple', 'kiwi', 'date']",
     op="sorted(words, key=lambda w: (len(w), w))", variants=1)

auto(topic="python", diff="medium", tags=["sorting", "key"], title="Sort strings by length",
     ask="Return the list sorted by string length ascending; equal lengths stay in "
         "alphabetical order.",
     args="words = ['bb', 'a', 'ccc', 'aa', 'b']",
     op="sorted(words, key=lambda w: (len(w), w))", variants=2)

auto(topic="python", diff="medium", tags=["sorting", "key"], title="Sort strings by length",
     ask="Return the list sorted by string length ascending; equal lengths stay in "
         "alphabetical order.",
     args="words = ['zzz', 'yy', 'x', 'www', 'vv']",
     op="sorted(words, key=lambda w: (len(w), w))", variants=3)

q(topic="python", diff="medium", tags=["sorting", "stable"], title="Evens before odds",
  ask="Return `xs` reordered so all even numbers come before all odd numbers, "
      "preserving the relative order inside each group.",
  sig="solve(xs)", sol="return sorted(xs, key=lambda x: x % 2 != 0)",
  mk="""
  cases = [([1, 2, 3, 4],), ([],), ([2, 4],), ([1, 3],), ([5, 8, 7, 6],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["A boolean key sorts `False` before `True`.", "The sort is stable."])

q(topic="python", diff="hard", tags=["sorting", "bit"], title="Sort by number of set bits",
  ask="Return `xs` sorted by the number of `1` bits in each integer (ascending), "
      "breaking ties by numeric value.",
  sig="solve(xs)", sol="return sorted(xs, key=lambda x: (bin(x).count('1'), x))",
  mk="""
  cases = [([3, 1, 2, 4],), ([],), ([7],), ([8, 7, 1],), ([0, 15, 3],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`bin(x).count('1')` counts bits.",
         "Include `x` itself in the key tuple for the tie-break."])

# =========================================================================== #
#  Comprehensions & iterators
# =========================================================================== #
q(topic="python", diff="easy", tags=["comprehension"], title="Squares with a comprehension",
  ask="Return `[0, 1, 4, ..., (n-1)**2]` for the non-negative integer `n`, in one comprehension.",
  sig="solve(n)", sol="return [i * i for i in range(n)]",
  mk="""
  cases = [(5,), (0,), (1,), (3,), (7,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["`range(n)` gives 0..n-1.", "Square each value inside the comprehension."])

auto(topic="python", diff="easy", tags=["comprehension"], title="Filter and transform",
     ask="Return a list of `x * 10` for every `x` in `xs` that is greater than 3.",
     args="xs = [1, 5, 2, 8, 4, 10]", op="[x * 10 for x in xs if x > 3]", variants=1)

auto(topic="python", diff="easy", tags=["comprehension"], title="Filter and transform",
     ask="Return a list of `x * 10` for every `x` in `xs` that is greater than 3.",
     args="xs = [-1, 4, 3, 7, 100]", op="[x * 10 for x in xs if x > 3]", variants=2)

auto(topic="python", diff="easy", tags=["comprehension"], title="Filter and transform",
     ask="Return a list of `x * 10` for every `x` in `xs` that is greater than 3.",
     args="xs = [4]", op="[x * 10 for x in xs if x > 3]", variants=3)

q(topic="python", diff="easy", tags=["dict", "comprehension"], title="Square dict",
  ask="Return a dict mapping `1..n` to their squares using a dict comprehension.",
  sig="solve(n)", sol="return {i: i * i for i in range(1, n + 1)}",
  mk="""
  cases = [(3,), (0,), (1,), (5,), (2,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["`range(1, n + 1)` covers 1..n.", "The comprehension syntax is `{k: v for ...}`."])

q(topic="python", diff="easy", tags=["enumerate"], title="Index pairs",
  ask="Return a list of `(index, value)` tuples for `xs`, built with `enumerate`.",
  sig="solve(xs)", sol="return list(enumerate(xs))",
  mk="""
  cases = [(["a", "b"],), ([],), ([10],), ([1, 2, 3],), ([None, True],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`enumerate` yields `(i, value)` pairs.", "Convert the iterator with `list(...)`."])

q(topic="python", diff="medium", tags=["zip"], title="Pair up two lists",
  ask="Pair the elements of `a` and `b` with `zip`. Return a list of tuples; stop at "
      "the length of the shorter list.",
  sig="solve(a, b)", sol="return list(zip(a, b))",
  mk="""
  cases = [([1, 2], [3, 4]), ([], [1]), ([1, 2, 3], [4]), ([5], [6, 7]), (["x"], ["y"])]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["`zip` is lazy — materialise it with `list`.",
         "It stops automatically at the shorter input."])

q(topic="python", diff="medium", tags=["itertools"], title="Running totals",
  ask="Return the running (cumulative) sum of `xs` using `itertools.accumulate`.",
  sig="solve(xs)", sol="""
  from itertools import accumulate
  return list(accumulate(xs))
  """,
  mk="""
  cases = [([1, 2, 3],), ([],), ([5, -2],), ([0],), ([1, 1, 1, 1],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`itertools.accumulate` adds as it goes.",
         "Return a list, not the iterator."])

q(topic="python", diff="medium", tags=["itertools"], title="Flatten with chain",
  ask="Concatenate the nested lists `groups` into one flat list using "
      "`itertools.chain.from_iterable`.",
  sig="solve(groups)", sol="""
  from itertools import chain
  return list(chain.from_iterable(groups))
  """,
  mk="""
  cases = [([[1, 2], [3], []],), ([],), ([[], []],), ([["a"], ["b", "c"]],), ([[1], [2], [3]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["groups"],
  hints=["`chain.from_iterable` takes an iterable *of* iterables.",
         "Wrap the result in `list`."])

q(topic="python", diff="medium", tags=["itertools"], title="All combinations pairs",
  ask="Return every 2-element combination of `xs` as a list of tuples, using "
      "`itertools.combinations` (order matters — don't sort).",
  sig="solve(xs)", sol="""
  from itertools import combinations
  return list(combinations(xs, 2))
  """,
  mk="""
  cases = [([1, 2, 3],), ([],), ([1],), (["a", "b", "c", "d"],), ([0, 1],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`combinations(xs, 2)` yields index-ordered pairs.",
         "Materialise with `list(...)`."])

q(topic="python", diff="medium", tags=["itertools"], title="Cartesian product",
  ask="Return every `(a, b)` pair from `a_list` x `b_list` in order, using "
      "`itertools.product`.",
  sig="solve(a_list, b_list)", sol="""
  from itertools import product
  return list(product(a_list, b_list))
  """,
  mk="""
  cases = [([1, 2], [3]), ([], [1]), ([1], []), (["x"], ["y", "z"]), ([0], [0])]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a_list", "b_list"],
  hints=["`product(a, b)` iterates `b` fastest.",
         "Return a list of tuples."])

q(topic="python", diff="medium", tags=["itertools"], title="Count permutations",
  ask="Return the number of permutations of `n` distinct items, computed **without** "
      "`math.factorial` (loop or `functools.reduce`).",
  sig="solve(n)", sol="""
  from functools import reduce
  import operator
  return reduce(operator.mul, range(1, n + 1), 1)
  """,
  mk="""
  cases = [(0,), (1,), (5,), (3,), (7,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["The answer is n! — start the accumulator at 1.",
         "`range(1, n + 1)` multiplies every integer."])

q(topic="python", diff="medium", tags=["generator"], title="First n squares (generator)",
  ask="Return a **generator** (or list) yielding the squares of `1..n`. The tests call "
      "`list(result)`.",
  sig="solve(n)", sol="return (i * i for i in range(1, n + 1))",
  mk="""
  cases = [(3,), (0,), (1,), (5,), (2,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["A generator expression or `yield` works.",
         "The test materialises the result with `list(...)`."],
  cmp="none",
  props=["n = _args[0]\nassert list(_got) == [i * i for i in range(1, n + 1)]"])

q(topic="python", diff="medium", tags=["generator"], title="Chunked generator",
  ask="Return an iterable of consecutive chunks of `xs` with size `n`, each chunk a list. "
      "The tests call `list(result)`.",
  sig="solve(xs, n)", sol="""
  return (xs[i:i + n] for i in range(0, len(xs), n))
  """,
  mk="""
  cases = [([1, 2, 3, 4, 5], 2), ([], 3), ([1], 1), ([1, 2, 3], 5), ([0, 1, 2, 3], 2)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "n"],
  hints=["`range(0, len(xs), n)` gives the chunk starts.",
         "Yield slices instead of building the whole list."],
  cmp="none",
  props=["xs, n = _args[0], _args[1]\nassert list(_got) == [xs[i:i + n] for i in range(0, len(xs), n)]"])

# =========================================================================== #
#  Functions, closures, decorators
# =========================================================================== #
q(topic="python", diff="easy", tags=["functions", "args"], title="Sum any number of args",
  ask="`solve` must accept any number of positional numbers and return their sum.",
  sig="solve(*nums)", sol="return sum(nums)",
  mk="""
  cases = [((1, 2, 3),), ((),), ((5,),), ((-1, 1),), ((2, 2, 2, 2),)]
  return cases[(v + i) % len(cases)][0]
  """,
  arg_names=["*nums"],
  hints=["`*nums` collects the positional arguments into a tuple.",
         "`sum(tuple)` handles the empty case."])

q(topic="python", diff="medium", tags=["functions", "kwargs"], title="Keyword arguments with defaults",
  ask="`kw` is a dict of optional settings. Return a dict with keys `a`, `b`, `c` where "
      "`a` defaults to `0`, `b` to `'x'` and `c` to `False`; keys present in `kw` override "
      "the defaults. Unknown keys are ignored.",
  sig="solve(kw)", sol="""
  defaults = {"a": 0, "b": "x", "c": False}
  for k in ("a", "b", "c"):
      defaults[k] = kw.get(k, defaults[k])
  return defaults
  """,
  mk="""
  cases = [({"a": 5},), ({},), ({"b": "y", "c": True},), ({"zzz": 1},), ({"a": -1, "b": "z", "c": True},)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["kw"],
  hints=["Start from a defaults dict.", "`kwargs.get(key, default)` keeps defaults intact."])

q(topic="python", diff="medium", tags=["closures"], title="Make a counter",
  ask="Return a function that returns 0, 1, 2, ... on successive calls. "
      "The tests call it three times and compare the list of results.",
  sig="solve()", sol="""
  state = {"n": -1}
  def counter():
      state["n"] += 1
      return state["n"]
  return counter
  """,
  mk="return ()", arg_names=[],
  cmp="none",
  props=["""
  c = _got
  assert [c(), c(), c()] == [0, 1, 2], "counter should yield 0, 1, 2"
  assert c() == 3
  """],
  hints=["A closure can keep state in a mutable container.",
         "`nonlocal` inside a nested function is the other idiom."])

q(topic="python", diff="medium", tags=["decorator"], title="Count the calls",
  ask="Return `(wrapped, get_count)` where `wrapped` behaves like `f` and `get_count()` "
      "returns how many times `wrapped` has been called. `f` takes one number and returns a number.",
  sig="solve(f)", sol="""
  calls = {"n": 0}
  def wrapped(x):
      calls["n"] += 1
      return f(x)
  return (wrapped, lambda: calls["n"])
  """,
  mk="return (lambda x: x + 1,)", arg_names=["f"],
  cmp="none",
  props=["""
  wrapped, count = _got
  assert count() == 0
  assert wrapped(2) == 3 and wrapped(5) == 6
  assert count() == 2
  """],
  hints=["Keep the counter in a mutable dict inside the closure.",
         "Return both the wrapper and a getter."])

q(topic="python", diff="medium", tags=["decorator", "functools"], title="Memoize a function",
  ask="Return a memoised version of `f` (single positional arg). Calling it twice with "
      "the same argument must call `f` only once. Expose `cache_len()` too: return "
      "`(memo, cache_len)`.",
  sig="solve(f)", sol="""
  cache = {}
  def memo(x):
      if x not in cache:
          cache[x] = f(x)
      return cache[x]
  return (memo, lambda: len(cache))
  """,
  mk="return (lambda n: n * 2,)", arg_names=["f"],
  cmp="none",
  props=["""
  memo, cache_len = _got
  assert cache_len() == 0
  assert memo(4) == 8 and memo(4) == 8
  assert cache_len() == 1
  assert memo(5) == 10 and cache_len() == 2
  """],
  hints=["A dict keyed by the argument is enough.",
         "Check `if x not in cache` before computing."])

q(topic="python", diff="easy", tags=["recursion"], title="Factorial with recursion",
  ask="Return `n!` using recursion and without `math.factorial`.",
  sig="solve(n)", sol="""
  if n <= 1:
      return 1
  return n * solve(n - 1)
  """,
  mk="""
  cases = [(0,), (1,), (5,), (3,), (7,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Base case: 0! = 1! = 1.", "Recursive case: n * (n-1)!."])

q(topic="python", diff="medium", tags=["recursion", "memo"], title="Fibonacci with memoisation",
  ask="Return the `n`-th Fibonacci number (F(0)=0, F(1)=1) using memoisation.",
  sig="solve(n)", sol="""
  memo = {0: 0, 1: 1}
  def fib(k):
      if k not in memo:
          memo[k] = fib(k - 1) + fib(k - 2)
      return memo[k]
  return fib(n)
  """,
  mk="""
  cases = [(0,), (1,), (10,), (20,), (30,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Seed the base cases in a dict.",
         "Look up, compute recursively, and store the result."])

q(topic="python", diff="easy", tags=["recursion"], title="Digit sum recursively",
  ask="Return the sum of the decimal digits of `n` using recursion (n >= 0).",
  sig="solve(n)", sol="""
  if n < 10:
      return n
  return n % 10 + solve(n // 10)
  """,
  mk="""
  cases = [(0,), (7,), (123,), (9999,), (10,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["`n % 10` is the last digit, `n // 10` drops it.",
         "The base case is a single digit."])

q(topic="python", diff="medium", tags=["functools"], title="Partial application",
  ask="Return a function that multiplies its argument by `factor` and adds `offset`. "
      "Use `functools.partial` (or a closure).",
  sig="solve(factor, offset)", sol="""
  from functools import partial
  def fma(x, m, b):
      return m * x + b
  return partial(fma, m=factor, b=offset)
  """,
  mk="""
  cases = [(2, 1), (0, 5), (-1, 0), (3, -2), (1, 1)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["factor", "offset"],
  cmp="none",
  props=["""
  factor, offset = _args[0], _args[1]
  assert _got(10) == factor * 10 + offset
  assert _got(0) == offset
  """],
  hints=["`functools.partial(f, m=..., b=...)` freezes keyword arguments.",
         "The returned object is callable with the remaining argument."])

# =========================================================================== #
#  Classic interview algorithms (part 2)
# =========================================================================== #
q(topic="python", diff="medium", tags=["hash-map", "array"], title="Two-sum indices",
  ask="Return the indices `(i, j)` of two **distinct** positions adding up to `target`, "
      "using a hash map in one pass. Return `None` if no pair exists. When several pairs "
      "exist return the one found first while scanning from the left.",
  sig="solve(xs, target)", sol="""
  seen = {}
  for i, x in enumerate(xs):
      if target - x in seen:
          return (seen[target - x], i)
      seen[x] = i
  return None
  """,
  mk="""
  cases = [([2, 7, 11, 15], 9), ([3, 3], 6), ([1, 2], 10), ([0, 4, 3, 0], 0), ([-1, -2, -3], -5)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "target"],
  hints=["Store the complement you would need.",
         "Check the map before inserting the current value."])

q(topic="python", diff="medium", tags=["dp", "kadane"], title="Maximum subarray sum",
  ask="Return the largest sum of any non-empty contiguous subarray of `xs` (Kadane's "
      "algorithm).",
  sig="solve(xs)", sol="""
  best = cur = xs[0]
  for x in xs[1:]:
      cur = max(x, cur + x)
      best = max(best, cur)
  return best
  """,
  mk="""
  cases = [([-2, 1, -3, 4, -1, 2, 1, -5, 4],), ([-1],), ([1, 2, 3],), ([-3, -1, -2],), ([5, -10, 6],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`cur` is the best sum ending at the current position.",
         "Restart the running sum when it becomes worse than the element itself."])

q(topic="python", diff="medium", tags=["greedy"], title="Best time to buy and sell",
  ask="`prices[i]` is the price on day `i`. Return the maximum profit from one buy "
      "followed by one later sell (0 if no profit is possible).",
  sig="solve(prices)", sol="""
  best = 0
  low = prices[0]
  for p in prices[1:]:
      best = max(best, p - low)
      low = min(low, p)
  return best
  """,
  mk="""
  cases = [([7, 1, 5, 3, 6, 4],), ([7, 6, 4, 3, 1],), ([1, 2],), ([3],), ([2, 4, 1],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["prices"],
  hints=["Track the minimum price seen so far.",
         "The best profit is `price - min_so_far`."])

q(topic="python", diff="medium", tags=["stack"], title="Valid parentheses",
  ask="Return `True` if every bracket in `s` is correctly closed and nested "
      "(`()`, `[]`, `{}`).",
  sig="solve(s)", sol="""
  pairs = {')': '(', ']': '[', '}': '{'}
  stack = []
  for ch in s:
      if ch in '([{':
          stack.append(ch)
      elif ch in pairs:
          if not stack or stack.pop() != pairs[ch]:
              return False
  return not stack
  """,
  mk="""
  cases = [("()[]{}",), ("(]",), ("",), ("([{}])",), ("((",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Push openers, pop on closers.",
         "A leftover stack means an unclosed bracket."])

q(topic="python", diff="hard", tags=["intervals", "sorting"], title="Merge intervals",
  ask="Merge the overlapping closed intervals in `intervals` (a list of `[start, end]` "
      "pairs) and return them sorted by start.",
  sig="solve(intervals)", sol="""
  if not intervals:
      return []
  out = []
  for start, end in sorted(intervals):
      if out and start <= out[-1][1]:
          out[-1][1] = max(out[-1][1], end)
      else:
          out.append([start, end])
  return out
  """,
  mk="""
  cases = [([[1, 3], [2, 6], [8, 10], [15, 18]],), ([],), ([[1, 4], [4, 5]],),
           ([[5, 6], [1, 2]],), ([[1, 10], [2, 3], [4, 5]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["intervals"],
  hints=["Sort by start time first.",
         "Merge when the next start is <= the current end."])

q(topic="python", diff="medium", tags=["voting"], title="Majority element",
  ask="Return the element that appears more than `n // 2` times in `xs` (Boyer–Moore "
      "voting algorithm, no hash map).",
  sig="solve(xs)", sol="""
  count, cand = 0, None
  for x in xs:
      if count == 0:
          cand = x
      count += 1 if x == cand else -1
  return cand
  """,
  mk="""
  cases = [([3, 2, 3],), ([2, 2, 1, 1, 1, 2, 2],), ([1],), ([5, 5, 5, 1],), ([7, 7],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Pair off different elements until one candidate remains.",
         "The majority element survives any cancellation."])

q(topic="python", diff="easy", tags=["bit-manipulation"], title="Single number",
  ask="Every element of `xs` appears twice except one. Return the unique number using XOR.",
  sig="solve(xs)", sol="""
  result = 0
  for x in xs:
      result ^= x
  return result
  """,
  mk="""
  cases = [([2, 2, 1],), ([4, 1, 2, 1, 2],), ([1],), ([7, 7, 9],), ([3, 3, 5, 5, 8],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["`x ^ x == 0` and `x ^ 0 == x`.",
         "XOR is commutative, so the order doesn't matter."])

q(topic="python", diff="medium", tags=["bit-manipulation"], title="Counting bits",
  ask="Return a list where position `i` holds the number of `1` bits in `i`, for "
      "`i = 0..n` (DP: `bits[i] = bits[i >> 1] + (i & 1)`).",
  sig="solve(n)", sol="""
  bits = [0] * (n + 1)
  for i in range(1, n + 1):
      bits[i] = bits[i >> 1] + (i & 1)
  return bits
  """,
  mk="""
  cases = [(0,), (2,), (5,), (8,), (1,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Reuse the answer for `i >> 1`.",
         "`i & 1` adds the least significant bit."])

q(topic="python", diff="medium", tags=["math", "sieve"], title="Primes below n",
  ask="Return the list of primes strictly below `n` using the sieve of Eratosthenes.",
  sig="solve(n)", sol="""
  if n < 3:
      return []
  sieve = [True] * n
  sieve[0] = sieve[1] = False
  for p in range(2, int(n ** 0.5) + 1):
      if sieve[p]:
          for multiple in range(p * p, n, p):
              sieve[multiple] = False
  return [i for i in range(n) if sieve[i]]
  """,
  mk="""
  cases = [(10,), (2,), (30,), (1,), (50,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Start crossing off at `p * p`.",
         "Only loop up to `sqrt(n)`."])

q(topic="python", diff="easy", tags=["math"], title="FizzBuzz",
  ask="Return a list of strings for `1..n` where multiples of 3 are `'Fizz'`, multiples "
      "of 5 are `'Buzz'`, multiples of both are `'FizzBuzz'`, and everything else is the "
      "number as a string.",
  sig="solve(n)", sol="""
  out = []
  for i in range(1, n + 1):
      if i % 15 == 0:
          out.append('FizzBuzz')
      elif i % 3 == 0:
          out.append('Fizz')
      elif i % 5 == 0:
          out.append('Buzz')
      else:
          out.append(str(i))
  return out
  """,
  mk="""
  cases = [(5,), (15,), (1,), (3,), (20,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Check divisibility by 15 first.",
         "Otherwise 15 would be reported as `'Fizz'`."])

q(topic="python", diff="easy", tags=["math"], title="GCD with Euclid",
  ask="Return the greatest common divisor of `a` and `b` using Euclid's algorithm "
      "(no `math.gcd`).",
  sig="solve(a, b)", sol="""
  while b:
      a, b = b, a % b
  return abs(a)
  """,
  mk="""
  cases = [(12, 18), (7, 13), (0, 5), (100, 75), (9, 0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["Replace `(a, b)` with `(b, a % b)` until `b` is zero.",
         "`gcd(0, x)` is `x`."])

q(topic="python", diff="easy", tags=["math"], title="Least common multiple",
  ask="Return the least common multiple of `a` and `b` using `abs(a * b) // gcd(a, b)`.",
  sig="solve(a, b)", sol="""
  x, y = a, b
  while y:
      x, y = y, x % y
  return abs(a * b) // abs(x)
  """,
  mk="""
  cases = [(4, 6), (7, 5), (3, 3), (0, 9), (10, 15)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["Compute the gcd first.",
         "The product divided by the gcd is the lcm."])

q(topic="python", diff="easy", tags=["math"], title="Is prime",
  ask="Return `True` if the integer `n` (> 1) is prime, using trial division up to "
      "`sqrt(n)`.",
  sig="solve(n)", sol="""
  if n < 2:
      return False
  i = 2
  while i * i <= n:
      if n % i == 0:
          return False
      i += 1
  return True
  """,
  mk="""
  cases = [(2,), (1,), (17,), (18,), (97,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Only divisors up to `sqrt(n)` need checking.",
         "1 is not prime."])

q(topic="python", diff="medium", tags=["math"], title="Armstrong number",
  ask="Return `True` if the `d`-digit number `n` equals the sum of its digits each "
      "raised to the power `d` (a narcissistic number).",
  sig="solve(n)", sol="""
  digits = [int(ch) for ch in str(n)]
  d = len(digits)
  return n == sum(x ** d for x in digits)
  """,
  mk="""
  cases = [(153,), (123,), (9474,), (7,), (370,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["`153 = 1^3 + 5^3 + 3^3`.",
         "The exponent is the number of digits."])

q(topic="python", diff="medium", tags=["dp", "sliding-window"], title="Longest unique substring",
  ask="Return the length of the longest substring of `s` without repeating characters.",
  sig="solve(s)", sol="""
  last = {}
  best = start = 0
  for i, ch in enumerate(s):
      if ch in last and last[ch] >= start:
          start = last[ch] + 1
      last[ch] = i
      best = max(best, i - start + 1)
  return best
  """,
  mk="""
  cases = [("abcabcbb",), ("bbbbb",), ("pwwkew",), ("",), ("abcdef",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Remember the last index of each character.",
         "Move the window start past the previous occurrence."])

q(topic="python", diff="medium", tags=["sliding-window"], title="Max sum of a fixed window",
  ask="Return the maximum sum of any `k` consecutive elements of `xs`.",
  sig="solve(xs, k)", sol="""
  window = sum(xs[:k])
  best = window
  for i in range(k, len(xs)):
      window += xs[i] - xs[i - k]
      best = max(best, window)
  return best
  """,
  mk="""
  cases = [([1, 3, 2, 6, -1, 4, 1, 8, 2], 3), ([5], 1), ([1, 2, 3, 4], 2), ([-1, -2, -3], 2), ([0, 0, 0], 3)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "k"],
  hints=["Slide the window by adding the new element and removing the old one.",
         "Each slide is O(1)."])

q(topic="python", diff="medium", tags=["sliding-window", "set"], title="Nearby duplicates",
  ask="Return `True` if `xs` contains two equal values whose indices differ by at most "
      "`k`.",
  sig="solve(xs, k)", sol="""
  seen = {}
  for i, x in enumerate(xs):
      if x in seen and i - seen[x] <= k:
          return True
      seen[x] = i
  return False
  """,
  mk="""
  cases = [([1, 2, 3, 1], 3), ([1, 0, 1, 1], 1), ([1, 2, 3], 2), (["a", "a"], 1), ([4, 5, 6, 5], 0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "k"],
  hints=["Store the most recent index of each value.",
         "`k=0` can never be true."])

q(topic="python", diff="medium", tags=["strings", "math"], title="Roman to integer",
  ask="Convert the Roman numeral `s` to an integer. Subtractive pairs (`IV`, `IX`, `XL`, "
      "`XC`, `CD`, `CM`) count as 4, 9, 40, 90, 400, 900.",
  sig="solve(s)", sol="""
  values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
  total = 0
  for i, ch in enumerate(s):
      if i + 1 < len(s) and values[s[i + 1]] > values[ch]:
          total -= values[ch]
      else:
          total += values[ch]
  return total
  """,
  mk="""
  cases = [("III",), ("IV",), ("MCMXCIV",), ("LVIII",), ("IX",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["s"],
  hints=["Scan left to right and subtract when the next symbol is larger.",
         "`MCMXCIV` is 1994."])

q(topic="python", diff="medium", tags=["strings"], title="Integer to Roman",
  ask="Convert `n` (1..3999) to a Roman numeral using greedy subtraction over the "
      "value/symbol table (including the subtractive pairs).",
  sig="solve(n)", sol="""
  table = [(1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'), (100, 'C'), (90, 'XC'),
           (50, 'L'), (40, 'XL'), (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')]
  out = []
  for value, sym in table:
      while n >= value:
          out.append(sym)
          n -= value
  return ''.join(out)
  """,
  mk="""
  cases = [(3,), (1994,), (58,), (9,), (3999,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Greedily take the largest symbol that fits.",
         "Include the six subtractive pairs in the table."])

q(topic="python", diff="medium", tags=["array", "prefix"], title="Product except self",
  ask="Return a list where position `i` is the product of all elements of `xs` except "
      "`xs[i]`, **without** division and in O(n).",
  sig="solve(xs)", sol="""
  n = len(xs)
  out = [1] * n
  left = 1
  for i in range(n):
      out[i] = left
      left *= xs[i]
  right = 1
  for i in range(n - 1, -1, -1):
      out[i] *= right
      right *= xs[i]
  return out
  """,
  mk="""
  cases = [([1, 2, 3, 4],), ([0, 1, 2],), ([5],), ([-1, 1, 0, -3],), ([2, 3],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["Two passes: prefix products, then suffix products.",
         "Multiplying the two passes gives the answer."])

q(topic="python", diff="medium", tags=["matrix"], title="Set matrix zeroes",
  ask="Return a copy of the matrix `m` where every row and column containing a zero is "
      "set to zero.",
  sig="solve(m)", sol="""
  rows = {i for i, row in enumerate(m) if any(x == 0 for x in row)}
  cols = {j for i, row in enumerate(m) for j, x in enumerate(row) if x == 0}
  return [[0 if i in rows or j in cols else x for j, x in enumerate(row)]
          for i, row in enumerate(m)]
  """,
  mk="""
  cases = [([[1, 1, 1], [1, 0, 1], [1, 1, 1]],), ([[0, 1], [1, 1]],),
           ([[1, 2], [3, 4]],), ([[0]],), ([[1, 0], [0, 1]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["m"],
  hints=["Find all rows and columns that contain a zero first.",
         "Apply the zeroing in a second pass."])

q(topic="python", diff="medium", tags=["math", "dp"], title="Full Pascal triangle",
  ask="Return the first `n` rows of Pascal's triangle as a list of lists.",
  sig="solve(n)", sol="""
  rows = []
  for i in range(n):
      rows.append([1] * (i + 1))
      for j in range(1, i):
          rows[i][j] = rows[i - 1][j - 1] + rows[i - 1][j]
  return rows
  """,
  mk="""
  cases = [(4,), (1,), (6,), (0,), (2,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["n"],
  hints=["Row `i` has `i + 1` entries.",
         "Interior entries are sums of two entries from the row above."])

q(topic="python", diff="medium", tags=["strings"], title="Group words by first letter",
  ask="Group the words in `words` by their first character. Return a dict mapping the "
      "letter to the alphabetically sorted list of words.",
  sig="solve(words)", sol="""
  groups = {}
  for w in words:
      groups.setdefault(w[0], []).append(w)
  return {k: sorted(v) for k, v in sorted(groups.items())}
  """,
  mk="""
  cases = [(["apple", "avocado", "banana"],), ([],), (["x"],), (["b", "a", "bb", "aa"],),
           (["cat", "car", "dog"],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["words"],
  hints=["`setdefault(key, [])` groups in a single pass.",
         "Sort the values inside each group."])

q(topic="python", diff="medium", tags=["oop", "dataclass"], title="Dataclass distance",
  ask="Define a `Point` dataclass with fields `x` and `y`, then return the Euclidean "
      "distance between `p1` and `p2` (given as `(x, y)` tuples) using a `Point` "
      "instance for each.",
  sig="solve(p1, p2)", sol="""
  from dataclasses import dataclass
  @dataclass
  class Point:
      x: float
      y: float
  a, b = Point(*p1), Point(*p2)
  return ((a.x - b.x) ** 2 + (a.y - b.y) ** 2) ** 0.5
  """,
  mk="""
  cases = [((0.0, 0.0), (3.0, 4.0)), ((1.0, 1.0), (1.0, 1.0)), ((-1.0, 2.0), (2.0, 6.0))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["p1", "p2"],
  hints=["`@dataclass` generates `__init__` and `__repr__` for you.",
         "`Point(*p1)` unpacks the tuple into the fields."])

q(topic="python", diff="medium", tags=["oop", "dunder"], title="Vector addition with __add__",
  ask="Define a class `Vec2` supporting `v + w` component-wise, then return "
      "`(v + w).x, (v + w).y` for the given pairs.",
  sig="solve(a, b)", sol="""
  class Vec2:
      def __init__(self, x, y):
          self.x, self.y = x, y
      def __add__(self, other):
          return Vec2(self.x + other.x, self.y + other.y)
  v, w = Vec2(*a), Vec2(*b)
  s = v + w
  return (s.x, s.y)
  """,
  mk="""
  cases = [((1.0, 2.0), (3.0, 4.0)), ((0.0, 0.0), (1.0, -1.0)), ((-1.0, 5.0), (1.0, -5.0))]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["`__add__` receives the right-hand operand as `other`.",
         "Return a new instance rather than mutating."])

q(topic="python", diff="medium", tags=["oop", "property"], title="Validated property",
  ask="Define a class `Temp` with a `celsius` attribute that rejects values below "
      "`-273.15` by raising `ValueError`. Return `(t.celsius, caught)` where `caught` "
      "is `True` if constructing `Temp(-300)` raised.",
  sig="solve(value)", sol="""
  class Temp:
      def __init__(self, celsius):
          self.celsius = celsius      # goes through the property setter
      @property
      def celsius(self):
          return self._c
      @celsius.setter
      def celsius(self, v):
          if v < -273.15:
              raise ValueError("below absolute zero")
          self._c = v
  t = Temp(value)
  try:
      Temp(-300)
      caught = False
  except ValueError:
      caught = True
  return (t.celsius, caught)
  """,
  mk="""
  cases = [(0.0,), (25.5,), (-273.15,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["value"],
  hints=["A property setter can validate before storing.",
         "Store the real value under a private attribute like `_c`."])

q(topic="python", diff="medium", tags=["oop"], title="Inheritance and overriding",
  ask="Define `Animal` with `speak()` returning `'generic'` and `Dog(Animal)` overriding "
      "it to return `'woof'`. Return the list of `speak()` results for the class names "
      "in `names` (either `'Dog'` or `'Animal'`).",
  sig="solve(names)", sol="""
  class Animal:
      def speak(self):
          return 'generic'
  class Dog(Animal):
      def speak(self):
          return 'woof'
  classes = {'Dog': Dog, 'Animal': Animal}
  return [classes[n]().speak() for n in names]
  """,
  mk="""
  cases = [(["Dog", "Animal"],), (["Animal"],), (["Dog", "Dog"],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["names"],
  hints=["A subclass overrides a method by redefining it.",
         "Instantiate with `classes[n]()` then call `.speak()`."])

q(topic="python", diff="medium", tags=["exceptions"], title="Safe division",
  ask="Return `a / b`, or `None` when `b == 0` (catch `ZeroDivisionError`).",
  sig="solve(a, b)", sol="""
  try:
      return a / b
  except ZeroDivisionError:
      return None
  """,
  mk="""
  cases = [(1.0, 2.0), (1.0, 0.0), (0.0, 0.0), (-3.0, 1.5), (5.0, 5.0)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["a", "b"],
  hints=["`try/except ZeroDivisionError`.",
         "Returning `None` signals 'no answer'."])

q(topic="python", diff="medium", tags=["exceptions"], title="Custom exception",
  ask="Define `NegativeError(Exception)` and a function that raises it for negative "
      "input. Return `(value * 2, caught)` where `caught` is `True` if the negative "
      "case raised `NegativeError`.",
  sig="solve(value)", sol="""
  class NegativeError(Exception):
      pass
  def double(x):
      if x < 0:
          raise NegativeError(f"negative: {x}")
      return x * 2
  caught = False
  try:
      double(-5)
  except NegativeError:
      caught = True
  return (double(value), caught)
  """,
  mk="""
  cases = [(3,), (0,), (10,)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["value"],
  hints=["Subclass `Exception` for custom errors.",
         "Catch the specific type, not bare `except`."])

q(topic="python", diff="medium", tags=["context-manager"], title="Context manager that logs",
  ask="Write a context manager class that appends its name to a list on enter and exit. "
      "Return the list of recorded events after using it.",
  sig="solve(name)", sol="""
  events = []
  class Log:
      def __init__(self, name):
          self.name = name
      def __enter__(self):
          events.append(('enter', self.name))
          return self
      def __exit__(self, *exc):
          events.append(('exit', self.name))
          return False
  with Log(name):
      pass
  return events
  """,
  mk="""
  cases = [("job",), ("",), ("a long name",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["name"],
  hints=["`__enter__` runs first, `__exit__` always runs on the way out.",
         "Returning `False` from `__exit__` lets exceptions propagate."])

q(topic="python", diff="medium", tags=["copy", "gotcha"], title="Deep copy a nested list",
  ask="Return a **deep** copy of the nested list `m` such that mutating the copy's inner "
      "list does not affect the original. Property checks mutate the returned copy.",
  sig="solve(m)", sol="""
  import copy
  return copy.deepcopy(m)
  """,
  mk="""
  cases = [([[1, 2], [3, 4]],), ([[1], [2]],), ([[[]]],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["m"],
  hints=["`copy.copy` only duplicates the outer list.",
         "`copy.deepcopy` recurses into nested containers."])

q(topic="python", diff="medium", tags=["gotcha", "default-arg"], title="Avoid the mutable default",
  ask="Implement `append(item)` that appends to a list which **starts empty on every "
      "call** (the classic mutable-default-argument bug). Return the accumulated lists "
      "after calling it with the three items `a`, `b`, `c`.",
  sig="solve(items)", sol="""
  def append(item, bucket=None):
      if bucket is None:
          bucket = []
      bucket.append(item)
      return bucket
  return [append(x) for x in items]
  """,
  mk="""
  cases = [(["a", "b", "c"],), (["x"],), ([],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["items"],
  hints=["Never use `[]` as a default argument value.",
         "Use `None` and create the list inside."])

q(topic="python", diff="hard", tags=["oop", "lru"], title="LRU cache",
  ask="`ops` simulates an LRU cache of capacity `cap`: `('put', k, v)` and "
      "`('get', k)`. Return the list of `get` results (`-1` when missing).",
  sig="solve(cap, ops)", sol="""
  from collections import OrderedDict
  cache = OrderedDict()
  out = []
  for op in ops:
      if op[0] == 'put':
          _, k, v = op
          if k in cache:
              cache.move_to_end(k)
          cache[k] = v
          if len(cache) > cap:
              cache.popitem(last=False)
      else:
          _, k = op
          if k in cache:
              cache.move_to_end(k)
              out.append(cache[k])
          else:
              out.append(-1)
  return out
  """,
  mk="""
  cases = [(2, [('put', 1, 1), ('put', 2, 2), ('get', 1), ('put', 3, 3), ('get', 2), ('get', 3)]),
           (1, [('put', 1, 10), ('get', 1), ('put', 2, 20), ('get', 1), ('get', 2)]),
           (3, [('get', 5)])]
  return cases[(v + i) % len(cases)]
  """, arg_names=["cap", "ops"],
  hints=["`OrderedDict.move_to_end` marks a key as recently used.",
         "Evict with `popitem(last=False)`."])

q(topic="python", diff="hard", tags=["design", "stack"], title="Min stack",
  ask="`ops` simulates a stack supporting `('push', v)`, `('pop',)` and `('min',)` in "
      "O(1). Return the results of the `min` operations.",
  sig="solve(ops)", sol="""
  stack = []
  mins = []
  out = []
  for op in ops:
      if op[0] == 'push':
          v = op[1]
          stack.append(v)
          mins.append(v if not mins else min(v, mins[-1]))
      elif op[0] == 'pop':
          stack.pop()
          mins.pop()
      else:
          out.append(mins[-1])
  return out
  """,
  mk="""
  cases = [([('push', 3), ('push', 1), ('min',), ('push', -2), ('min',)],),
           ([('push', 5), ('min',), ('pop',), ('push', 2), ('min',)],),
           ([('push', 0), ('push', 0), ('min',), ('pop',), ('min',)],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["ops"],
  hints=["Keep a parallel stack of running minima.",
         "Each element stores the minimum of everything below it."])

q(topic="python", diff="medium", tags=["iterators"], title="Generator pipeline",
  ask="Build a generator pipeline: take the squares of `xs`, keep only the even ones, "
      "and return the first `k` of them as a list.",
  sig="solve(xs, k)", sol="""
  squares = (x * x for x in xs)
  evens = (s for s in squares if s % 2 == 0)
  out = []
  for s in evens:
      out.append(s)
      if len(out) == k:
          break
  return out
  """,
  mk="""
  cases = [([1, 2, 3, 4, 5], 2), ([2, 4], 5), ([1], 1), ([6, 8, 10], 3), ([], 2)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs", "k"],
  hints=["Chained generators are lazy — values are only computed as needed.",
         "Stop early once you have `k` values."])

q(topic="python", diff="medium", tags=["functools"], title="Product with reduce",
  ask="Return the product of `xs` using `functools.reduce` (empty list → 1).",
  sig="solve(xs)", sol="""
  from functools import reduce
  import operator
  return reduce(operator.mul, xs, 1)
  """,
  mk="""
  cases = [([1, 2, 3, 4],), ([],), ([5],), ([2, 0, 3],), ([-1, 3],)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["xs"],
  hints=["The third argument to `reduce` is the initial accumulators.",
         "`operator.mul` is cleaner than a lambda."])

q(topic="python", diff="medium", tags=["strings", "parsing"], title="Parse a query string",
  ask="Parse the URL query `'a=1&b=2&a=3'`-style string `qs` into a dict of lists of "
      "values (keys sorted).",
  sig="solve(qs)", sol="""
  out = {}
  for pair in qs.split('&'):
      if not pair:
          continue
      key, _, value = pair.partition('=')
      out.setdefault(key, []).append(value)
  return {k: out[k] for k in sorted(out)}
  """,
  mk="""
  cases = [("a=1&b=2&a=3",), ("",), ("x=1",), ("k=&k=v",), ("z=9&z=8&z=7",)]
  return cases[(v + i) % len(cases)]
  """, arg_names=["qs"],
  hints=["`str.partition('=')` splits into key, separator, value.",
         "`setdefault` collects repeated keys."])
