"""
TensorForge execution worker.

Runs one submission against the generated checks in an isolated child process.
Reads a JSON payload on stdin, writes a JSON result on stdout.

Two modes:
  * one-shot:  read all of stdin, write one JSON object, exit.
  * serve:     `--serve`; loop forever, one JSON job per line, one result line per job
               (prefixed with `@@TF@@`) so the Flask app can reuse a warm process.

Payload:  {"source": str, "checks": [{"name","kind","source","n"}], "timeout": int}
Result:   {"ok": bool, "compile_error": str|None, "results": [...],
           "figures": [b64 png, ...], "stdout": str}
"""
from __future__ import annotations

import base64
import contextlib
import io
import json
import os
import sys
import time
import traceback
import types

MAX_STDOUT = 6000
MAX_FIGURES = 2


def _write_out(text: str) -> None:
    """
    Write a line to the parent process.

    A windowed (console=False) PyInstaller build has sys.stdout = None, so fall
    back to the raw file descriptor, which is still the pipe the parent created.
    """
    try:
        if sys.stdout is not None:
            sys.stdout.write(text)
            sys.stdout.flush()
            return
    except Exception:
        pass
    try:
        os.write(1, text.encode("utf-8"))
    except Exception:
        pass


def _apply_limits() -> None:
    """Best-effort resource limits (POSIX only; harmless elsewhere)."""
    try:
        import resource

        # 4 GiB address space: enough for torch, small enough to avoid swapping.
        # No RLIMIT_CPU here: this process is long-lived and the parent enforces
        # a per-submission wall-clock timeout instead.
        resource.setrlimit(resource.RLIMIT_AS, (4 * 1024 ** 3, 4 * 1024 ** 3))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    except Exception:
        pass


def _quiet_matplotlib() -> None:
    try:
        import matplotlib

        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt

        plt.show = lambda *a, **k: None
    except Exception:
        pass


def _load_user(source: str):
    """Execute the submission in a real module so dataclasses / pickling work."""
    mod = types.ModuleType("tf_user")
    sys.modules["tf_user"] = mod
    sys.modules["__tf_user__"] = mod
    compile(source, "<your code>", "exec")
    exec(source, mod.__dict__)
    return mod.__dict__.get("solve")


def _grab_figures() -> list[str]:
    out: list[str] = []
    try:
        import matplotlib.pyplot as plt

        for num in plt.get_fignums()[:MAX_FIGURES]:
            fig = plt.figure(num)
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=110, bbox_inches="tight",
                        facecolor="white")
            out.append(base64.b64encode(buf.getvalue()).decode("ascii"))
        plt.close("all")
    except Exception:
        pass
    return out


def _short_trace(exc: BaseException) -> str:
    tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
    # keep the last frames that point into the user's code / checks
    lines = [ln.rstrip() for ln in tb if ln.strip()]
    tail = lines[-6:]
    return "\n".join(tail)


def run(payload: dict) -> dict:
    source = payload.get("source", "")
    checks = payload.get("checks", [])
    result = {
        "ok": False,
        "compile_error": None,
        "results": [],
        "figures": [],
        "stdout": "",
    }

    _quiet_matplotlib()

    try:
        solve = _load_user(source)
    except SyntaxError as exc:
        result["compile_error"] = f"SyntaxError: {exc.msg} (line {exc.lineno})"
        return result
    except Exception as exc:
        result["compile_error"] = _short_trace(exc)
        return result

    if solve is None:
        result["compile_error"] = (
            "No `solve` function found. Define it exactly as shown in the "
            "signature at the top of the starter code."
        )
        return result
    if not callable(solve):
        result["compile_error"] = "`solve` is not callable — did you overwrite it?"
        return result

    out = io.StringIO()
    ok_all = True
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(io.StringIO()):
        for chk in checks:
            t0 = time.time()
            g = {"__name__": "tf_check", "solve": solve}
            item = {"name": chk.get("name", "check"), "passed": True, "message": "",
                    "time_ms": 0}
            try:
                exec(compile(chk["source"], "<test>", "exec"), g)
                if chk.get("kind") == "cases":
                    for i in range(int(chk.get("n", 0))):
                        g["_case"](i)
                else:
                    g["_props"]()
            except AssertionError as exc:
                ok_all = False
                item["passed"] = False
                item["message"] = str(exc) or "assertion failed"
            except Exception as exc:  # noqa: BLE001
                ok_all = False
                item["passed"] = False
                item["message"] = _short_trace(exc)
            item["time_ms"] = int((time.time() - t0) * 1000)
            result["results"].append(item)

    result["figures"] = _grab_figures()
    text = out.getvalue()
    if len(text) > MAX_STDOUT:
        text = text[:MAX_STDOUT] + "\n... (output truncated)"
    result["stdout"] = text
    result["ok"] = ok_all and bool(result["results"])
    return result


def _safe_run(payload: dict) -> dict:
    """Run a submission; any hard crash (segfault) kills the process instead."""
    try:
        return run(payload)
    except MemoryError:
        return {"ok": False, "compile_error": "Out of memory while running your code.",
                "results": [], "figures": [], "stdout": ""}
    except BaseException as exc:  # noqa: BLE001
        return {"ok": False, "compile_error": _short_trace(exc), "results": [],
                "figures": [], "stdout": ""}


def _warmup() -> None:
    """Import the heavy libraries up front so the first Run is not slow."""
    for mod in ("numpy", "torch", "torch.nn.functional", "matplotlib.pyplot"):
        try:
            __import__(mod)
        except Exception:
            pass
    _quiet_matplotlib()


def main() -> None:
    _apply_limits()
    serve = "--serve" in sys.argv
    if serve:
        _warmup()
        _write_out("__TF_READY__\n")
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                payload = json.loads(line)
            except Exception:
                payload = {}
            res = _safe_run(payload)
            _write_out("@@TF@@" + json.dumps(res) + "\n")
        return

    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw.strip() else {}
    except Exception:
        payload = {}
    _write_out(json.dumps(_safe_run(payload)))


if __name__ == "__main__":
    main()
