"""
Fast, curated PyInstaller hook for PyTorch.

The stock contrib hook calls ``collect_submodules("torch")``, which *imports*
every torch submodule (including torch.distributed, torch._dynamo,
torch._inductor, torch.utils.tensorboard, ...). That takes minutes on a normal
machine and can exhaust memory on small ones, while bundling a lot of code the
practice app never executes.

TensorForge only needs the everyday tensor API plus nn / optim / autograd /
utils.data / linalg. Everything else is either unreachable from those modules or
provided by the shared libraries in torch/lib (which we do bundle in full).
"""
from PyInstaller.utils.hooks import collect_dynamic_libs, collect_data_files, get_package_paths

# Every shared library torch needs at runtime (libtorch_cpu, libc10, libgomp, ...)
binaries = collect_dynamic_libs("torch")

# torch calls inspect.getsource() on its own modules while importing (see
# torch/utils/_config_module.py reading '# compile_ignored' markers). Frozen
# modules live in an archive, so ship the sources of the packages that do this
# as plain data files — PyInstaller points module.__file__ at the unpacked
# directory, so getsource() reads the real code again.
datas = collect_data_files(
    "torch",
    include_py_files=True,
    includes=["*.py", "**/*.py"],
    excludes=["**/test/**", "**/include/**"],
)

# Non-.py data shipped inside the package (version metadata, templates, etc.).
# Test suites and C++ headers are dropped: they are large and never imported.
datas += collect_data_files(
    "torch",
    excludes=[
        "**/test/**",
        "**/include/**",
        "**/*.h",
        "**/*.hpp",
        "**/*.cuh",
        "**/*.cu",
        "**/bin/**",
    ],
)

hiddenimports = [
    "torch",
    "torch._C", "torch._VF", "torch._jit_internal", "torch._tensor", "torch._utils",
    "torch.types", "torch.version", "torch.random", "torch.serialization",
    "torch.storage", "torch.overrides", "torch.signal", "torch.special",
    "torch.sparse", "torch.fx", "torch.jit", "torch.backends",
    "torch.backends.cpu", "torch.backends.cudnn", "torch.backends.mps",
    "torch.nn", "torch.nn.functional", "torch.nn.init", "torch.nn.parameter",
    "torch.nn.modules", "torch.nn.utils", "torch.nn.utils.clip_grad",
    "torch.nn.utils.parametrizations", "torch.nn.utils.rnn",
    "torch.optim", "torch.optim.sgd", "torch.optim.adam", "torch.optim.adamw",
    "torch.optim.rmsprop", "torch.optim.adagrad", "torch.optim.lr_scheduler",
    "torch.autograd", "torch.autograd.functional", "torch.autograd.gradcheck",
    "torch.utils", "torch.utils.data", "torch.utils.data.dataloader",
    "torch.utils.data.dataset", "torch.utils.data.sampler",
    "torch.utils.data.distributed",
    "torch.linalg", "torch.fft", "torch.distributions",
    "ctypes.util", "ctypes.wintypes", "ctypes.macholib",
    # torch._jit_internal imports these at torch.nn import time
    "torch.distributed", "torch.distributed.rpc", "torch.distributed.rpc.api",
    "torch.distributions.normal", "torch.distributions.uniform",
]

# Keep the bundled tree lean: these packages are pulled in transitively by
# torch's optional integrations and are never used by the app.
# Only packages that torch never touches during normal tensor/nn/optim usage.
# Everything else stays bundled: a missing module deep inside torch's import
# chain surfaces much later as a confusing ImportError.
excludedimports = [
    "torch.utils.tensorboard", "torch.utils.benchmark", "torch.utils.cpp_extension",
    "torchvision", "torchaudio", "tensorboard", "numpy.distutils",
]
